"""
Shared pytest fixtures. Every app's test suite can use these without
reimplementing auth setup — this is what unblocks sales/inventory/fraud
tests, which all need an authenticated request context.
"""
import pytest
from rest_framework.test import APIClient

from apps.core.tests.factories import (
    BranchFactory,
    BusinessFactory,
    CashierFactory,
    ManagerFactory,
    OwnerFactory,
)


@pytest.fixture
def api_client():
    return APIClient()


@pytest.fixture
def business(db):
    return BusinessFactory()


@pytest.fixture
def branch(business):
    return BranchFactory(business=business)


@pytest.fixture
def owner(business):
    return OwnerFactory(business=business)


@pytest.fixture
def manager(business):
    return ManagerFactory(business=business)


@pytest.fixture
def cashier(business):
    return CashierFactory(business=business)


def _auth_client(user):
    """
    Issues a real token via the same RetailGuardAccessToken class the
    login endpoint uses, so authenticated-fixture tests exercise the same
    JWT claims (business_id, role, primary_branch_id) production requests
    carry — not a stand-in that happens to pass permission checks.
    """
    from apps.authentication.tokens import RetailGuardAccessToken

    client = APIClient()
    token = RetailGuardAccessToken.for_user(user)
    client.credentials(HTTP_AUTHORIZATION=f'Bearer {token}')
    return client


@pytest.fixture
def owner_client(owner):
    return _auth_client(owner)


@pytest.fixture
def manager_client(manager):
    return _auth_client(manager)


@pytest.fixture
def cashier_client(cashier):
    return _auth_client(cashier)
