# RetailGuard — Database Schema v4.0 (FINAL LOCKED)
# Patch v3 Applied | PostgreSQL 15+ | All domain PKs → UUID

## Patch v3 Change Manifest (delta from v3.0)

| # | Change | Scope |
|---|---|---|
| 1 | All business-domain PKs → UUID (gen_random_uuid()) | 16 tables |
| 2 | BIGSERIAL kept for inventory_movements, product_price_history | 2 tables |
| 3 | SALE_VOID added to inventory_movements.movement_type enum | inventory_movements |
| 4 | sales.status gains 'pending_payment' state | sales |
| 5 | Non-cash payment confirmation enforced at app layer | sales + payment_transactions |
| 6 | terminal_takeover_events → terminal_takeovers (new schema) | new table |
| 7 | sale_price_approvals → price_override_approvals (new schema) | new table |
| 8 | sale_items.override_approval_id FK target updated | sale_items |
| 9 | EXCESSIVE_SALE_VOIDS, EXCESSIVE_DISCOUNT_APPROVALS, FREQUENT_TERMINAL_TAKEOVERS added | fraud_rules |
| 10 | All FKs updated to UUID references | all tables |

## UUID Migration Scope

### UUID (gen_random_uuid()) — business domain tables
businesses, branches, warehouses, users, user_sessions,
user_branch_assignments, categories, products,
inventory_stock, inventory_damage_reports, shifts, attendance,
sync_batches, sales, sale_items, payment_transactions,
price_override_approvals, cash_reconciliation, stock_transfers,
stock_transfer_items, expense_categories, expenses,
fraud_rules, fraud_alerts, terminal_takeovers, audit_logs

### BIGSERIAL — high-volume append-only ledger tables
inventory_movements, product_price_history

Rationale: UUID prevents ID enumeration attacks, enables safe offline
provisioning, and prepares the schema for multi-tenant federation.
Ledger tables keep BIGSERIAL for INSERT throughput at scale.

---
## COMPLETE SCHEMA

-- ============================================================
-- EXTENSIONS
-- ============================================================
CREATE EXTENSION IF NOT EXISTS "pgcrypto";  -- gen_random_uuid()

-- ============================================================
-- LAYER 1: FOUNDATION
-- ============================================================

CREATE TABLE businesses (
    id              UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    name            VARCHAR(200)    NOT NULL,
    slug            VARCHAR(100)    NOT NULL UNIQUE,
    phone           VARCHAR(20),
    email           VARCHAR(255),
    address         TEXT,
    currency        CHAR(3)         NOT NULL DEFAULT 'XAF',
    timezone        VARCHAR(60)     NOT NULL DEFAULT 'Africa/Douala',
    is_active       BOOLEAN         NOT NULL DEFAULT TRUE,
    settings        JSONB           NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);
-- settings keys: unsynced_alert_hours, max_cashier_discount_pct,
-- cash_shortage_alert_xaf, transfer_variance_alert_units,
-- max_voids_per_shift, max_price_overrides_per_shift,
-- max_price_overrides_per_manager_per_day,
-- require_manager_approval_for_void, allow_negative_stock


CREATE TABLE categories (
    id              UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    business_id     UUID            NOT NULL REFERENCES businesses(id),
    name            VARCHAR(100)    NOT NULL,
    description     TEXT,
    is_active       BOOLEAN         NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_category_name_per_business UNIQUE (business_id, name)
);


CREATE TABLE branches (
    id              UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    business_id     UUID            NOT NULL REFERENCES businesses(id),
    name            VARCHAR(200)    NOT NULL,
    code            VARCHAR(20)     NOT NULL,
    address         TEXT,
    phone           VARCHAR(20),
    manager_id      UUID,           -- FK added post-users
    is_active       BOOLEAN         NOT NULL DEFAULT TRUE,
    is_deleted      BOOLEAN         NOT NULL DEFAULT FALSE,
    deleted_at      TIMESTAMPTZ,
    deleted_by      UUID,           -- FK added post-users
    created_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_branch_code UNIQUE (business_id, code)
);


CREATE TABLE warehouses (
    id              UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    business_id     UUID            NOT NULL REFERENCES businesses(id),
    name            VARCHAR(200)    NOT NULL,
    code            VARCHAR(20)     NOT NULL,
    address         TEXT,
    phone           VARCHAR(20),
    manager_id      UUID,
    is_active       BOOLEAN         NOT NULL DEFAULT TRUE,
    is_deleted      BOOLEAN         NOT NULL DEFAULT FALSE,
    deleted_at      TIMESTAMPTZ,
    deleted_by      UUID,
    created_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_warehouse_code UNIQUE (business_id, code)
);

-- ============================================================
-- LAYER 2: IDENTITY & ACCESS
-- ============================================================

CREATE TABLE users (
    id                      UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    business_id             UUID            NOT NULL REFERENCES businesses(id),
    employee_id             VARCHAR(50),
    first_name              VARCHAR(100)    NOT NULL,
    last_name               VARCHAR(100)    NOT NULL,
    phone                   VARCHAR(20)     UNIQUE,
    email                   VARCHAR(255)    UNIQUE,
    password_hash           VARCHAR(255)    NOT NULL,
    role                    VARCHAR(30)     NOT NULL
        CHECK (role IN ('owner', 'manager', 'cashier', 'warehouse_staff')),
    override_pin_hash       VARCHAR(255),
    is_active               BOOLEAN         NOT NULL DEFAULT TRUE,
    is_deleted              BOOLEAN         NOT NULL DEFAULT FALSE,
    last_login_at           TIMESTAMPTZ,
    failed_login_attempts   INTEGER         NOT NULL DEFAULT 0,
    locked_until            TIMESTAMPTZ,
    deleted_at              TIMESTAMPTZ,
    deleted_by              UUID            REFERENCES users(id),
    created_by              UUID            REFERENCES users(id),
    created_at              TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    CONSTRAINT require_phone_or_email CHECK (phone IS NOT NULL OR email IS NOT NULL)
);

-- Resolve deferred FKs
ALTER TABLE branches
    ADD CONSTRAINT fk_branch_manager   FOREIGN KEY (manager_id)  REFERENCES users(id),
    ADD CONSTRAINT fk_branch_deleted   FOREIGN KEY (deleted_by)  REFERENCES users(id);

ALTER TABLE warehouses
    ADD CONSTRAINT fk_wh_manager       FOREIGN KEY (manager_id)  REFERENCES users(id),
    ADD CONSTRAINT fk_wh_deleted       FOREIGN KEY (deleted_by)  REFERENCES users(id);


CREATE TABLE user_sessions (
    id                  UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id             UUID            NOT NULL REFERENCES users(id),
    token_hash          VARCHAR(255)    NOT NULL,
    device_info         JSONB           NOT NULL DEFAULT '{}',
    device_fingerprint  VARCHAR(200),
    ip_address          INET,
    is_active           BOOLEAN         NOT NULL DEFAULT TRUE,
    expires_at          TIMESTAMPTZ     NOT NULL,
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    last_activity       TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    terminated_at       TIMESTAMPTZ,
    terminated_by       UUID            REFERENCES users(id),
    termination_reason  VARCHAR(30)
        CHECK (termination_reason IN (
            'logout','terminal_takeover','expired','admin_revoke','force_close'
        ))
);


CREATE TABLE user_branch_assignments (
    id              UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         UUID            NOT NULL REFERENCES users(id),
    branch_id       UUID            REFERENCES branches(id),
    warehouse_id    UUID            REFERENCES warehouses(id),
    is_primary      BOOLEAN         NOT NULL DEFAULT FALSE,
    assigned_at     TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    assigned_by     UUID            NOT NULL REFERENCES users(id),
    revoked_at      TIMESTAMPTZ,
    revoked_by      UUID            REFERENCES users(id),
    CONSTRAINT location_exclusive CHECK (
        (branch_id IS NOT NULL AND warehouse_id IS NULL) OR
        (warehouse_id IS NOT NULL AND branch_id IS NULL)
    )
);

-- ============================================================
-- LAYER 3: PRODUCTS
-- ============================================================

CREATE TABLE products (
    id                  UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    business_id         UUID            NOT NULL REFERENCES businesses(id),
    category_id         UUID            REFERENCES categories(id),
    name                VARCHAR(200)    NOT NULL,
    sku                 VARCHAR(100),
    barcode             VARCHAR(100),
    description         TEXT,
    brand               VARCHAR(100),
    series_name         VARCHAR(100),
    tile_size           VARCHAR(20),
    tile_finish         VARCHAR(30),
    tile_material       VARCHAR(30),
    tile_type           VARCHAR(20),
    color_description   VARCHAR(100),
    specifications      JSONB           DEFAULT '{}',
    stock_unit          VARCHAR(20)     NOT NULL DEFAULT 'BOX'
        CHECK (stock_unit IN ('PIECE','BOX','SQM','PALLET')),
    pieces_per_box      NUMERIC(10,4),
    sqm_per_box         NUMERIC(10,4),
    sqm_per_piece       NUMERIC(10,4),
    boxes_per_pallet    NUMERIC(10,4),
    cost_price          INTEGER         NOT NULL DEFAULT 0,
    selling_price       INTEGER         NOT NULL,
    min_selling_price   INTEGER,
    reorder_level       NUMERIC(12,3)   NOT NULL DEFAULT 0,
    is_active           BOOLEAN         NOT NULL DEFAULT TRUE,
    is_deleted          BOOLEAN         NOT NULL DEFAULT FALSE,
    deleted_at          TIMESTAMPTZ,
    deleted_by          UUID            REFERENCES users(id),
    created_by          UUID            NOT NULL REFERENCES users(id),
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_sku_per_business   UNIQUE (business_id, sku),
    CONSTRAINT selling_price_pos     CHECK (selling_price > 0),
    CONSTRAINT cost_price_non_neg    CHECK (cost_price >= 0),
    CONSTRAINT min_price_pos         CHECK (min_selling_price IS NULL OR min_selling_price > 0),
    CONSTRAINT min_lte_selling       CHECK (min_selling_price IS NULL OR min_selling_price <= selling_price),
    CONSTRAINT sqm_consistency       CHECK (
        sqm_per_piece IS NULL OR pieces_per_box IS NULL OR sqm_per_box IS NULL OR
        ABS((sqm_per_piece * pieces_per_box) - sqm_per_box) < 0.001
    )
);


-- BIGSERIAL: append-only ledger
CREATE TABLE product_price_history (
    id                  BIGSERIAL       PRIMARY KEY,
    product_id          UUID            NOT NULL REFERENCES products(id),
    old_cost_price      INTEGER,
    new_cost_price      INTEGER,
    old_selling_price   INTEGER,
    new_selling_price   INTEGER,
    old_min_price       INTEGER,
    new_min_price       INTEGER,
    changed_by          UUID            NOT NULL REFERENCES users(id),
    reason              TEXT,
    changed_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

-- ============================================================
-- LAYER 4: INVENTORY
-- ============================================================

CREATE TABLE inventory_stock (
    id              UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id      UUID            NOT NULL REFERENCES products(id),
    branch_id       UUID            REFERENCES branches(id),
    warehouse_id    UUID            REFERENCES warehouses(id),
    quantity        NUMERIC(12,3)   NOT NULL DEFAULT 0,
    updated_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_stock_per_location    UNIQUE (product_id, branch_id, warehouse_id),
    CONSTRAINT location_exclusive       CHECK (
        (branch_id IS NOT NULL AND warehouse_id IS NULL) OR
        (warehouse_id IS NOT NULL AND branch_id IS NULL)
    ),
    CONSTRAINT quantity_non_negative    CHECK (quantity >= 0)
);


-- BIGSERIAL: very high volume, append-only
CREATE TABLE inventory_movements (
    id              BIGSERIAL       PRIMARY KEY,
    business_id     UUID            NOT NULL REFERENCES businesses(id),
    product_id      UUID            NOT NULL REFERENCES products(id),
    branch_id       UUID            REFERENCES branches(id),
    warehouse_id    UUID            REFERENCES warehouses(id),
    movement_type   VARCHAR(30)     NOT NULL
        CHECK (movement_type IN (
            'OPENING_STOCK',
            'RESTOCK',
            'SALE',
            'SALE_VOID',        -- NEW in v4: void reversal is distinct from adjustment
            'TRANSFER_OUT',
            'TRANSFER_IN',
            'DAMAGE',
            'ADJUSTMENT',
            'COUNT_CORRECTION'
        )),
    quantity_before     NUMERIC(12,3)   NOT NULL,
    quantity_change     NUMERIC(12,3)   NOT NULL,
    quantity_after      NUMERIC(12,3)   NOT NULL,
    reference_type      VARCHAR(50),
    reference_id        VARCHAR(100),
    notes               TEXT,
    performed_by        UUID            NOT NULL REFERENCES users(id),
    approved_by         UUID            REFERENCES users(id),
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    CONSTRAINT movement_math CHECK (quantity_before + quantity_change = quantity_after),
    CONSTRAINT location_exclusive CHECK (
        (branch_id IS NOT NULL AND warehouse_id IS NULL) OR
        (warehouse_id IS NOT NULL AND branch_id IS NULL)
    )
);
-- SALE_VOID rationale: fraud analytics now distinguishes legitimate
-- operational adjustments from sale reversals. Query:
-- SELECT cashier_id, COUNT(*) FROM inventory_movements
-- WHERE movement_type = 'SALE_VOID' GROUP BY cashier_id
-- produces clean cashier void frequency reports.


CREATE TABLE inventory_damage_reports (
    id              UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    business_id     UUID            NOT NULL REFERENCES businesses(id),
    product_id      UUID            NOT NULL REFERENCES products(id),
    branch_id       UUID            REFERENCES branches(id),
    warehouse_id    UUID            REFERENCES warehouses(id),
    quantity_damaged        NUMERIC(12,3)   NOT NULL,
    unit_reported           VARCHAR(20)     NOT NULL
        CHECK (unit_reported IN ('PIECE','BOX','SQM','PALLET')),
    quantity_in_stock_unit  NUMERIC(12,3)   NOT NULL,
    damage_type     VARCHAR(30)     NOT NULL
        CHECK (damage_type IN (
            'loading_breakage','transit_breakage','handling_breakage',
            'water_damage','expired','other'
        )),
    description     TEXT            NOT NULL,
    photo_reference TEXT,
    reported_by     UUID            NOT NULL REFERENCES users(id),
    approved_by     UUID            REFERENCES users(id),
    status          VARCHAR(20)     NOT NULL DEFAULT 'pending'
        CHECK (status IN ('pending','approved','rejected')),
    movement_id     BIGINT          REFERENCES inventory_movements(id),
    approved_at     TIMESTAMPTZ,
    rejection_note  TEXT,
    is_deleted      BOOLEAN         NOT NULL DEFAULT FALSE,
    deleted_at      TIMESTAMPTZ,
    deleted_by      UUID            REFERENCES users(id),
    created_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    CONSTRAINT qty_damaged_pos      CHECK (quantity_damaged > 0),
    CONSTRAINT stock_unit_qty_pos   CHECK (quantity_in_stock_unit > 0),
    CONSTRAINT location_exclusive   CHECK (
        (branch_id IS NOT NULL AND warehouse_id IS NULL) OR
        (warehouse_id IS NOT NULL AND branch_id IS NULL)
    )
);

-- ============================================================
-- LAYER 5: OPERATIONS
-- ============================================================

CREATE TABLE shifts (
    id                  UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    business_id         UUID            NOT NULL REFERENCES businesses(id),
    branch_id           UUID            NOT NULL REFERENCES branches(id),
    cashier_id          UUID            NOT NULL REFERENCES users(id),
    status              VARCHAR(30)     NOT NULL DEFAULT 'open'
        CHECK (status IN (
            'open','closed_pending','closed_synced','closed_conflict','force_closed'
        )),
    opening_cash        INTEGER         NOT NULL DEFAULT 0,
    started_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    closed_at           TIMESTAMPTZ,
    sync_completed_at   TIMESTAMPTZ,
    unsynced_alert_sent BOOLEAN         NOT NULL DEFAULT FALSE,
    is_force_closed     BOOLEAN         NOT NULL DEFAULT FALSE,
    force_closed_by     UUID            REFERENCES users(id),
    force_closed_at     TIMESTAMPTZ,
    force_close_reason  TEXT,
    notes               TEXT,
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

-- ONE ACTIVE TERMINAL PER BRANCH — database enforced
CREATE UNIQUE INDEX uq_one_active_terminal_per_branch
    ON shifts(branch_id)
    WHERE status = 'open';


CREATE TABLE attendance (
    id              UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         UUID            NOT NULL REFERENCES users(id),
    branch_id       UUID            NOT NULL REFERENCES branches(id),
    shift_id        UUID            REFERENCES shifts(id),
    check_in_at     TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    check_out_at    TIMESTAMPTZ,
    status          VARCHAR(20)     NOT NULL DEFAULT 'present'
        CHECK (status IN ('present','late','half_day','absent')),
    notes           TEXT,
    created_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);


-- NEW in v4 (replaces terminal_takeover_events)
CREATE TABLE terminal_takeovers (
    id                  UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    branch_id           UUID            NOT NULL REFERENCES branches(id),
    old_shift_id        UUID            NOT NULL REFERENCES shifts(id),
    previous_device_id  VARCHAR(255)    NOT NULL,
    new_device_id       VARCHAR(255)    NOT NULL,
    previous_session_id UUID            REFERENCES user_sessions(id),
    new_session_id      UUID            REFERENCES user_sessions(id),
    approved_by         UUID            NOT NULL REFERENCES users(id),
    approval_method     VARCHAR(20)     NOT NULL
        CHECK (approval_method IN ('pin','password','re_auth')),
    reason              TEXT            NOT NULL,
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

-- ============================================================
-- LAYER 6: SYNC
-- ============================================================

CREATE TABLE sync_batches (
    id                  UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    shift_id            UUID            NOT NULL REFERENCES shifts(id),
    cashier_id          UUID            NOT NULL REFERENCES users(id),
    device_info         JSONB,
    records_submitted   INTEGER         NOT NULL DEFAULT 0,
    records_accepted    INTEGER         NOT NULL DEFAULT 0,
    records_rejected    INTEGER         NOT NULL DEFAULT 0,
    records_conflict    INTEGER         NOT NULL DEFAULT 0,
    status              VARCHAR(20)     NOT NULL DEFAULT 'processing'
        CHECK (status IN ('processing','completed','partial','failed')),
    submitted_at        TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    completed_at        TIMESTAMPTZ,
    error_detail        TEXT
);

-- ============================================================
-- LAYER 7: SALES
-- ============================================================

-- NEW in v4 (replaces sale_price_approvals)
CREATE TABLE price_override_approvals (
    id                      UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id              UUID            NOT NULL REFERENCES products(id),
    branch_id               UUID            NOT NULL REFERENCES branches(id),
    cashier_id              UUID            NOT NULL REFERENCES users(id),
    approved_by             UUID            NOT NULL REFERENCES users(id),
    requested_price         INTEGER         NOT NULL,
    selling_price_at_time   INTEGER         NOT NULL,
    min_price_at_time       INTEGER         NOT NULL,
    reason                  TEXT            NOT NULL,
    status                  VARCHAR(20)     NOT NULL DEFAULT 'pending'
        CHECK (status IN ('pending','approved','rejected')),
    approved_at             TIMESTAMPTZ,
    expires_at              TIMESTAMPTZ,
    used_at                 TIMESTAMPTZ,
    sale_id                 UUID,           -- FK added post-sales; set when approval consumed
    CONSTRAINT self_approval_forbidden CHECK (cashier_id != approved_by),
    CONSTRAINT requested_price_pos     CHECK (requested_price > 0)
);


CREATE TABLE sales (
    id                  UUID            PRIMARY KEY,  -- client-generated
    business_id         UUID            NOT NULL REFERENCES businesses(id),
    branch_id           UUID            NOT NULL REFERENCES branches(id),
    shift_id            UUID            NOT NULL REFERENCES shifts(id),
    cashier_id          UUID            NOT NULL REFERENCES users(id),
    receipt_number      VARCHAR(50)     UNIQUE,
    subtotal            INTEGER         NOT NULL,
    discount_amount     INTEGER         NOT NULL DEFAULT 0,
    total_amount        INTEGER         NOT NULL,
    status              VARCHAR(30)     NOT NULL DEFAULT 'completed'
        CHECK (status IN (
            'completed',        -- all payments confirmed
            'pending_payment',  -- NEW v4: non-cash payment awaiting confirmation
            'voided'
        )),
    void_reason         TEXT,
    voided_by           UUID            REFERENCES users(id),
    voided_at           TIMESTAMPTZ,
    approval_required   BOOLEAN         NOT NULL DEFAULT FALSE,
    sync_status         VARCHAR(20)     NOT NULL DEFAULT 'pending'
        CHECK (sync_status IN ('pending','synced','conflict','rejected')),
    sync_batch_id       UUID            REFERENCES sync_batches(id),
    sync_rejection_reason TEXT,
    created_at_device   TIMESTAMPTZ     NOT NULL,
    synced_at           TIMESTAMPTZ,
    notes               TEXT,
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    CONSTRAINT total_pos        CHECK (total_amount > 0),
    CONSTRAINT subtotal_pos     CHECK (subtotal > 0),
    CONSTRAINT discount_nn      CHECK (discount_amount >= 0),
    CONSTRAINT total_math       CHECK (total_amount = subtotal - discount_amount)
);

-- Resolve price_override_approvals.sale_id FK
ALTER TABLE price_override_approvals
    ADD CONSTRAINT fk_approval_sale
        FOREIGN KEY (sale_id) REFERENCES sales(id) ON DELETE SET NULL;


CREATE TABLE sale_items (
    id                      UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    sale_id                 UUID            NOT NULL REFERENCES sales(id) ON DELETE RESTRICT,
    product_id              UUID            NOT NULL REFERENCES products(id),
    product_name            VARCHAR(200)    NOT NULL,
    product_sku             VARCHAR(100),
    tile_size               VARCHAR(20),
    unit_sold               VARCHAR(20)     NOT NULL
        CHECK (unit_sold IN ('PIECE','BOX','SQM','PALLET')),
    quantity_sold           NUMERIC(12,3)   NOT NULL,
    stock_unit_snapshot     VARCHAR(20)     NOT NULL,
    quantity_in_stock_unit  NUMERIC(12,3)   NOT NULL,
    unit_price              INTEGER         NOT NULL,
    discount_amount         INTEGER         NOT NULL DEFAULT 0,
    total_price             INTEGER         NOT NULL,
    is_price_override       BOOLEAN         NOT NULL DEFAULT FALSE,
    override_approval_id    UUID            REFERENCES price_override_approvals(id),
    CONSTRAINT qty_sold_pos          CHECK (quantity_sold > 0),
    CONSTRAINT stock_unit_qty_pos    CHECK (quantity_in_stock_unit > 0),
    CONSTRAINT unit_price_pos        CHECK (unit_price > 0),
    CONSTRAINT total_price_pos       CHECK (total_price > 0),
    CONSTRAINT override_needs_ref    CHECK (
        is_price_override = FALSE OR override_approval_id IS NOT NULL
    )
);


CREATE TABLE payment_transactions (
    id                  UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    sale_id             UUID            NOT NULL REFERENCES sales(id) ON DELETE RESTRICT,
    payment_method      VARCHAR(20)     NOT NULL
        CHECK (payment_method IN ('CASH','MTN_MOMO','ORANGE_MONEY','BANK_TRANSFER')),
    amount              INTEGER         NOT NULL,
    reference_number    VARCHAR(100),
    provider_response   JSONB,
    is_confirmed        BOOLEAN         NOT NULL DEFAULT FALSE,
    confirmed_at        TIMESTAMPTZ,
    confirmed_by        UUID            REFERENCES users(id),
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    CONSTRAINT amount_pos CHECK (amount > 0),
    CONSTRAINT cash_no_ref CHECK (
        payment_method != 'CASH' OR reference_number IS NULL
    ),
    CONSTRAINT non_cash_ref_on_confirm CHECK (
        payment_method = 'CASH' OR is_confirmed = FALSE OR reference_number IS NOT NULL
    )
);
-- STRICT CONFIRMATION RULE (v4):
-- Application enforces: if any payment_transaction.is_confirmed = FALSE
-- AND payment_method != 'CASH', sale.status must be 'pending_payment'.
-- Sale transitions to 'completed' only when all non-cash payments confirmed.
-- This prevents the fake-screenshot mobile money fraud scenario.

-- ============================================================
-- LAYER 8: RECONCILIATION
-- ============================================================

CREATE TABLE cash_reconciliation (
    id                          UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    shift_id                    UUID            NOT NULL UNIQUE REFERENCES shifts(id),
    branch_id                   UUID            NOT NULL REFERENCES branches(id),
    cashier_id                  UUID            NOT NULL REFERENCES users(id),
    opening_cash                INTEGER         NOT NULL,
    confirmed_cash_sales        INTEGER         NOT NULL,
    pending_cash_sales          INTEGER         NOT NULL DEFAULT 0,
    expected_cash_confirmed     INTEGER         NOT NULL,
    expected_cash_with_pending  INTEGER         NOT NULL,
    actual_cash                 INTEGER         NOT NULL,
    difference_confirmed        INTEGER         NOT NULL,
    difference_with_pending     INTEGER         NOT NULL,
    is_preliminary              BOOLEAN         NOT NULL DEFAULT FALSE,
    finalized_difference        INTEGER,
    finalized_at                TIMESTAMPTZ,
    reviewed_by                 UUID            REFERENCES users(id),
    reviewed_at                 TIMESTAMPTZ,
    review_notes                TEXT,
    created_at                  TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at                  TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    CONSTRAINT expected_math CHECK (
        expected_cash_confirmed = opening_cash + confirmed_cash_sales
    ),
    CONSTRAINT difference_math CHECK (
        difference_confirmed = actual_cash - expected_cash_confirmed
    )
);

-- ============================================================
-- LAYER 9: TRANSFERS
-- ============================================================

CREATE TABLE stock_transfers (
    id                  UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    business_id         UUID            NOT NULL REFERENCES businesses(id),
    transfer_number     VARCHAR(50)     NOT NULL UNIQUE,
    from_branch_id      UUID            REFERENCES branches(id),
    from_warehouse_id   UUID            REFERENCES warehouses(id),
    to_branch_id        UUID            REFERENCES branches(id),
    to_warehouse_id     UUID            REFERENCES warehouses(id),
    status              VARCHAR(30)     NOT NULL DEFAULT 'requested'
        CHECK (status IN (
            'requested','approved','dispatched','received','confirmed','cancelled'
        )),
    requested_by        UUID            NOT NULL REFERENCES users(id),
    approved_by         UUID            REFERENCES users(id),
    dispatched_by       UUID            REFERENCES users(id),
    received_by         UUID            REFERENCES users(id),
    confirmed_by        UUID            REFERENCES users(id),
    cancelled_by        UUID            REFERENCES users(id),
    requested_at        TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    approved_at         TIMESTAMPTZ,
    dispatched_at       TIMESTAMPTZ,
    received_at         TIMESTAMPTZ,
    confirmed_at        TIMESTAMPTZ,
    cancelled_at        TIMESTAMPTZ,
    notes               TEXT,
    cancellation_reason TEXT,
    CONSTRAINT from_location_exclusive CHECK (
        (from_branch_id IS NOT NULL AND from_warehouse_id IS NULL) OR
        (from_warehouse_id IS NOT NULL AND from_branch_id IS NULL)
    ),
    CONSTRAINT to_location_exclusive CHECK (
        (to_branch_id IS NOT NULL AND to_warehouse_id IS NULL) OR
        (to_warehouse_id IS NOT NULL AND to_branch_id IS NULL)
    ),
    CONSTRAINT not_self_transfer CHECK (
        from_branch_id IS DISTINCT FROM to_branch_id OR
        from_warehouse_id IS DISTINCT FROM to_warehouse_id
    )
);


CREATE TABLE stock_transfer_items (
    id                      UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    transfer_id             UUID            NOT NULL REFERENCES stock_transfers(id),
    product_id              UUID            NOT NULL REFERENCES products(id),
    quantity_requested      NUMERIC(12,3)   NOT NULL,
    quantity_dispatched     NUMERIC(12,3),
    quantity_received       NUMERIC(12,3),
    quantity_confirmed      NUMERIC(12,3),
    dispatch_receive_variance NUMERIC(12,3)
        GENERATED ALWAYS AS (
            CASE
                WHEN quantity_dispatched IS NOT NULL AND quantity_received IS NOT NULL
                THEN quantity_received - quantity_dispatched
                ELSE NULL
            END
        ) STORED,
    notes TEXT,
    CONSTRAINT qty_req_pos CHECK (quantity_requested > 0)
);

-- ============================================================
-- LAYER 10: EXPENSES
-- ============================================================

CREATE TABLE expense_categories (
    id              UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    business_id     UUID            NOT NULL REFERENCES businesses(id),
    name            VARCHAR(100)    NOT NULL,
    description     TEXT,
    is_active       BOOLEAN         NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_expense_cat UNIQUE (business_id, name)
);


CREATE TABLE expenses (
    id                  UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    business_id         UUID            NOT NULL REFERENCES businesses(id),
    branch_id           UUID            REFERENCES branches(id),
    category_id         UUID            NOT NULL REFERENCES expense_categories(id),
    amount              INTEGER         NOT NULL,
    description         TEXT            NOT NULL,
    expense_date        DATE            NOT NULL,
    payment_method      VARCHAR(20)     NOT NULL DEFAULT 'CASH'
        CHECK (payment_method IN ('CASH','MTN_MOMO','ORANGE_MONEY','BANK_TRANSFER')),
    receipt_reference   VARCHAR(100),
    status              VARCHAR(20)     NOT NULL DEFAULT 'pending'
        CHECK (status IN ('pending','approved','rejected')),
    submitted_by        UUID            NOT NULL REFERENCES users(id),
    approved_by         UUID            REFERENCES users(id),
    approved_at         TIMESTAMPTZ,
    rejection_note      TEXT,
    is_deleted          BOOLEAN         NOT NULL DEFAULT FALSE,
    deleted_at          TIMESTAMPTZ,
    deleted_by          UUID            REFERENCES users(id),
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    CONSTRAINT amount_pos CHECK (amount > 0)
);

-- ============================================================
-- LAYER 11: FRAUD & MONITORING
-- ============================================================

CREATE TABLE fraud_rules (
    id                      UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    business_id             UUID            NOT NULL REFERENCES businesses(id),
    rule_code               VARCHAR(60)     NOT NULL
        CHECK (rule_code IN (
            'CASH_SHORTAGE',
            'PRICE_BELOW_MINIMUM',
            'EXCESS_DISCOUNT',
            'INVENTORY_MISMATCH',
            'TRANSFER_VARIANCE',
            'UNSYNCED_SHIFT_TIMEOUT',
            'EXCESSIVE_VOIDS',              -- threshold voids per shift
            'EXCESSIVE_SALE_VOIDS',         -- NEW v4: cashier void frequency
            'RAPID_SEQUENTIAL_SALES',
            'DAMAGE_REPORT_PATTERN',
            'UNAPPROVED_ADJUSTMENT',
            'REPEATED_PRICE_OVERRIDE',
            'EXCESSIVE_DISCOUNT_APPROVALS', -- NEW v4: manager approval frequency
            'FREQUENT_TERMINAL_TAKEOVERS'   -- NEW v4: suspicious device switching
        )),
    name                    VARCHAR(200)    NOT NULL,
    description             TEXT,
    threshold_value         NUMERIC(12,3),
    threshold_percentage    NUMERIC(5,2),
    alert_level             VARCHAR(20)     NOT NULL
        CHECK (alert_level IN ('low','medium','high','critical')),
    is_active               BOOLEAN         NOT NULL DEFAULT TRUE,
    created_at              TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_rule_per_business UNIQUE (business_id, rule_code)
);
-- Default seeds:
-- EXCESSIVE_SALE_VOIDS:         5 voids/24h = MEDIUM; 10 = HIGH
-- EXCESSIVE_DISCOUNT_APPROVALS: 3 approvals/shift = MEDIUM
-- FREQUENT_TERMINAL_TAKEOVERS:  2 takeovers/24h = HIGH


CREATE TABLE fraud_alerts (
    id              UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    business_id     UUID            NOT NULL REFERENCES businesses(id),
    branch_id       UUID            REFERENCES branches(id),
    rule_id         UUID            REFERENCES fraud_rules(id),
    alert_type      VARCHAR(60)     NOT NULL,
    alert_level     VARCHAR(20)     NOT NULL
        CHECK (alert_level IN ('low','medium','high','critical')),
    title           VARCHAR(200)    NOT NULL,
    description     TEXT            NOT NULL,
    reference_type  VARCHAR(50),
    reference_id    VARCHAR(100),
    triggered_by    UUID            REFERENCES users(id),
    status          VARCHAR(20)     NOT NULL DEFAULT 'open'
        CHECK (status IN ('open','acknowledged','investigating','resolved','dismissed')),
    acknowledged_by UUID            REFERENCES users(id),
    acknowledged_at TIMESTAMPTZ,
    resolved_by     UUID            REFERENCES users(id),
    resolved_at     TIMESTAMPTZ,
    resolution_notes TEXT,
    created_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

-- ============================================================
-- LAYER 12: AUDIT
-- ============================================================

CREATE TABLE audit_logs (
    id              UUID            NOT NULL DEFAULT gen_random_uuid(),
    business_id     UUID            NOT NULL REFERENCES businesses(id),
    user_id         UUID            REFERENCES users(id),
    branch_id       UUID            REFERENCES branches(id),
    session_id      UUID            REFERENCES user_sessions(id),
    action          VARCHAR(100)    NOT NULL,
    entity_type     VARCHAR(50)     NOT NULL,
    entity_id       VARCHAR(100)    NOT NULL,
    old_values      JSONB,
    new_values      JSONB,
    ip_address      INET,
    device_info     JSONB,
    created_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW()
) PARTITION BY RANGE (created_at);

CREATE TABLE audit_logs_2026_06 PARTITION OF audit_logs FOR VALUES FROM ('2026-06-01') TO ('2026-07-01');
CREATE TABLE audit_logs_2026_07 PARTITION OF audit_logs FOR VALUES FROM ('2026-07-01') TO ('2026-08-01');
CREATE TABLE audit_logs_2026_08 PARTITION OF audit_logs FOR VALUES FROM ('2026-08-01') TO ('2026-09-01');
CREATE TABLE audit_logs_2026_09 PARTITION OF audit_logs FOR VALUES FROM ('2026-09-01') TO ('2026-10-01');

-- ============================================================
-- INDEXES
-- ============================================================

-- Users
CREATE INDEX idx_users_business_role    ON users(business_id, role) WHERE is_deleted = FALSE;
CREATE INDEX idx_users_phone            ON users(phone) WHERE phone IS NOT NULL;
CREATE INDEX idx_users_email            ON users(email) WHERE email IS NOT NULL;

-- Sessions
CREATE INDEX idx_sessions_token         ON user_sessions(token_hash);
CREATE INDEX idx_sessions_user_active   ON user_sessions(user_id) WHERE is_active = TRUE;
CREATE INDEX idx_sessions_fingerprint   ON user_sessions(device_fingerprint) WHERE device_fingerprint IS NOT NULL;

-- Products
CREATE INDEX idx_products_business      ON products(business_id) WHERE is_deleted = FALSE AND is_active = TRUE;
CREATE INDEX idx_products_barcode       ON products(barcode) WHERE barcode IS NOT NULL;
CREATE INDEX idx_products_tile_type     ON products(business_id, tile_type) WHERE tile_type IS NOT NULL;

-- Inventory
CREATE INDEX idx_inv_stock_branch       ON inventory_stock(product_id, branch_id) WHERE branch_id IS NOT NULL;
CREATE INDEX idx_inv_stock_warehouse    ON inventory_stock(product_id, warehouse_id) WHERE warehouse_id IS NOT NULL;
CREATE INDEX idx_inv_movements_product  ON inventory_movements(product_id, created_at DESC);
CREATE INDEX idx_inv_movements_type     ON inventory_movements(movement_type, created_at DESC);
CREATE INDEX idx_inv_movements_ref      ON inventory_movements(reference_type, reference_id);
-- SALE_VOID specific index for fraud queries
CREATE INDEX idx_inv_movements_voids    ON inventory_movements(performed_by, movement_type, created_at DESC)
    WHERE movement_type = 'SALE_VOID';

-- Shifts
CREATE INDEX idx_shifts_branch_date     ON shifts(branch_id, started_at DESC);
CREATE INDEX idx_shifts_pending_sync    ON shifts(status, closed_at) WHERE status = 'closed_pending';

-- Sales
CREATE INDEX idx_sales_branch_date      ON sales(branch_id, created_at_device DESC);
CREATE INDEX idx_sales_shift            ON sales(shift_id);
CREATE INDEX idx_sales_sync_pending     ON sales(sync_status) WHERE sync_status = 'pending';
CREATE INDEX idx_sales_pending_payment  ON sales(status, branch_id) WHERE status = 'pending_payment';

-- Sale items
CREATE INDEX idx_sale_items_sale        ON sale_items(sale_id);
CREATE INDEX idx_sale_items_product     ON sale_items(product_id);
CREATE INDEX idx_sale_items_override    ON sale_items(is_price_override) WHERE is_price_override = TRUE;

-- Price override approvals
CREATE INDEX idx_overrides_cashier      ON price_override_approvals(cashier_id, approved_at DESC);
CREATE INDEX idx_overrides_manager      ON price_override_approvals(approved_by, approved_at DESC);
CREATE INDEX idx_overrides_unused       ON price_override_approvals(used_at) WHERE used_at IS NULL AND status = 'approved';

-- Payments
CREATE INDEX idx_payments_sale          ON payment_transactions(sale_id);
CREATE INDEX idx_payments_unconfirmed   ON payment_transactions(payment_method, is_confirmed)
    WHERE is_confirmed = FALSE AND payment_method != 'CASH';

-- Terminal takeovers
CREATE INDEX idx_takeovers_branch       ON terminal_takeovers(branch_id, created_at DESC);
CREATE INDEX idx_takeovers_approved_by  ON terminal_takeovers(approved_by, created_at DESC);

-- Transfers
CREATE INDEX idx_transfers_status       ON stock_transfers(business_id, status);
CREATE INDEX idx_transfers_variance     ON stock_transfer_items(transfer_id)
    WHERE dispatch_receive_variance != 0 AND dispatch_receive_variance IS NOT NULL;

-- Fraud alerts
CREATE INDEX idx_alerts_open            ON fraud_alerts(business_id, alert_level, status)
    WHERE status IN ('open','acknowledged','investigating');
CREATE INDEX idx_alerts_triggered_by    ON fraud_alerts(triggered_by, created_at DESC);

-- Audit logs (per partition)
CREATE INDEX idx_audit_entity_06        ON audit_logs_2026_06(entity_type, entity_id);
CREATE INDEX idx_audit_user_06          ON audit_logs_2026_06(user_id, created_at DESC);
CREATE INDEX idx_audit_business_06      ON audit_logs_2026_06(business_id, created_at DESC);

-- ============================================================
-- TABLE COUNT: 28 tables
-- UUID tables: 26 | BIGSERIAL tables: 2
-- Schema status: FINAL LOCKED
-- ============================================================
