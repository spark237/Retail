"""
RetailGuard Products — Category, Product, ProductPriceHistory

Primary domain: tiles (floor, wall, bath, outdoor).
Secondary: general retail products (non-tile fields nullable).

Unit system: stock_unit is the BASE inventory unit (default: BOX).
Cashiers can sell in PIECE, BOX, SQM, or PALLET — conversion happens at sale time.
All prices are per stock_unit in XAF (integer, never float).
"""
import uuid

from django.conf import settings
from django.db import models

from apps.core.models import QuantityField, SoftDeleteModel


class Category(models.Model):
    """Product grouping. Seeded with tile categories on business creation."""
    id          = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    business    = models.ForeignKey('branches.Business', on_delete=models.PROTECT, related_name='categories')
    name        = models.CharField(max_length=100)
    description = models.TextField(blank=True, null=True)
    is_active   = models.BooleanField(default=True)
    created_at  = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'categories'
        constraints = [
            models.UniqueConstraint(
                fields=['business', 'name'],
                name='uq_category_name_per_business',
            )
        ]

    def __str__(self):
        return f"{self.name} ({self.business_id})"


class StockUnit(models.TextChoices):
    PIECE   = 'PIECE',  'Piece'
    BOX     = 'BOX',    'Box'
    SQM     = 'SQM',    'Square Meter'
    PALLET  = 'PALLET', 'Pallet'


class Product(SoftDeleteModel):
    """
    Master product record. Tile-optimised with nullable non-tile fields.

    PRICING RULE:
      All prices are per stock_unit in XAF (integer).
      selling_price = price per 1 BOX (if stock_unit=BOX)
      min_selling_price = anti-fraud floor; server enforced on every sale + sync.
      Cashiers cannot view or override min_selling_price from the UI.

    UNIT CONVERSION:
      sqm_per_box is also used by V2 Tile Estimation Engine.
      Set at product creation; validated for internal consistency.
    """
    id              = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    business        = models.ForeignKey('branches.Business', on_delete=models.PROTECT, related_name='products')
    category        = models.ForeignKey(Category, null=True, blank=True, on_delete=models.SET_NULL, related_name='products')

    # Core identity
    name            = models.CharField(max_length=200)
    sku             = models.CharField(max_length=100, blank=True, null=True)
    barcode         = models.CharField(max_length=100, blank=True, null=True)
    description     = models.TextField(blank=True, null=True)
    brand           = models.CharField(max_length=100, blank=True, null=True)
    series_name     = models.CharField(max_length=100, blank=True, null=True)

    # Tile-specific (nullable for non-tile products)
    tile_size       = models.CharField(max_length=20, blank=True, null=True)   # '60x60', '30x60'
    tile_finish     = models.CharField(max_length=30, blank=True, null=True)   # 'matte', 'glossy'
    tile_material   = models.CharField(max_length=30, blank=True, null=True)   # 'ceramic', 'porcelain'
    tile_type       = models.CharField(max_length=20, blank=True, null=True)   # 'floor', 'wall', 'bath'
    color_description = models.CharField(max_length=100, blank=True, null=True)
    specifications  = models.JSONField(default=dict, blank=True)

    # Unit system — LOCKED: NUMERIC(12,3) via QuantityField
    stock_unit      = models.CharField(max_length=20, choices=StockUnit.choices, default=StockUnit.BOX)
    pieces_per_box  = models.DecimalField(max_digits=10, decimal_places=4, null=True, blank=True)
    sqm_per_box     = models.DecimalField(max_digits=10, decimal_places=4, null=True, blank=True)
    sqm_per_piece   = models.DecimalField(max_digits=10, decimal_places=4, null=True, blank=True)
    boxes_per_pallet = models.DecimalField(max_digits=10, decimal_places=4, null=True, blank=True)

    # Pricing — all in XAF (integer), per stock_unit
    cost_price          = models.IntegerField(default=0)
    selling_price       = models.IntegerField()
    min_selling_price   = models.IntegerField(null=True, blank=True)

    # Stock control
    reorder_level       = QuantityField(default=0)

    # Lifecycle
    is_active   = models.BooleanField(default=True)
    created_by  = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name='created_products',
    )

    class Meta:
        db_table = 'products'
        constraints = [
            models.UniqueConstraint(
                fields=['business', 'sku'],
                name='uq_sku_per_business',
                condition=models.Q(sku__isnull=False),
            ),
            models.CheckConstraint(
                condition=models.Q(selling_price__gt=0),
                name='selling_price_positive',
            ),
            models.CheckConstraint(
                condition=models.Q(cost_price__gte=0),
                name='cost_price_non_negative',
            ),
            models.CheckConstraint(
                condition=(
                    models.Q(min_selling_price__isnull=True) |
                    models.Q(min_selling_price__gt=0)
                ),
                name='min_price_positive',
            ),
            models.CheckConstraint(
                condition=(
                    models.Q(min_selling_price__isnull=True) |
                    models.Q(min_selling_price__lte=models.F('selling_price'))
                ),
                name='min_lte_selling',
            ),
        ]
        indexes = [
            models.Index(
                fields=['business', 'is_active'],
                name='idx_products_business',
                condition=models.Q(is_deleted=False, is_active=True),
            ),
            models.Index(
                fields=['tile_type'],
                name='idx_products_tile_type',
                condition=models.Q(tile_type__isnull=False),
            ),
            models.Index(
                fields=['barcode'],
                name='idx_products_barcode',
                condition=models.Q(barcode__isnull=False),
            ),
        ]

    def __str__(self):
        return f"{self.name} ({self.sku or 'no-sku'})"

    def clean(self):
        from decimal import Decimal

        from django.core.exceptions import ValidationError
        # Validate SQM internal consistency
        if all([self.sqm_per_piece, self.pieces_per_box, self.sqm_per_box]):
            computed = Decimal(str(self.sqm_per_piece)) * Decimal(str(self.pieces_per_box))
            actual = Decimal(str(self.sqm_per_box))
            if abs(computed - actual) >= Decimal('0.001'):
                raise ValidationError(
                    'sqm_per_piece × pieces_per_box must equal sqm_per_box (tolerance 0.001)'
                )


class ProductPriceHistory(models.Model):
    """
    IMMUTABLE — append-only price audit log. No UPDATE or DELETE.
    Written automatically on every price change via Product.save() signal.

    BIGSERIAL: high-volume append. Integer PK is fine — server-controlled creation only.
    """
    # BigAutoField = BIGSERIAL in PostgreSQL
    id                  = models.BigAutoField(primary_key=True)
    product             = models.ForeignKey(Product, on_delete=models.PROTECT, related_name='price_history')
    old_cost_price      = models.IntegerField(null=True)
    new_cost_price      = models.IntegerField(null=True)
    old_selling_price   = models.IntegerField(null=True)
    new_selling_price   = models.IntegerField(null=True)
    old_min_price       = models.IntegerField(null=True)
    new_min_price       = models.IntegerField(null=True)
    changed_by          = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name='price_changes',
    )
    reason              = models.TextField(blank=True, null=True)
    changed_at          = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'product_price_history'
        ordering = ['-changed_at']
        # No UPDATE, no DELETE — enforced at DB permission level in production

    def __str__(self):
        return f"{self.product.name} price change @ {self.changed_at:%Y-%m-%d %H:%M}"
