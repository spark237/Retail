"""RetailGuard Products — Serializers"""
from rest_framework import serializers

from apps.products.models import Category, Product, ProductPriceHistory


class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model  = Category
        fields = ['id', 'name', 'description', 'is_active', 'created_at']
        read_only_fields = ['id', 'created_at']


class ProductListSerializer(serializers.ModelSerializer):
    category_name = serializers.CharField(source='category.name', read_only=True, default=None)

    class Meta:
        model  = Product
        fields = [
            'id', 'name', 'sku', 'barcode', 'category_id', 'category_name',
            'brand', 'series_name', 'tile_size', 'tile_type', 'tile_finish',
            'tile_material', 'color_description',
            'stock_unit', 'sqm_per_box', 'pieces_per_box',
            'cost_price', 'selling_price', 'min_selling_price',
            'reorder_level', 'is_active', 'created_at',
        ]


class ProductDetailSerializer(ProductListSerializer):
    class Meta(ProductListSerializer.Meta):
        fields = ProductListSerializer.Meta.fields + [
            'description', 'sqm_per_piece', 'boxes_per_pallet', 'specifications',
        ]


class ProductCreateSerializer(serializers.Serializer):
    name              = serializers.CharField(max_length=200)
    sku               = serializers.CharField(max_length=100, required=False, allow_blank=True)
    barcode           = serializers.CharField(max_length=100, required=False, allow_blank=True)
    description       = serializers.CharField(required=False, allow_blank=True)
    category_id       = serializers.UUIDField(required=False, allow_null=True)
    brand             = serializers.CharField(max_length=100, required=False, allow_blank=True)
    series_name       = serializers.CharField(max_length=100, required=False, allow_blank=True)
    tile_size         = serializers.CharField(max_length=20, required=False, allow_blank=True)
    tile_finish       = serializers.CharField(max_length=30, required=False, allow_blank=True)
    tile_material     = serializers.CharField(max_length=30, required=False, allow_blank=True)
    tile_type         = serializers.CharField(max_length=20, required=False, allow_blank=True)
    color_description = serializers.CharField(max_length=100, required=False, allow_blank=True)
    stock_unit        = serializers.ChoiceField(choices=['PIECE', 'BOX', 'SQM', 'PALLET'], default='BOX')
    pieces_per_box    = serializers.DecimalField(max_digits=10, decimal_places=4, required=False, allow_null=True)
    sqm_per_box       = serializers.DecimalField(max_digits=10, decimal_places=4, required=False, allow_null=True)
    sqm_per_piece     = serializers.DecimalField(max_digits=10, decimal_places=4, required=False, allow_null=True)
    boxes_per_pallet  = serializers.DecimalField(max_digits=10, decimal_places=4, required=False, allow_null=True)
    cost_price        = serializers.IntegerField(min_value=0, default=0)
    selling_price     = serializers.IntegerField(min_value=1)
    min_selling_price = serializers.IntegerField(min_value=1, required=False, allow_null=True)
    reorder_level     = serializers.DecimalField(max_digits=12, decimal_places=3, default=0)

    def validate(self, data):
        sp = data.get('selling_price')
        mp = data.get('min_selling_price')
        if sp and mp and mp > sp:
            raise serializers.ValidationError({'min_selling_price': 'Min price cannot exceed selling price.'})
        return data


class ProductPriceUpdateSerializer(serializers.Serializer):
    selling_price     = serializers.IntegerField(min_value=1, required=False)
    min_selling_price = serializers.IntegerField(min_value=1, required=False, allow_null=True)
    cost_price        = serializers.IntegerField(min_value=0, required=False)
    reason            = serializers.CharField(min_length=5, required=True)


class PriceHistorySerializer(serializers.ModelSerializer):
    changed_by_name = serializers.CharField(source='changed_by.full_name', read_only=True)

    class Meta:
        model  = ProductPriceHistory
        fields = [
            'id', 'old_cost_price', 'new_cost_price',
            'old_selling_price', 'new_selling_price',
            'old_min_price', 'new_min_price',
            'changed_by_id', 'changed_by_name', 'reason', 'changed_at',
        ]
