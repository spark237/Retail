"""RetailGuard Products — Views"""
from rest_framework import status as http_status
from rest_framework.exceptions import NotFound
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.audit.models import AuditService
from apps.core.pagination import StandardPagination
from apps.core.permissions import IsCashierOrAbove, IsManagerOrOwner
from apps.core.utils import success_response
from apps.products.models import Category, Product, ProductPriceHistory
from apps.products.serializers import (
    CategorySerializer,
    PriceHistorySerializer,
    ProductCreateSerializer,
    ProductDetailSerializer,
    ProductListSerializer,
    ProductPriceUpdateSerializer,
)


class ProductListCreateView(APIView):
    def get_permissions(self):
        return [IsManagerOrOwner()] if self.request.method == 'POST' else [IsCashierOrAbove()]

    def get(self, request):
        qs = Product.objects.filter(
            business=request.user.business, is_deleted=False
        ).select_related('category').order_by('name')

        if is_active := request.query_params.get('is_active'):
            qs = qs.filter(is_active=is_active.lower() == 'true')
        if cat := request.query_params.get('category_id'):
            qs = qs.filter(category_id=cat)
        if tile_type := request.query_params.get('tile_type'):
            qs = qs.filter(tile_type=tile_type)
        if tile_size := request.query_params.get('tile_size'):
            qs = qs.filter(tile_size=tile_size)
        if search := request.query_params.get('search'):
            qs = qs.filter(name__icontains=search)

        paginator = StandardPagination()
        page = paginator.paginate_queryset(qs, request)
        return paginator.get_paginated_response(ProductListSerializer(page, many=True).data)

    def post(self, request):
        s = ProductCreateSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        data = s.validated_data

        category = None
        if cat_id := data.pop('category_id', None):
            try:
                category = Category.objects.get(id=cat_id, business=request.user.business)
            except Category.DoesNotExist:
                raise NotFound('Category not found.')

        product = Product.objects.create(
            business=request.user.business,
            category=category,
            created_by=request.user,
            **data,
        )
        AuditService.log(action='product.created', entity_type='product', entity_id=str(product.id),
                         business=request.user.business, new_values={'name': product.name}, request=request)
        return success_response(ProductDetailSerializer(product).data, status=201)


class ProductDetailView(APIView):
    def get_permissions(self):
        return [IsManagerOrOwner()] if self.request.method in ('PATCH', 'DELETE') else [IsCashierOrAbove()]

    def _get_product(self, request, product_id):
        try:
            return Product.objects.get(id=product_id, business=request.user.business, is_deleted=False)
        except Product.DoesNotExist:
            raise NotFound('Product not found.')

    def get(self, request, product_id):
        return success_response(ProductDetailSerializer(self._get_product(request, product_id)).data)

    def patch(self, request, product_id):
        product = self._get_product(request, product_id)
        price_fields = {'selling_price', 'min_selling_price', 'cost_price'}
        is_price_update = bool(price_fields & set(request.data.keys()))

        if is_price_update:
            s = ProductPriceUpdateSerializer(data=request.data)
            s.is_valid(raise_exception=True)
            data = s.validated_data

            # Write price history before updating
            ProductPriceHistory.objects.create(
                product=product,
                old_cost_price=product.cost_price,
                new_cost_price=data.get('cost_price', product.cost_price),
                old_selling_price=product.selling_price,
                new_selling_price=data.get('selling_price', product.selling_price),
                old_min_price=product.min_selling_price,
                new_min_price=data.get('min_selling_price', product.min_selling_price),
                changed_by=request.user,
                reason=data['reason'],
            )
            for field in ('cost_price', 'selling_price', 'min_selling_price'):
                if field in data:
                    setattr(product, field, data[field])
            product.save()
            AuditService.log(action='product.price_changed', entity_type='product', entity_id=str(product.id),
                             business=request.user.business, request=request)
        else:
            s = ProductCreateSerializer(data=request.data, partial=True)
            s.is_valid(raise_exception=True)
            for field, value in s.validated_data.items():
                setattr(product, field, value)
            product.save()

        return success_response(ProductDetailSerializer(product).data)

    def delete(self, request, product_id):
        product = self._get_product(request, product_id)
        from apps.inventory.models import InventoryStock
        if InventoryStock.objects.filter(product=product, quantity__gt=0).exists():
            from apps.core.exceptions import RetailGuardException
            raise RetailGuardException(detail='Cannot archive product with active stock.', code='PRODUCT_HAS_ACTIVE_STOCK')
        product.soft_delete(deleted_by_user=request.user)
        return Response(status=http_status.HTTP_204_NO_CONTENT)


class ProductPriceHistoryView(APIView):
    permission_classes = [IsManagerOrOwner]

    def get(self, request, product_id):
        try:
            product = Product.objects.get(id=product_id, business=request.user.business)
        except Product.DoesNotExist:
            raise NotFound('Product not found.')
        history = product.price_history.select_related('changed_by').order_by('-changed_at')
        return success_response(PriceHistorySerializer(history, many=True).data)


class CategoryListCreateView(APIView):
    def get_permissions(self):
        return [IsManagerOrOwner()] if self.request.method == 'POST' else [IsCashierOrAbove()]

    def get(self, request):
        qs = Category.objects.filter(business=request.user.business, is_active=True)
        return success_response(CategorySerializer(qs, many=True).data)

    def post(self, request):
        s = CategorySerializer(data=request.data)
        s.is_valid(raise_exception=True)
        cat = Category.objects.create(business=request.user.business, **s.validated_data)
        return success_response(CategorySerializer(cat).data, status=201)


class CategoryDetailView(APIView):
    permission_classes = [IsManagerOrOwner]

    def patch(self, request, category_id):
        try:
            cat = Category.objects.get(id=category_id, business=request.user.business)
        except Category.DoesNotExist:
            raise NotFound('Category not found.')
        s = CategorySerializer(cat, data=request.data, partial=True)
        s.is_valid(raise_exception=True)
        s.save()
        return success_response(CategorySerializer(cat).data)
