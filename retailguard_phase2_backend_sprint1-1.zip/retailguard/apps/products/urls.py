from django.urls import path

from apps.products.views import (
    CategoryDetailView,
    CategoryListCreateView,
    ProductDetailView,
    ProductListCreateView,
    ProductPriceHistoryView,
)

urlpatterns = [
    path('',                                     ProductListCreateView.as_view(),  name='product-list'),
    path('<uuid:product_id>/',                   ProductDetailView.as_view(),      name='product-detail'),
    path('<uuid:product_id>/price-history/',     ProductPriceHistoryView.as_view(), name='product-price-history'),
    path('categories/',                          CategoryListCreateView.as_view(), name='category-list'),
    path('categories/<uuid:category_id>/',       CategoryDetailView.as_view(),     name='category-detail'),
]
