from django.urls import path

from apps.sales.views import (
    PaymentConfirmView,
    PriceOverrideApproveView,
    PriceOverrideRejectView,
    PriceOverrideRequestView,
    SaleCreateListView,
    SaleDetailView,
    SaleReceiptView,
    SaleVoidView,
    SyncBatchDetailView,
    SyncSalesView,
)

urlpatterns = [
    path('',                                              SaleCreateListView.as_view(),         name='sale-list'),
    path('<uuid:sale_id>/',                               SaleDetailView.as_view(),             name='sale-detail'),
    path('<uuid:sale_id>/receipt/',                       SaleReceiptView.as_view(),            name='sale-receipt'),
    path('<uuid:sale_id>/void/',                          SaleVoidView.as_view(),               name='sale-void'),
    path('price-approvals/request/',                      PriceOverrideRequestView.as_view(),   name='price-approval-request'),
    path('price-approvals/<uuid:approval_id>/approve/',   PriceOverrideApproveView.as_view(),  name='price-approval-approve'),
    path('price-approvals/<uuid:approval_id>/reject/',    PriceOverrideRejectView.as_view(),   name='price-approval-reject'),
    path('payments/<uuid:payment_id>/confirm/',           PaymentConfirmView.as_view(),         name='payment-confirm'),
    path('sync/',                                         SyncSalesView.as_view(),              name='sync-sales'),
    path('sync/batches/<uuid:batch_id>/',                 SyncBatchDetailView.as_view(),        name='sync-batch-detail'),
]
