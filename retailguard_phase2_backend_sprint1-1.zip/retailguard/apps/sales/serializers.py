"""
RetailGuard Sales — Serializers

SaleCreateSerializer: handles both online and sync-path sale creation.
Validates stock, prices, payments, and override approvals before
passing to SaleService.create_sale().
"""
from decimal import Decimal

from django.utils import timezone
from rest_framework import serializers

from apps.products.models import Product
from apps.sales.models import (
    PaymentMethod,
    PaymentTransaction,
    PriceOverrideApproval,
    Sale,
    SaleItem,
)

# ─── NESTED SERIALIZERS ───────────────────────────────────────────────────────

class SaleItemReadSerializer(serializers.ModelSerializer):
    class Meta:
        model = SaleItem
        fields = [
            'id', 'product_id', 'product_name', 'product_sku', 'tile_size',
            'unit_sold', 'quantity_sold', 'stock_unit_snapshot',
            'quantity_in_stock_unit', 'unit_price', 'discount_amount',
            'total_price', 'is_price_override', 'override_approval_id',
        ]


class PaymentTransactionReadSerializer(serializers.ModelSerializer):
    class Meta:
        model = PaymentTransaction
        fields = [
            'id', 'payment_method', 'amount', 'reference_number',
            'is_confirmed', 'confirmed_at',
        ]


class SaleItemWriteSerializer(serializers.Serializer):
    product_id              = serializers.UUIDField()
    unit_sold               = serializers.ChoiceField(choices=['PIECE', 'BOX', 'SQM', 'PALLET'])
    quantity_sold           = serializers.DecimalField(max_digits=12, decimal_places=3, min_value=Decimal('0.001'))
    unit_price              = serializers.IntegerField(min_value=1)
    discount_amount         = serializers.IntegerField(min_value=0, default=0)
    override_approval_id    = serializers.UUIDField(required=False, allow_null=True)

    def validate_product_id(self, value):
        try:
            return Product.objects.get(id=value, is_active=True, is_deleted=False)
        except Product.DoesNotExist:
            raise serializers.ValidationError(f'Product {value} not found or inactive.')


class PaymentWriteSerializer(serializers.Serializer):
    payment_method      = serializers.ChoiceField(choices=PaymentMethod.choices)
    amount              = serializers.IntegerField(min_value=1)
    reference_number    = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    is_confirmed        = serializers.BooleanField(default=False)

    def validate(self, data):
        method = data.get('payment_method')
        ref = data.get('reference_number')
        confirmed = data.get('is_confirmed', False)
        # Cash auto-confirms, no reference needed
        if method == PaymentMethod.CASH:
            data['is_confirmed'] = True
            data['reference_number'] = None
        # Non-cash: reference required when confirming
        elif confirmed and not ref:
            raise serializers.ValidationError(
                {'reference_number': 'Reference number required when confirming non-cash payment.'}
            )
        return data


# ─── MAIN SERIALIZERS ─────────────────────────────────────────────────────────

class SaleCreateSerializer(serializers.Serializer):
    """
    Used for both online sale creation and sync-path processing.
    Validates structure only — stock/price validation happens in SaleService.
    """
    id                  = serializers.UUIDField(help_text='Client-generated UUID. Must be unique.')
    shift_id            = serializers.UUIDField()
    created_at_device   = serializers.DateTimeField()
    notes               = serializers.CharField(required=False, allow_blank=True, default='')
    items               = SaleItemWriteSerializer(many=True, min_length=1)
    payments            = PaymentWriteSerializer(many=True, min_length=1)

    def validate_created_at_device(self, value):
        # Reject device times more than 24h in the future (clock manipulation)
        if value > timezone.now().replace(tzinfo=value.tzinfo) and \
           (value - timezone.now()).total_seconds() > 86400:
            raise serializers.ValidationError(
                'Device timestamp is too far in the future. Check device clock.'
            )
        return value

    def validate_items(self, value):
        if not value:
            raise serializers.ValidationError('Sale must contain at least one item.')
        return value

    def validate_payments(self, value):
        if not value:
            raise serializers.ValidationError('Sale must contain at least one payment.')
        return value


class SaleVoidSerializer(serializers.Serializer):
    void_reason = serializers.CharField(min_length=5, max_length=500)


class SaleReadSerializer(serializers.ModelSerializer):
    items       = SaleItemReadSerializer(many=True, read_only=True)
    payments    = PaymentTransactionReadSerializer(many=True, read_only=True)
    cashier_name = serializers.SerializerMethodField()

    class Meta:
        model = Sale
        fields = [
            'id', 'receipt_number', 'branch_id', 'shift_id',
            'cashier_id', 'cashier_name',
            'subtotal', 'discount_amount', 'total_amount',
            'status', 'approval_required',
            'void_reason', 'voided_by_id', 'voided_at',
            'sync_status', 'sync_rejection_reason',
            'created_at_device', 'synced_at', 'notes',
            'items', 'payments',
        ]

    def get_cashier_name(self, obj):
        return obj.cashier.full_name


class SaleListSerializer(serializers.ModelSerializer):
    """Lightweight list view — no nested items."""
    cashier_name = serializers.SerializerMethodField()

    class Meta:
        model = Sale
        fields = [
            'id', 'receipt_number', 'branch_id', 'cashier_id', 'cashier_name',
            'total_amount', 'status', 'sync_status', 'approval_required',
            'created_at_device', 'synced_at',
        ]

    def get_cashier_name(self, obj):
        return obj.cashier.full_name


# ─── PRICE OVERRIDE SERIALIZERS ───────────────────────────────────────────────

class PriceOverrideRequestSerializer(serializers.Serializer):
    product_id      = serializers.UUIDField()
    branch_id       = serializers.UUIDField()
    requested_price = serializers.IntegerField(min_value=1)
    reason          = serializers.CharField(min_length=10)


class PriceOverrideApproveSerializer(serializers.Serializer):
    approval_method = serializers.ChoiceField(choices=['pin', 'password', 're_auth'])
    credential      = serializers.CharField(write_only=True)
    approved_price  = serializers.IntegerField(min_value=1)


class PriceOverrideReadSerializer(serializers.ModelSerializer):
    is_valid = serializers.ReadOnlyField()

    class Meta:
        model = PriceOverrideApproval
        fields = [
            'id', 'product_id', 'branch_id', 'cashier_id', 'approved_by_id',
            'requested_price', 'selling_price_at_time', 'min_price_at_time',
            'reason', 'status', 'approved_at', 'expires_at', 'used_at',
            'is_valid',
        ]


# ─── PAYMENT CONFIRMATION SERIALIZER ─────────────────────────────────────────

class PaymentConfirmSerializer(serializers.Serializer):
    reference_number    = serializers.CharField(min_length=3)
    notes               = serializers.CharField(required=False, allow_blank=True)


# ─── SYNC BATCH SERIALIZER ────────────────────────────────────────────────────

class SyncUploadSerializer(serializers.Serializer):
    """Wraps a batch of offline sales for upload."""
    shift_id    = serializers.UUIDField()
    sales       = SaleCreateSerializer(many=True, min_length=1, max_length=500)
