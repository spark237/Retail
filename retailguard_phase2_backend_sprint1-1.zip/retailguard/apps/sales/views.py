"""
RetailGuard Sales — Views

POST /sales/          Create sale (online path)
GET  /sales/          List sales
GET  /sales/{id}/     Get sale detail
GET  /sales/{id}/receipt/  Receipt data
POST /sales/{id}/void/     Void sale (manager+)
POST /sales/price-approvals/request/    Request override
POST /sales/price-approvals/{id}/approve/
POST /sales/price-approvals/{id}/reject/
POST /payments/{id}/confirm/
POST /sync/sales/     Upload offline batch
GET  /sync/batches/{id}/
"""
from django.utils import timezone
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.audit.models import AuditService
from apps.branches.models import Branch
from apps.core.exceptions import (
    DuplicateSaleError,
    InsufficientStockError,
    NoActiveShiftError,
)
from apps.core.pagination import StandardPagination
from apps.core.permissions import CanApproveDiscount, IsCashierOrAbove, IsManagerOrOwner
from apps.core.utils import generate_receipt_number, success_response
from apps.fraud.services import FraudDetectionService
from apps.sales.models import PaymentTransaction, PriceOverrideApproval, Sale, SyncStatus
from apps.sales.serializers import (
    PaymentConfirmSerializer,
    PriceOverrideApproveSerializer,
    PriceOverrideReadSerializer,
    PriceOverrideRequestSerializer,
    SaleCreateSerializer,
    SaleListSerializer,
    SaleReadSerializer,
    SaleVoidSerializer,
    SyncUploadSerializer,
)
from apps.sales.services import SaleService
from apps.shifts.models import Shift, SyncBatch


class SaleCreateListView(APIView):
    """
    POST /sales/    Create a single sale (online path)
    GET  /sales/    List sales (scoped by role/branch)
    """
    permission_classes = [IsCashierOrAbove]

    def post(self, request):
        serializer = SaleCreateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data

        user = request.user
        branch = self._get_branch(user, data)

        # Resolve product objects from validated item data
        items_data = []
        for item in data['items']:
            items_data.append({
                'product': item['product_id'],  # already resolved to Product by serializer
                'unit_sold': item['unit_sold'],
                'quantity_sold': item['quantity_sold'],
                'unit_price': item['unit_price'],
                'discount_amount': item.get('discount_amount', 0),
                'override_approval_id': item.get('override_approval_id'),
            })

        sale = SaleService.create_sale(
            cashier=user,
            branch=branch,
            shift_id=data['shift_id'],
            sale_uuid=data['id'],
            items_data=items_data,
            payments_data=data['payments'],
            created_at_device=data['created_at_device'],
            notes=data.get('notes', ''),
        )

        # Assign receipt number post-creation
        if not sale.receipt_number:
            branch.refresh_from_db()
            day_count = Sale.objects.filter(
                branch=branch,
                synced_at__date=timezone.now().date(),
            ).count()
            sale.receipt_number = generate_receipt_number(branch.code, day_count)
            sale.save(update_fields=['receipt_number'])

        AuditService.log(
            action='sale.created',
            entity_type='sale',
            entity_id=str(sale.id),
            business=sale.business,
            branch=sale.branch,
            new_values={'total_amount': sale.total_amount, 'status': sale.status},
            request=request,
        )

        # Async fraud checks
        FraudDetectionService.check_after_sale(sale)

        return Response(
            {'success': True, 'data': SaleReadSerializer(sale).data},
            status=status.HTTP_201_CREATED,
        )

    def get(self, request):
        qs = Sale.objects.select_related('cashier', 'branch', 'shift').order_by('-created_at_device')

        # Scope by role
        if request.user.role not in ('owner',):
            branch_ids = list(
                request.user.branch_assignments.filter(
                    revoked_at__isnull=True, branch_id__isnull=False
                ).values_list('branch_id', flat=True)
            )
            qs = qs.filter(branch_id__in=branch_ids)

        # Filters
        if branch_id := request.query_params.get('branch_id'):
            qs = qs.filter(branch_id=branch_id)
        if shift_id := request.query_params.get('shift_id'):
            qs = qs.filter(shift_id=shift_id)
        if cashier_id := request.query_params.get('cashier_id'):
            qs = qs.filter(cashier_id=cashier_id)
        if sale_status := request.query_params.get('status'):
            qs = qs.filter(status=sale_status)
        if sync_status := request.query_params.get('sync_status'):
            qs = qs.filter(sync_status=sync_status)
        if from_date := request.query_params.get('from_date'):
            qs = qs.filter(created_at_device__date__gte=from_date)
        if to_date := request.query_params.get('to_date'):
            qs = qs.filter(created_at_device__date__lte=to_date)

        paginator = StandardPagination()
        page = paginator.paginate_queryset(qs, request)
        return paginator.get_paginated_response(SaleListSerializer(page, many=True).data)

    def _get_branch(self, user, data):
        """Resolve branch from user's assignment or explicit branch context in shift."""
        from apps.shifts.models import Shift
        try:
            shift = Shift.objects.get(id=data['shift_id'])
            return shift.branch
        except Shift.DoesNotExist:
            raise NoActiveShiftError()


class SaleDetailView(APIView):
    permission_classes = [IsCashierOrAbove]

    def get(self, request, sale_id):
        sale = self._get_sale(request, sale_id)
        return success_response(SaleReadSerializer(sale).data)

    def _get_sale(self, request, sale_id):
        from rest_framework.exceptions import NotFound
        try:
            sale = Sale.objects.select_related('cashier', 'branch').prefetch_related(
                'items', 'payments'
            ).get(id=sale_id)
        except Sale.DoesNotExist:
            raise NotFound('Sale not found.')
        # Scope check
        if request.user.role != 'owner':
            branch_ids = list(
                request.user.branch_assignments.filter(
                    revoked_at__isnull=True, branch_id__isnull=False
                ).values_list('branch_id', flat=True)
            )
            if str(sale.branch_id) not in [str(b) for b in branch_ids]:
                raise NotFound('Sale not found.')
        return sale


class SaleReceiptView(SaleDetailView):
    def get(self, request, sale_id):
        sale = self._get_sale(request, sale_id)
        data = {
            'receipt_number': sale.receipt_number,
            'business_name': sale.business.name,
            'branch_name': sale.branch.name,
            'cashier_name': sale.cashier.full_name,
            'date': sale.created_at_device,
            'items': SaleReadSerializer(sale).data['items'],
            'subtotal': sale.subtotal,
            'discount_amount': sale.discount_amount,
            'total_amount': sale.total_amount,
            'payments': SaleReadSerializer(sale).data['payments'],
        }
        return success_response(data)


class SaleVoidView(APIView):
    permission_classes = [IsManagerOrOwner]

    def post(self, request, sale_id):
        from rest_framework.exceptions import NotFound
        try:
            sale = Sale.objects.get(id=sale_id)
        except Sale.DoesNotExist:
            raise NotFound('Sale not found.')

        serializer = SaleVoidSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        old_status = sale.status
        sale = SaleService.void_sale(
            sale=sale,
            voided_by=request.user,
            void_reason=serializer.validated_data['void_reason'],
        )

        AuditService.log(
            action='sale.voided',
            entity_type='sale',
            entity_id=str(sale.id),
            business=sale.business,
            branch=sale.branch,
            old_values={'status': old_status},
            new_values={'status': 'voided', 'void_reason': sale.void_reason},
            request=request,
        )

        FraudDetectionService.check_after_void(sale)

        return success_response({
            'id': str(sale.id),
            'status': sale.status,
            'voided_by': request.user.full_name,
            'voided_at': sale.voided_at,
            'inventory_restored': True,
        })


# ─── PRICE OVERRIDE VIEWS ─────────────────────────────────────────────────────

class PriceOverrideRequestView(APIView):
    permission_classes = [IsCashierOrAbove]

    def post(self, request):
        from apps.products.models import Product

        serializer = PriceOverrideRequestSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data

        try:
            product = Product.objects.get(id=data['product_id'])
            branch = Branch.objects.get(id=data['branch_id'])
        except (Product.DoesNotExist, Branch.DoesNotExist):
            from rest_framework.exceptions import NotFound
            raise NotFound('Product or branch not found.')

        approval = PriceOverrideApproval.objects.create(
            product=product,
            branch=branch,
            cashier=request.user,
            requested_price=data['requested_price'],
            selling_price_at_time=product.selling_price,
            min_price_at_time=product.min_selling_price or 0,
            reason=data['reason'],
            status='pending',
            expires_at=timezone.now() + timezone.timedelta(minutes=30),
        )

        return Response(
            {'success': True, 'data': PriceOverrideReadSerializer(approval).data},
            status=status.HTTP_201_CREATED,
        )


class PriceOverrideApproveView(APIView):
    permission_classes = [CanApproveDiscount]

    def post(self, request, approval_id):
        from rest_framework.exceptions import NotFound
        try:
            approval = PriceOverrideApproval.objects.get(id=approval_id, status='pending')
        except PriceOverrideApproval.DoesNotExist:
            raise NotFound('Approval request not found or already processed.')

        serializer = PriceOverrideApproveSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data

        # Validate credential
        user = request.user
        if data['approval_method'] == 'pin':
            if not user.verify_override_pin(data['credential']):
                from apps.core.exceptions import RetailGuardException
                raise RetailGuardException(detail='Invalid override PIN.', code='INVALID_CREDENTIALS')
        else:
            if not user.check_password(data['credential']):
                from apps.core.exceptions import RetailGuardException
                raise RetailGuardException(detail='Invalid password.', code='INVALID_CREDENTIALS')

        # Self-approval check
        if approval.cashier_id == user.id:
            from apps.core.exceptions import RetailGuardException
            raise RetailGuardException(
                detail='You cannot approve your own price override request.',
                code='SELF_APPROVAL_FORBIDDEN',
            )

        approval.approved_by = user
        approval.approved_price = data['approved_price']
        approval.status = 'approved'
        approval.approved_at = timezone.now()
        approval.save(update_fields=['approved_by', 'status', 'approved_at'])

        AuditService.log(
            action='approval.price_override_granted',
            entity_type='price_override_approval',
            entity_id=str(approval.id),
            business=approval.branch.business,
            branch=approval.branch,
            new_values={'approved_price': data['approved_price'], 'approved_by': str(user.id)},
            request=request,
        )

        FraudDetectionService.check_after_price_override(approval)

        return success_response(PriceOverrideReadSerializer(approval).data)


class PriceOverrideRejectView(APIView):
    permission_classes = [CanApproveDiscount]

    def post(self, request, approval_id):
        from rest_framework.exceptions import NotFound
        try:
            approval = PriceOverrideApproval.objects.get(id=approval_id, status='pending')
        except PriceOverrideApproval.DoesNotExist:
            raise NotFound('Approval not found.')

        approval.status = 'rejected'
        approval.save(update_fields=['status'])

        return success_response({'id': str(approval.id), 'status': 'rejected'})


# ─── PAYMENT CONFIRMATION ─────────────────────────────────────────────────────

class PaymentConfirmView(APIView):
    permission_classes = [IsManagerOrOwner]

    def post(self, request, payment_id):
        from rest_framework.exceptions import NotFound
        try:
            payment = PaymentTransaction.objects.select_related('sale').get(id=payment_id)
        except PaymentTransaction.DoesNotExist:
            raise NotFound('Payment not found.')

        if payment.payment_method == 'CASH':
            from apps.core.exceptions import RetailGuardException
            raise RetailGuardException(detail='Cash payments are auto-confirmed.', code='INVALID_OPERATION')

        serializer = PaymentConfirmSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        payment.is_confirmed = True
        payment.reference_number = serializer.validated_data['reference_number']
        payment.confirmed_by = request.user
        payment.confirmed_at = timezone.now()
        payment.save(update_fields=['is_confirmed', 'reference_number', 'confirmed_by', 'confirmed_at'])

        # Check if all non-cash payments are now confirmed → update sale status
        sale = payment.sale
        unconfirmed = sale.payments.filter(is_confirmed=False).exclude(payment_method='CASH').count()
        if unconfirmed == 0 and sale.status == 'pending_payment':
            sale.status = 'completed'
            sale.save(update_fields=['status', 'updated_at'])

        return success_response({
            'id': str(payment.id),
            'is_confirmed': True,
            'confirmed_at': payment.confirmed_at,
            'sale_status': sale.status,
        })


# ─── OFFLINE SYNC ─────────────────────────────────────────────────────────────

class SyncSalesView(APIView):
    """
    POST /sync/sales/

    Processes a batch of offline-recorded sales.
    Each sale is processed independently — partial success is valid.
    Returns per-record results with accept/reject/conflict status.
    """
    permission_classes = [IsCashierOrAbove]

    def post(self, request):
        serializer = SyncUploadSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data

        try:
            shift = Shift.objects.get(id=data['shift_id'], cashier=request.user)
        except Shift.DoesNotExist:
            from rest_framework.exceptions import NotFound
            raise NotFound('Shift not found.')

        batch = SyncBatch.objects.create(
            shift=shift,
            cashier=request.user,
            device_info=request.data.get('device_info', {}),
            records_submitted=len(data['sales']),
        )

        results = []
        accepted = rejected = conflict = 0

        for sale_data in data['sales']:
            result = self._process_single_sale(sale_data, shift, request.user, batch)
            results.append(result)
            if result['status'] == 'accepted':
                accepted += 1
            elif result['status'] == 'conflict':
                conflict += 1
            else:
                rejected += 1

        # Update batch totals
        batch.records_accepted = accepted
        batch.records_rejected = rejected
        batch.records_conflict = conflict
        batch.completed_at = timezone.now()
        batch.status = (
            'completed' if rejected == 0 and conflict == 0
            else 'partial' if accepted > 0
            else 'failed'
        )
        batch.save()

        # Check if shift is now fully synced
        shift_update = self._maybe_finalize_shift(shift)

        return success_response({
            'batch_id': str(batch.id),
            'records_submitted': batch.records_submitted,
            'records_accepted': accepted,
            'records_rejected': rejected,
            'records_conflict': conflict,
            'status': batch.status,
            'results': results,
            'shift_updated': shift_update,
        })

    def _process_single_sale(self, sale_data, shift, cashier, batch):
        """Process one sale from the batch. Returns result dict."""
        sale_id = sale_data['id']
        try:
            items_data = [
                {
                    'product': item['product_id'],
                    'unit_sold': item['unit_sold'],
                    'quantity_sold': item['quantity_sold'],
                    'unit_price': item['unit_price'],
                    'discount_amount': item.get('discount_amount', 0),
                    'override_approval_id': item.get('override_approval_id'),
                }
                for item in sale_data['items']
            ]
            sale = SaleService.create_sale(
                cashier=cashier,
                branch=shift.branch,
                shift_id=shift.id,
                sale_uuid=sale_id,
                items_data=items_data,
                payments_data=sale_data['payments'],
                created_at_device=sale_data['created_at_device'],
                notes=sale_data.get('notes', ''),
                sync_batch=batch,
            )
            # Assign receipt number
            day_count = Sale.objects.filter(
                branch=shift.branch,
                synced_at__date=timezone.now().date(),
            ).count()
            sale.receipt_number = generate_receipt_number(shift.branch.code, day_count)
            sale.save(update_fields=['receipt_number'])

            return {
                'sale_id': str(sale_id),
                'status': 'accepted',
                'receipt_number': sale.receipt_number,
                'inventory_deducted': True,
            }

        except DuplicateSaleError:
            # Idempotent — already synced
            existing = Sale.objects.filter(id=sale_id).first()
            if existing and existing.sync_status == SyncStatus.SYNCED:
                return {'sale_id': str(sale_id), 'status': 'accepted', 'receipt_number': existing.receipt_number, 'inventory_deducted': False}
            return {'sale_id': str(sale_id), 'status': 'rejected', 'reason': 'DUPLICATE_SALE_ID', 'details': {}}

        except InsufficientStockError as e:
            Sale.objects.filter(id=sale_id).update(
                sync_status=SyncStatus.CONFLICT,
                sync_rejection_reason='INSUFFICIENT_STOCK',
                sync_batch=batch,
            )
            return {'sale_id': str(sale_id), 'status': 'conflict', 'reason': 'INSUFFICIENT_STOCK', 'details': e.extra}

        except Exception as e:
            return {'sale_id': str(sale_id), 'status': 'rejected', 'reason': str(type(e).__name__), 'details': {'message': str(e)}}

    def _maybe_finalize_shift(self, shift):
        """If all sales are synced, upgrade shift status and finalize reconciliation."""
        pending_count = Sale.objects.filter(shift=shift, sync_status='pending').count()
        if pending_count == 0 and shift.status == 'closed_pending':
            shift.status = 'closed_synced'
            shift.sync_completed_at = timezone.now()
            shift.save(update_fields=['status', 'sync_completed_at', 'updated_at'])

            if hasattr(shift, 'reconciliation'):
                shift.reconciliation.finalize()

            return {
                'shift_id': str(shift.id),
                'new_status': 'closed_synced',
                'reconciliation_finalized': True,
            }
        return None


class SyncBatchDetailView(APIView):
    permission_classes = [IsCashierOrAbove]

    def get(self, request, batch_id):
        from rest_framework.exceptions import NotFound
        try:
            batch = SyncBatch.objects.get(id=batch_id)
        except SyncBatch.DoesNotExist:
            raise NotFound('Sync batch not found.')
        return success_response({
            'id': str(batch.id),
            'status': batch.status,
            'records_submitted': batch.records_submitted,
            'records_accepted': batch.records_accepted,
            'records_rejected': batch.records_rejected,
            'records_conflict': batch.records_conflict,
            'submitted_at': batch.submitted_at,
            'completed_at': batch.completed_at,
        })
