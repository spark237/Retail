"""
RetailGuard Sales — Sale Service (Business Logic Layer)

This module contains the atomic transaction logic for sale creation and voiding.
Views are thin — all business rules live here.

ATOMIC SALE COMMIT (7 steps, all-or-nothing):
  1. SELECT FOR UPDATE on all stock rows (prevents concurrent overselling)
  2. Validate stock availability
  3. Validate price overrides
  4. Validate payment total
  5. Create Sale + SaleItems + PaymentTransactions
  6. Deduct InventoryStock (per product)
  7. Create InventoryMovement records (SALE type)
  → COMMIT or full ROLLBACK

VOID FLOW:
  1. Verify sale is voided-eligible (not already voided)
  2. Create SALE_VOID inventory movements (restores stock)
  3. Update sale.status = voided
  → All in one transaction
"""
from decimal import Decimal

from django.db import transaction
from django.utils import timezone

from apps.core.exceptions import (
    ApprovalInvalidError,
    DuplicateSaleError,
    InsufficientStockError,
    InvalidPaymentTotalError,
    ManagerApprovalRequiredError,
    NoActiveShiftError,
    SaleAlreadyVoidedError,
)
from apps.core.utils import (
    compute_total_price,
    convert_to_stock_unit,
)
from apps.inventory.models import InventoryMovement, InventoryStock, MovementType
from apps.sales.models import PaymentTransaction, PriceOverrideApproval, Sale, SaleItem, SaleStatus, SyncStatus
from apps.shifts.models import Shift


class SaleService:

    @staticmethod
    @transaction.atomic
    def create_sale(*, cashier, branch, shift_id, sale_uuid, items_data, payments_data,
                    created_at_device, notes='', sync_batch=None) -> Sale:
        """
        Atomic sale creation.
        Called for both online sales and sync-uploaded offline sales.

        Args:
            cashier:            User instance
            branch:             Branch instance
            shift_id:           UUID of the open shift
            sale_uuid:          Client-generated UUID (idempotent sync key)
            items_data:         list of dicts {product, unit_sold, quantity_sold, unit_price,
                                               discount_amount, override_approval_id}
            payments_data:      list of dicts {payment_method, amount, reference_number}
            created_at_device:  datetime from device
            notes:              optional string
            sync_batch:         SyncBatch instance (offline sync path only)

        Returns:
            Sale instance (fully created, inventory already deducted)

        Raises:
            DuplicateSaleError              if sale_uuid already synced
            NoActiveShiftError              if no open shift found
            InsufficientStockError          if branch stock < requested
            ManagerApprovalRequiredError    if price below min with no approval
            ApprovalInvalidError            if approval expired/used/wrong sale
            InvalidPaymentTotalError        if payments don't sum to total
            PaymentUnconfirmedError         if non-cash unconfirmed (online path only)
        """
        # ── IDEMPOTENCY CHECK ─────────────────────────────────────────────
        existing = Sale.objects.filter(id=sale_uuid).first()
        if existing:
            if existing.sync_status == SyncStatus.SYNCED:
                return existing  # Safe retry — return already-processed sale
            raise DuplicateSaleError(
                extra={'sale_id': str(sale_uuid), 'existing_status': existing.sync_status}
            )

        # ── SHIFT VALIDATION ──────────────────────────────────────────────
        try:
            shift = Shift.objects.get(id=shift_id, branch=branch, status='open')
        except Shift.DoesNotExist:
            raise NoActiveShiftError(
                extra={'branch_id': str(branch.id), 'shift_id': str(shift_id)}
            )

        # ── RESOLVE PRODUCTS AND QUANTITIES ───────────────────────────────
        resolved_items = []
        for item_data in items_data:
            product = item_data['product']
            unit_sold = item_data['unit_sold']
            quantity_sold = Decimal(str(item_data['quantity_sold']))
            unit_price = int(item_data['unit_price'])
            discount = int(item_data.get('discount_amount', 0))
            override_approval_id = item_data.get('override_approval_id')

            # Convert to stock unit
            qty_in_stock_unit = convert_to_stock_unit(quantity_sold, unit_sold, product)
            total_price = compute_total_price(unit_price, qty_in_stock_unit) - discount

            resolved_items.append({
                'product': product,
                'unit_sold': unit_sold,
                'quantity_sold': quantity_sold,
                'qty_in_stock_unit': qty_in_stock_unit,
                'unit_price': unit_price,
                'discount_amount': discount,
                'total_price': total_price,
                'override_approval_id': override_approval_id,
            })

        # ── STEP 1: LOCK ALL STOCK ROWS ───────────────────────────────────
        product_ids = [item['product'].id for item in resolved_items]
        stock_map = {
            s.product_id: s
            for s in InventoryStock.objects.select_for_update().filter(
                product_id__in=product_ids,
                branch=branch,
            )
        }

        # ── STEP 2: STOCK AVAILABILITY CHECK ─────────────────────────────
        for item in resolved_items:
            product = item['product']
            stock = stock_map.get(product.id)
            available = stock.quantity if stock else Decimal('0')
            if available < item['qty_in_stock_unit']:
                raise InsufficientStockError(
                    extra={
                        'product_id': str(product.id),
                        'product_name': product.name,
                        'available': str(available),
                        'requested': str(item['qty_in_stock_unit']),
                        'unit': product.stock_unit,
                    }
                )

        # ── STEP 3: PRICE OVERRIDE VALIDATION ────────────────────────────
        approval_required = False
        for item in resolved_items:
            product = item['product']
            if product.min_selling_price and item['unit_price'] < product.min_selling_price:
                override_id = item.get('override_approval_id')
                if not override_id:
                    raise ManagerApprovalRequiredError(
                        extra={
                            'product_id': str(product.id),
                            'product_name': product.name,
                            'min_selling_price': product.min_selling_price,
                            'requested_price': item['unit_price'],
                        }
                    )
                # Validate approval
                try:
                    approval = PriceOverrideApproval.objects.get(id=override_id)
                except PriceOverrideApproval.DoesNotExist:
                    raise ApprovalInvalidError(
                        extra={'override_approval_id': str(override_id)}
                    )
                if not approval.is_valid:
                    raise ApprovalInvalidError(
                        extra={
                            'override_approval_id': str(override_id),
                            'status': approval.status,
                            'expired': approval.expires_at < timezone.now() if approval.expires_at else False,
                            'already_used': approval.used_at is not None,
                        }
                    )
                item['override_approval'] = approval
                approval_required = True
            else:
                item['override_approval'] = None

        # ── STEP 4: PAYMENT VALIDATION ────────────────────────────────────
        subtotal = sum(item['total_price'] for item in resolved_items)
        discount_total = sum(item['discount_amount'] for item in resolved_items)
        total_amount = subtotal  # discount already applied per-item
        payment_total = sum(int(p['amount']) for p in payments_data)
        if payment_total != total_amount:
            raise InvalidPaymentTotalError(
                extra={
                    'sale_total': total_amount,
                    'payments_total': payment_total,
                    'difference': payment_total - total_amount,
                }
            )

        # Online path: check if any non-cash payment is unconfirmed
        has_unconfirmed_noncash = any(
            p['payment_method'] != 'CASH' and not p.get('is_confirmed', False)
            for p in payments_data
        )
        sale_status = SaleStatus.PENDING_PAYMENT if has_unconfirmed_noncash else SaleStatus.COMPLETED

        # ── STEP 5: CREATE SALE ───────────────────────────────────────────
        sale = Sale.objects.create(
            id=sale_uuid,
            business=branch.business,
            branch=branch,
            shift=shift,
            cashier=cashier,
            subtotal=subtotal,
            discount_amount=discount_total,
            total_amount=total_amount,
            status=sale_status,
            approval_required=approval_required,
            sync_status=SyncStatus.SYNCED,
            sync_batch=sync_batch,
            created_at_device=created_at_device,
            synced_at=timezone.now(),
            notes=notes,
        )

        # ── STEP 6: CREATE SALE ITEMS ─────────────────────────────────────
        for item in resolved_items:
            product = item['product']
            override = item.get('override_approval')
            SaleItem.objects.create(
                sale=sale,
                product=product,
                product_name=product.name,
                product_sku=product.sku,
                tile_size=product.tile_size,
                unit_sold=item['unit_sold'],
                quantity_sold=item['quantity_sold'],
                stock_unit_snapshot=product.stock_unit,
                quantity_in_stock_unit=item['qty_in_stock_unit'],
                unit_price=item['unit_price'],
                discount_amount=item['discount_amount'],
                total_price=item['total_price'],
                is_price_override=override is not None,
                override_approval=override,
            )
            # Mark approval as used
            if override:
                override.used_at = timezone.now()
                override.sale = sale
                override.save(update_fields=['used_at', 'sale'])

        # ── STEP 7a: CREATE PAYMENT TRANSACTIONS ─────────────────────────
        for p_data in payments_data:
            PaymentTransaction.objects.create(
                sale=sale,
                payment_method=p_data['payment_method'],
                amount=int(p_data['amount']),
                reference_number=p_data.get('reference_number'),
                is_confirmed=p_data['payment_method'] == 'CASH' or p_data.get('is_confirmed', False),
            )

        # ── STEP 7b: DEDUCT INVENTORY + CREATE MOVEMENTS ─────────────────
        for item in resolved_items:
            product = item['product']
            stock = stock_map[product.id]
            qty_before = stock.quantity
            qty_change = -item['qty_in_stock_unit']
            qty_after = qty_before + qty_change

            # Deduct stock (CHECK quantity >= 0 fires here as final safeguard)
            stock.quantity = qty_after
            stock.updated_at = timezone.now()
            stock.save(update_fields=['quantity', 'updated_at'])

            # Immutable movement record
            InventoryMovement.objects.create(
                business=branch.business,
                product=product,
                branch=branch,
                movement_type=MovementType.SALE,
                quantity_before=qty_before,
                quantity_change=qty_change,
                quantity_after=qty_after,
                reference_type='sale',
                reference_id=str(sale.id),
                performed_by=cashier,
            )

        return sale

    @staticmethod
    @transaction.atomic
    def void_sale(*, sale, voided_by, void_reason) -> Sale:
        """
        Void a sale and restore inventory via SALE_VOID movements.
        Only manager/owner can void — enforced at view permission layer.

        SALE_VOID is a distinct movement type (not ADJUSTMENT).
        This keeps fraud analytics clean:
          SELECT cashier_id, COUNT(*) FROM inventory_movements
          WHERE movement_type='SALE_VOID' GROUP BY cashier_id
        """
        if sale.status == SaleStatus.VOIDED:
            raise SaleAlreadyVoidedError(extra={'sale_id': str(sale.id)})

        movements_created = []

        # Lock and restore stock for each item
        item_ids = list(sale.items.values_list('product_id', flat=True))
        stock_map = {
            s.product_id: s
            for s in InventoryStock.objects.select_for_update().filter(
                product_id__in=item_ids,
                branch=sale.branch,
            )
        }

        for item in sale.items.all():
            stock = stock_map.get(item.product_id)
            if not stock:
                # Edge case: stock record deleted. Create it with the restored quantity.
                stock = InventoryStock.objects.create(
                    product_id=item.product_id,
                    branch=sale.branch,
                    quantity=Decimal('0'),
                )

            qty_before = stock.quantity
            qty_change = item.quantity_in_stock_unit   # positive — restoring stock
            qty_after = qty_before + qty_change

            stock.quantity = qty_after
            stock.updated_at = timezone.now()
            stock.save(update_fields=['quantity', 'updated_at'])

            movement = InventoryMovement.objects.create(
                business=sale.business,
                product_id=item.product_id,
                branch=sale.branch,
                movement_type=MovementType.SALE_VOID,
                quantity_before=qty_before,
                quantity_change=qty_change,
                quantity_after=qty_after,
                reference_type='sale',
                reference_id=str(sale.id),
                notes=f"Void: {void_reason}",
                performed_by=voided_by,
            )
            movements_created.append(movement)

        # Mark sale as voided
        sale.status = SaleStatus.VOIDED
        sale.void_reason = void_reason
        sale.voided_by = voided_by
        sale.voided_at = timezone.now()
        sale.save(update_fields=[
            'status', 'void_reason', 'voided_by', 'voided_at', 'updated_at'
        ])

        return sale
