"""
RetailGuard Sales — PriceOverrideApproval, Sale, SaleItem, PaymentTransaction

KEY RULES (all locked):
  1. Sale UUID generated on device — enables offline idempotent sync
  2. Atomic: sale + items + payments + stock deduction = one transaction or nothing
  3. Non-cash payments require is_confirmed=True before sale.status = 'completed'
  4. price overrides require valid, non-expired, unused PriceOverrideApproval
  5. sales.status = 'pending_payment' when any non-cash payment is unconfirmed
  6. Void creates SALE_VOID movement (not ADJUSTMENT) — clean fraud analytics
"""
import uuid

from django.conf import settings
from django.db import models

from apps.core.models import QuantityField, TimestampedModel


class PriceOverrideApproval(models.Model):
    """
    Manager approval for selling below min_selling_price.

    FRAUD CONTROLS:
      - cashier_id != approved_by enforced at DB level (self_approval_forbidden)
      - expires_at: approval must be used within 30 minutes
      - used_at + sale_id: prevents replay (one approval, one sale, one item)
      - selling_price_at_time + min_price_at_time: immutable snapshot;
        product price changes later don't alter what was approved

    FRAUD RULES triggered:
      REPEATED_PRICE_OVERRIDE:     cashier exceeds threshold per shift
      EXCESSIVE_DISCOUNT_APPROVALS: manager approves too many per day
    """
    id                      = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    product                 = models.ForeignKey('products.Product', on_delete=models.PROTECT, related_name='price_overrides')
    branch                  = models.ForeignKey('branches.Branch', on_delete=models.PROTECT, related_name='price_overrides')
    cashier                 = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name='requested_overrides',
    )
    approved_by             = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name='granted_overrides',
        null=True, blank=True,
    )
    requested_price         = models.IntegerField()
    selling_price_at_time   = models.IntegerField()
    min_price_at_time       = models.IntegerField()
    reason                  = models.TextField()
    status                  = models.CharField(
        max_length=20,
        choices=[('pending', 'Pending'), ('approved', 'Approved'), ('rejected', 'Rejected')],
        default='pending',
    )
    approved_at             = models.DateTimeField(null=True, blank=True)
    expires_at              = models.DateTimeField(null=True, blank=True)
    used_at                 = models.DateTimeField(null=True, blank=True)
    sale                    = models.ForeignKey(
        'sales.Sale', null=True, blank=True,
        on_delete=models.SET_NULL,
        related_name='price_approvals',
    )
    requested_at            = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'price_override_approvals'
        constraints = [
            models.CheckConstraint(
                condition=~models.Q(cashier=models.F('approved_by')),
                name='self_approval_forbidden',
            ),
            models.CheckConstraint(
                condition=models.Q(requested_price__gt=0),
                name='override_requested_price_pos',
            ),
        ]
        indexes = [
            models.Index(fields=['cashier', '-requested_at'], name='idx_overrides_cashier'),
            models.Index(fields=['approved_by', '-approved_at'], name='idx_overrides_manager'),
            models.Index(
                fields=['used_at', 'status'],
                name='idx_overrides_unused',
                condition=models.Q(used_at__isnull=True, status='approved'),
            ),
        ]

    def __str__(self):
        return f"Override: {self.cashier.full_name} → {self.requested_price} XAF [{self.status}]"

    @property
    def is_valid(self):
        """True if approved, not expired, and not used."""
        from django.utils import timezone
        return (
            self.status == 'approved' and
            self.used_at is None and
            (self.expires_at is None or self.expires_at > timezone.now())
        )


class SaleStatus(models.TextChoices):
    COMPLETED       = 'completed',       'Completed'
    PENDING_PAYMENT = 'pending_payment', 'Pending Payment Confirmation'  # v4 NEW
    VOIDED          = 'voided',          'Voided'


class SyncStatus(models.TextChoices):
    PENDING   = 'pending',   'Pending Sync'
    SYNCED    = 'synced',    'Synced'
    CONFLICT  = 'conflict',  'Conflict'
    REJECTED  = 'rejected',  'Rejected'


class Sale(TimestampedModel):
    """
    Sale header. UUID PK generated on device before sync.

    IDEMPOTENT SYNC:
      If server receives a sale UUID that already exists with status=synced,
      return success without re-processing (network retry safe).

    PENDING_PAYMENT STATUS (v4):
      When any non-cash payment has is_confirmed=False, sale.status = pending_payment.
      Inventory IS deducted (tiles left the store physically).
      Status transitions to completed only when all non-cash payments confirmed.
      This prevents the fake-screenshot momo scam.

    VOID:
      Only manager/owner can void.
      Creates SALE_VOID movement for each item (not ADJUSTMENT).
      void_reason is mandatory — enforced at serializer level.
    """
    id              = models.UUIDField(primary_key=True, editable=False)  # client-generated
    business        = models.ForeignKey('branches.Business', on_delete=models.PROTECT, related_name='sales')
    branch          = models.ForeignKey('branches.Branch', on_delete=models.PROTECT, related_name='sales')
    shift           = models.ForeignKey('shifts.Shift', on_delete=models.PROTECT, related_name='sales')
    cashier         = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name='sales',
    )
    receipt_number      = models.CharField(max_length=50, unique=True, null=True, blank=True)
    subtotal            = models.IntegerField()
    discount_amount     = models.IntegerField(default=0)
    total_amount        = models.IntegerField()
    status              = models.CharField(max_length=30, choices=SaleStatus.choices, default=SaleStatus.COMPLETED)
    void_reason         = models.TextField(blank=True, null=True)
    voided_by           = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True, blank=True,
        on_delete=models.PROTECT,
        related_name='voided_sales',
    )
    voided_at           = models.DateTimeField(null=True, blank=True)
    approval_required   = models.BooleanField(default=False)
    sync_status         = models.CharField(max_length=20, choices=SyncStatus.choices, default=SyncStatus.PENDING)
    sync_batch          = models.ForeignKey(
        'shifts.SyncBatch', null=True, blank=True,
        on_delete=models.SET_NULL,
        related_name='sales',
    )
    sync_rejection_reason = models.TextField(blank=True, null=True)
    created_at_device   = models.DateTimeField()  # device local time; may differ from created_at
    synced_at           = models.DateTimeField(null=True, blank=True)
    notes               = models.TextField(blank=True, null=True)

    class Meta:
        db_table = 'sales'
        ordering = ['-created_at_device']
        constraints = [
            models.CheckConstraint(condition=models.Q(total_amount__gt=0),    name='sale_total_pos'),
            models.CheckConstraint(condition=models.Q(subtotal__gt=0),        name='sale_subtotal_pos'),
            models.CheckConstraint(condition=models.Q(discount_amount__gte=0), name='sale_discount_nn'),
        ]
        indexes = [
            models.Index(fields=['branch', '-created_at_device'], name='idx_sales_branch_date'),
            models.Index(fields=['shift'],                         name='idx_sales_shift'),
            models.Index(fields=['cashier', '-created_at_device'], name='idx_sales_cashier_date'),
            models.Index(
                fields=['sync_status'],
                name='idx_sales_sync_pending',
                condition=models.Q(sync_status='pending'),
            ),
            models.Index(
                fields=['status', 'branch'],
                name='idx_sales_pending_payment',
                condition=models.Q(status='pending_payment'),
            ),
        ]

    def __str__(self):
        return f"Sale {self.receipt_number or self.id} — {self.total_amount} XAF [{self.status}]"

    def clean(self):
        from django.core.exceptions import ValidationError
        if self.total_amount != self.subtotal - self.discount_amount:
            raise ValidationError('total_amount must equal subtotal - discount_amount')


class SaleItem(models.Model):
    """
    Line item within a sale. Snapshots product data at time of sale.
    Snapshot fields (product_name, product_sku, tile_size, unit_price) are
    immutable records of what was actually sold — survive product edits.

    quantity_in_stock_unit: pre-computed conversion from unit_sold to stock_unit.
    This is the value deducted from inventory_stock and recorded in inventory_movements.
    """
    id                      = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    sale                    = models.ForeignKey(Sale, on_delete=models.PROTECT, related_name='items')
    product                 = models.ForeignKey('products.Product', on_delete=models.PROTECT, related_name='sale_items')

    # Snapshots — historical truth, not live product data
    product_name            = models.CharField(max_length=200)
    product_sku             = models.CharField(max_length=100, blank=True, null=True)
    tile_size               = models.CharField(max_length=20, blank=True, null=True)

    # Unit-aware quantity
    unit_sold               = models.CharField(max_length=20, choices=[
        (u, u) for u in ['PIECE', 'BOX', 'SQM', 'PALLET']
    ])
    quantity_sold           = QuantityField()                  # in unit_sold
    stock_unit_snapshot     = models.CharField(max_length=20)  # product.stock_unit at sale time
    quantity_in_stock_unit  = QuantityField()                  # used for inventory deduction

    # Pricing — snapshot at time of sale
    unit_price              = models.IntegerField()            # XAF per stock_unit
    discount_amount         = models.IntegerField(default=0)
    total_price             = models.IntegerField()

    # Price override tracking
    is_price_override       = models.BooleanField(default=False)
    override_approval       = models.ForeignKey(
        PriceOverrideApproval,
        null=True, blank=True,
        on_delete=models.PROTECT,
        related_name='sale_items',
    )

    class Meta:
        db_table = 'sale_items'
        constraints = [
            models.CheckConstraint(condition=models.Q(quantity_sold__gt=0),          name='item_qty_sold_pos'),
            models.CheckConstraint(condition=models.Q(quantity_in_stock_unit__gt=0), name='item_stock_qty_pos'),
            models.CheckConstraint(condition=models.Q(unit_price__gt=0),             name='item_unit_price_pos'),
            models.CheckConstraint(condition=models.Q(total_price__gt=0),            name='item_total_price_pos'),
        ]
        indexes = [
            models.Index(fields=['sale'],    name='idx_sale_items_sale'),
            models.Index(fields=['product'], name='idx_sale_items_product'),
            models.Index(
                fields=['is_price_override'],
                name='idx_sale_items_override',
                condition=models.Q(is_price_override=True),
            ),
        ]

    def __str__(self):
        return f"{self.product_name} × {self.quantity_sold} {self.unit_sold} = {self.total_price} XAF"


class PaymentMethod(models.TextChoices):
    CASH            = 'CASH',           'Cash'
    MTN_MOMO        = 'MTN_MOMO',       'MTN Mobile Money'
    ORANGE_MONEY    = 'ORANGE_MONEY',   'Orange Money'
    BANK_TRANSFER   = 'BANK_TRANSFER',  'Bank Transfer'


class PaymentTransaction(models.Model):
    """
    One or more payments per sale (split payment supported).
    SUM(amount) must equal sale.total_amount — enforced at service layer.

    STRICT CONFIRMATION RULE (v4, Cameroon-specific):
      Any non-CASH payment with is_confirmed=False keeps sale in 'pending_payment'.
      Prevents fake-screenshot mobile money fraud:
        - Customer shows fake momo screenshot
        - Cashier releases goods
        - Business never receives payment

    Cash: auto-confirmed at creation (is_confirmed=True, no reference needed).
    MTN_MOMO/ORANGE_MONEY: requires manual confirmation with reference_number.
    """
    id                  = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    sale                = models.ForeignKey(Sale, on_delete=models.PROTECT, related_name='payments')
    payment_method      = models.CharField(max_length=20, choices=PaymentMethod.choices)
    amount              = models.IntegerField()                   # XAF
    reference_number    = models.CharField(max_length=100, blank=True, null=True)
    provider_response   = models.JSONField(default=dict, blank=True)  # future API slot
    is_confirmed        = models.BooleanField(default=False)
    confirmed_at        = models.DateTimeField(null=True, blank=True)
    confirmed_by        = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True, blank=True,
        on_delete=models.PROTECT,
        related_name='confirmed_payments',
    )
    created_at          = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'payment_transactions'
        constraints = [
            models.CheckConstraint(condition=models.Q(amount__gt=0), name='payment_amount_pos'),
        ]
        indexes = [
            models.Index(fields=['sale'],             name='idx_payments_sale'),
            models.Index(fields=['payment_method', '-created_at'], name='idx_payments_method'),
            models.Index(
                fields=['payment_method', 'is_confirmed'],
                name='idx_payments_unconfirmed',
                condition=models.Q(is_confirmed=False, payment_method__in=['MTN_MOMO', 'ORANGE_MONEY', 'BANK_TRANSFER']),
            ),
        ]

    def __str__(self):
        confirmed = '✓' if self.is_confirmed else '⏳'
        return f"{confirmed} {self.payment_method}: {self.amount} XAF"

    def save(self, *args, **kwargs):
        # Cash is always auto-confirmed
        if self.payment_method == PaymentMethod.CASH and not self.is_confirmed:
            self.is_confirmed = True
        super().save(*args, **kwargs)
