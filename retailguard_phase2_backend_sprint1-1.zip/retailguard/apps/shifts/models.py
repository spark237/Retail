"""
RetailGuard Shifts — Shift, Attendance

CRITICAL CONSTRAINT:
  ONE open shift per branch — enforced by DB partial unique index.
  No application logic can create two open shifts at the same branch.
  This is the database enforcement of the single-terminal-per-branch rule.

SHIFT STATUS FLOW:
  open → closed_pending   (unsynced offline sales remain)
  open → closed_synced    (all sales were online; synced immediately)
  open → force_closed     (terminal takeover; manager override)
  closed_pending → closed_synced    (after sync_batch completes)
  closed_pending → closed_conflict  (sync completed but conflicts found)
"""
import uuid

from django.conf import settings
from django.db import models

from apps.core.models import TimestampedModel


class ShiftStatus(models.TextChoices):
    OPEN             = 'open',             'Open'
    CLOSED_PENDING   = 'closed_pending',   'Closed — Pending Sync'
    CLOSED_SYNCED    = 'closed_synced',    'Closed — Synced'
    CLOSED_CONFLICT  = 'closed_conflict',  'Closed — Conflict'
    FORCE_CLOSED     = 'force_closed',     'Force Closed'


class Shift(TimestampedModel):
    """
    Represents one cashier's working session at a branch.

    opening_cash: float given to cashier at start (used in reconciliation formula)
    unsynced_alert_sent: prevents duplicate fraud alerts for same unsynced shift

    DB constraint: Only ONE row with status='open' per branch_id.
    Implemented as a partial unique index (cannot be expressed as Django constraint).
    See Migration: migrations.RunSQL for the index.
    """
    id              = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    business        = models.ForeignKey('branches.Business', on_delete=models.PROTECT, related_name='shifts')
    branch          = models.ForeignKey('branches.Branch', on_delete=models.PROTECT, related_name='shifts')
    cashier         = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name='shifts',
    )
    status          = models.CharField(max_length=30, choices=ShiftStatus.choices, default=ShiftStatus.OPEN)
    opening_cash    = models.IntegerField(default=0)  # XAF integer
    started_at      = models.DateTimeField(auto_now_add=True)
    closed_at       = models.DateTimeField(null=True, blank=True)
    sync_completed_at   = models.DateTimeField(null=True, blank=True)
    unsynced_alert_sent = models.BooleanField(default=False)

    # Force-close metadata (populated on terminal takeover)
    is_force_closed     = models.BooleanField(default=False)
    force_closed_by     = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True, blank=True,
        on_delete=models.PROTECT,
        related_name='force_closed_shifts',
    )
    force_closed_at     = models.DateTimeField(null=True, blank=True)
    force_close_reason  = models.TextField(blank=True, null=True)
    notes               = models.TextField(blank=True, null=True)

    class Meta:
        db_table = 'shifts'
        ordering = ['-started_at']
        indexes = [
            models.Index(fields=['branch', '-started_at'], name='idx_shifts_branch_date'),
            models.Index(fields=['cashier', 'status'],     name='idx_shifts_cashier_status'),
            models.Index(
                fields=['status', 'closed_at'],
                name='idx_shifts_pending_sync',
                condition=models.Q(status='closed_pending'),
            ),
        ]

    def __str__(self):
        return f"Shift #{self.id} — {self.cashier.full_name} @ {self.branch.name} [{self.status}]"

    @property
    def is_open(self):
        return self.status == ShiftStatus.OPEN

    @property
    def has_pending_sales(self):
        return self.sales.filter(sync_status='pending').exists()

    @property
    def pending_sale_count(self):
        return self.sales.filter(sync_status='pending').count()


class Attendance(models.Model):
    """Staff attendance records. Created automatically on shift open/close."""
    class AttendanceStatus(models.TextChoices):
        PRESENT  = 'present',  'Present'
        LATE     = 'late',     'Late'
        HALF_DAY = 'half_day', 'Half Day'
        ABSENT   = 'absent',   'Absent'

    id          = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user        = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name='attendance')
    branch      = models.ForeignKey('branches.Branch', on_delete=models.PROTECT, related_name='attendance')
    shift       = models.ForeignKey(Shift, null=True, blank=True, on_delete=models.SET_NULL, related_name='attendance')
    check_in_at     = models.DateTimeField(auto_now_add=True)
    check_out_at    = models.DateTimeField(null=True, blank=True)
    status          = models.CharField(
        max_length=20,
        choices=AttendanceStatus.choices,
        default=AttendanceStatus.PRESENT,
    )
    notes   = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'attendance'
        ordering = ['-check_in_at']

    def __str__(self):
        return f"{self.user.full_name} @ {self.branch.name} — {self.check_in_at.date()}"


class SyncBatch(models.Model):
    """
    Tracks each offline sync upload from a device.
    One batch per sync attempt. Each sale links back to its batch.
    Used to detect stuck syncs and diagnose partial failures.
    """
    class BatchStatus(models.TextChoices):
        PROCESSING = 'processing', 'Processing'
        COMPLETED  = 'completed',  'Completed'
        PARTIAL    = 'partial',    'Partial'
        FAILED     = 'failed',     'Failed'

    id                  = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    shift               = models.ForeignKey(Shift, on_delete=models.PROTECT, related_name='sync_batches')
    cashier             = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name='sync_batches')
    device_info         = models.JSONField(default=dict, blank=True)
    records_submitted   = models.IntegerField(default=0)
    records_accepted    = models.IntegerField(default=0)
    records_rejected    = models.IntegerField(default=0)
    records_conflict    = models.IntegerField(default=0)
    status              = models.CharField(max_length=20, choices=BatchStatus.choices, default=BatchStatus.PROCESSING)
    submitted_at        = models.DateTimeField(auto_now_add=True)
    completed_at        = models.DateTimeField(null=True, blank=True)
    error_detail        = models.TextField(blank=True, null=True)

    class Meta:
        db_table = 'sync_batches'
        ordering = ['-submitted_at']

    def __str__(self):
        return f"Sync batch {self.id} — {self.status} ({self.records_accepted}/{self.records_submitted})"
