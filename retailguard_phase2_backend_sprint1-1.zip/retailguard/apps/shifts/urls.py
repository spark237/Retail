from django.urls import path

from apps.shifts.views import (
    AttendanceCheckInView,
    AttendanceCheckOutView,
    AttendanceListView,
    ShiftActiveView,
    ShiftCloseView,
    ShiftListView,
    ShiftOpenView,
)

urlpatterns = [
    path('',                          ShiftListView.as_view(),      name='shift-list'),
    path('open/',                     ShiftOpenView.as_view(),      name='shift-open'),
    path('active/',                   ShiftActiveView.as_view(),    name='shift-active'),
    path('<uuid:shift_id>/close/',    ShiftCloseView.as_view(),     name='shift-close'),
    path('attendance/check-in/',      AttendanceCheckInView.as_view(),  name='attendance-checkin'),
    path('attendance/check-out/',     AttendanceCheckOutView.as_view(), name='attendance-checkout'),
    path('attendance/',               AttendanceListView.as_view(), name='attendance-list'),
]
