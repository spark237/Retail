"""RetailGuard Shifts — Views"""
from django.db import IntegrityError, transaction
from django.db.models import Sum
from django.utils import timezone
from rest_framework.exceptions import NotFound
from rest_framework.views import APIView

from apps.audit.models import AuditService
from apps.branches.models import Branch
from apps.core.exceptions import ShiftAlreadyOpenError
from apps.core.pagination import StandardPagination
from apps.core.permissions import IsAnyActiveStaff, IsCashierOrAbove, IsManagerOrOwner
from apps.core.utils import success_response
from apps.reconciliation.models import CashReconciliation
from apps.sales.models import PaymentTransaction, Sale, SaleStatus
from apps.shifts.models import Attendance, Shift, ShiftStatus
from apps.shifts.serializers import AttendanceSerializer, ShiftCloseSerializer, ShiftOpenSerializer, ShiftSerializer


class ShiftOpenView(APIView):
    permission_classes = [IsCashierOrAbove]

    @transaction.atomic
    def post(self, request):
        s = ShiftOpenSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        data = s.validated_data

        try:
            branch = Branch.objects.get(id=data['branch_id'], business=request.user.business)
        except Branch.DoesNotExist:
            raise NotFound('Branch not found.')

        try:
            shift = Shift.objects.create(
                business=request.user.business,
                branch=branch,
                cashier=request.user,
                opening_cash=data['opening_cash'],
                status=ShiftStatus.OPEN,
            )
        except IntegrityError:
            raise ShiftAlreadyOpenError(
                extra={'branch_id': str(branch.id), 'branch_name': branch.name}
            )

        Attendance.objects.create(user=request.user, branch=branch, shift=shift)
        AuditService.log(
            action='shift.opened', entity_type='shift', entity_id=str(shift.id),
            business=request.user.business, branch=branch, request=request,
        )
        return success_response(ShiftSerializer(shift).data, status=201)


class ShiftActiveView(APIView):
    permission_classes = [IsCashierOrAbove]

    def get(self, request):
        shift = Shift.objects.filter(
            cashier=request.user, status=ShiftStatus.OPEN
        ).select_related('branch', 'cashier').first()

        if not shift:
            raise NotFound('No active shift.')

        data = ShiftSerializer(shift).data
        confirmed_rev = (
            Sale.objects.filter(
                shift=shift, sync_status='synced',
                status__in=[SaleStatus.COMPLETED, SaleStatus.PENDING_PAYMENT],
            ).aggregate(total=Sum('total_amount'))['total'] or 0
        )
        pending_rev = (
            Sale.objects.filter(shift=shift, sync_status='pending')
            .aggregate(total=Sum('total_amount'))['total'] or 0
        )
        data['confirmed_revenue']        = confirmed_rev
        data['pending_revenue_estimate'] = pending_rev
        return success_response(data)


class ShiftCloseView(APIView):
    permission_classes = [IsCashierOrAbove]

    @transaction.atomic
    def post(self, request, shift_id):
        try:
            shift = Shift.objects.select_for_update().get(
                id=shift_id, business=request.user.business, status=ShiftStatus.OPEN,
            )
        except Shift.DoesNotExist:
            raise NotFound('Open shift not found.')

        s = ShiftCloseSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        actual_cash = s.validated_data['actual_cash']

        confirmed_cash = (
            PaymentTransaction.objects.filter(
                sale__shift=shift, sale__sync_status='synced',
                payment_method='CASH', is_confirmed=True,
            ).aggregate(t=Sum('amount'))['t'] or 0
        )
        pending_cash = (
            PaymentTransaction.objects.filter(
                sale__shift=shift, sale__sync_status='pending', payment_method='CASH',
            ).aggregate(t=Sum('amount'))['t'] or 0
        )

        has_pending = shift.pending_sale_count > 0
        new_status  = ShiftStatus.CLOSED_PENDING if has_pending else ShiftStatus.CLOSED_SYNCED

        shift.status    = new_status
        shift.closed_at = timezone.now()
        shift.notes     = s.validated_data.get('notes', '')
        shift.save(update_fields=['status', 'closed_at', 'notes', 'updated_at'])

        Attendance.objects.filter(
            shift=shift, check_out_at__isnull=True
        ).update(check_out_at=timezone.now())

        expected_confirmed = shift.opening_cash + confirmed_cash
        recon = CashReconciliation.objects.create(
            shift=shift, branch=shift.branch, cashier=shift.cashier,
            opening_cash=shift.opening_cash,
            confirmed_cash_sales=confirmed_cash,
            pending_cash_sales=pending_cash,
            expected_cash_confirmed=expected_confirmed,
            expected_cash_with_pending=expected_confirmed + pending_cash,
            actual_cash=actual_cash,
            difference_confirmed=actual_cash - expected_confirmed,
            difference_with_pending=actual_cash - (expected_confirmed + pending_cash),
            is_preliminary=has_pending,
        )

        from apps.fraud.services import FraudDetectionService
        FraudDetectionService.check_after_shift_close(recon)

        AuditService.log(
            action='shift.closed', entity_type='shift', entity_id=str(shift.id),
            business=request.user.business, branch=shift.branch, request=request,
        )
        return success_response({
            'shift_id': str(shift.id),
            'status': new_status,
            'reconciliation': {
                'opening_cash':            recon.opening_cash,
                'confirmed_cash_sales':    recon.confirmed_cash_sales,
                'pending_cash_sales':      recon.pending_cash_sales,
                'expected_cash_confirmed': recon.expected_cash_confirmed,
                'actual_cash':             recon.actual_cash,
                'difference_confirmed':    recon.difference_confirmed,
                'is_preliminary':          recon.is_preliminary,
            },
            'unsynced_sales': shift.pending_sale_count,
            'warning': 'PRELIMINARY — unsynced sales pending' if has_pending else None,
        })


class ShiftListView(APIView):
    permission_classes = [IsCashierOrAbove]

    def get(self, request):
        qs = Shift.objects.filter(
            business=request.user.business
        ).select_related('cashier', 'branch').order_by('-started_at')

        if request.user.role not in ('owner', 'manager'):
            qs = qs.filter(cashier=request.user)
        if bid := request.query_params.get('branch_id'):
            qs = qs.filter(branch_id=bid)
        if st := request.query_params.get('status'):
            qs = qs.filter(status=st)
        if cid := request.query_params.get('cashier_id'):
            qs = qs.filter(cashier_id=cid)
        if from_dt := request.query_params.get('from_date'):
            qs = qs.filter(started_at__date__gte=from_dt)
        if to_dt := request.query_params.get('to_date'):
            qs = qs.filter(started_at__date__lte=to_dt)

        paginator = StandardPagination()
        page = paginator.paginate_queryset(qs, request)
        return paginator.get_paginated_response(ShiftSerializer(page, many=True).data)


class AttendanceCheckInView(APIView):
    permission_classes = [IsAnyActiveStaff]

    def post(self, request):
        branch_id = request.data.get('branch_id')
        shift_id  = request.data.get('shift_id')
        try:
            branch = Branch.objects.get(id=branch_id, business=request.user.business)
        except Branch.DoesNotExist:
            raise NotFound('Branch not found.')
        shift = Shift.objects.filter(id=shift_id).first() if shift_id else None
        att   = Attendance.objects.create(user=request.user, branch=branch, shift=shift)
        return success_response(AttendanceSerializer(att).data, status=201)


class AttendanceCheckOutView(APIView):
    permission_classes = [IsAnyActiveStaff]

    def post(self, request):
        att = Attendance.objects.filter(
            user=request.user, check_out_at__isnull=True
        ).last()
        if not att:
            raise NotFound('No open attendance record found.')
        att.check_out_at = timezone.now()
        att.save(update_fields=['check_out_at'])
        return success_response(AttendanceSerializer(att).data)


class AttendanceListView(APIView):
    permission_classes = [IsManagerOrOwner]

    def get(self, request):
        qs = Attendance.objects.filter(
            branch__business=request.user.business
        ).select_related('user', 'branch').order_by('-check_in_at')

        if request.user.role != 'owner':
            branch_ids = list(
                request.user.branch_assignments
                .filter(revoked_at__isnull=True, branch_id__isnull=False)
                .values_list('branch_id', flat=True)
            )
            qs = qs.filter(branch_id__in=branch_ids)
        if bid := request.query_params.get('branch_id'):
            qs = qs.filter(branch_id=bid)
        if uid := request.query_params.get('user_id'):
            qs = qs.filter(user_id=uid)
        if dt := request.query_params.get('date'):
            qs = qs.filter(check_in_at__date=dt)

        paginator = StandardPagination()
        page = paginator.paginate_queryset(qs, request)
        return paginator.get_paginated_response(AttendanceSerializer(page, many=True).data)
