"""RetailGuard Shifts — Serializers, Views, URLs"""
# ─── SERIALIZERS ─────────────────────────────────────────────────────────────
from rest_framework import serializers

from apps.shifts.models import Attendance, Shift


class ShiftSerializer(serializers.ModelSerializer):
    cashier_name     = serializers.CharField(source='cashier.full_name', read_only=True)
    branch_name      = serializers.CharField(source='branch.name', read_only=True)
    pending_sales    = serializers.IntegerField(source='pending_sale_count', read_only=True)

    class Meta:
        model  = Shift
        fields = [
            'id', 'branch_id', 'branch_name', 'cashier_id', 'cashier_name',
            'status', 'opening_cash', 'started_at', 'closed_at',
            'sync_completed_at', 'is_force_closed', 'force_close_reason',
            'pending_sales', 'notes',
        ]


class ShiftOpenSerializer(serializers.Serializer):
    branch_id    = serializers.UUIDField()
    opening_cash = serializers.IntegerField(min_value=0, default=0)


class ShiftCloseSerializer(serializers.Serializer):
    actual_cash = serializers.IntegerField(min_value=0)
    notes       = serializers.CharField(required=False, allow_blank=True)


class AttendanceSerializer(serializers.ModelSerializer):
    user_name  = serializers.CharField(source='user.full_name', read_only=True)
    branch_name = serializers.CharField(source='branch.name', read_only=True)

    class Meta:
        model  = Attendance
        fields = ['id', 'user_id', 'user_name', 'branch_id', 'branch_name',
                  'shift_id', 'check_in_at', 'check_out_at', 'status', 'notes']
