"""RetailGuard Transfers — Serializers"""
from decimal import Decimal

from rest_framework import serializers

from apps.transfers.models import StockTransfer, StockTransferItem


class TransferItemSerializer(serializers.ModelSerializer):
    product_name              = serializers.CharField(source='product.name',       read_only=True)
    dispatch_receive_variance = serializers.ReadOnlyField()
    has_variance              = serializers.ReadOnlyField()

    class Meta:
        model  = StockTransferItem
        fields = [
            'id', 'product_id', 'product_name',
            'quantity_requested', 'quantity_dispatched',
            'quantity_received', 'quantity_confirmed',
            'dispatch_receive_variance', 'has_variance', 'notes',
        ]


class TransferSerializer(serializers.ModelSerializer):
    items              = TransferItemSerializer(many=True, read_only=True)
    requested_by_name  = serializers.CharField(source='requested_by.full_name',  read_only=True)
    source_name        = serializers.SerializerMethodField()
    destination_name   = serializers.SerializerMethodField()

    class Meta:
        model  = StockTransfer
        fields = [
            'id', 'transfer_number', 'status',
            'from_branch_id', 'from_warehouse_id', 'to_branch_id', 'to_warehouse_id',
            'source_name', 'destination_name',
            'requested_by_id', 'requested_by_name',
            'requested_at', 'approved_at', 'dispatched_at',
            'received_at', 'confirmed_at', 'cancelled_at',
            'notes', 'cancellation_reason', 'items',
        ]

    def get_source_name(self, obj):
        loc = obj.from_branch or obj.from_warehouse
        return loc.name if loc else None

    def get_destination_name(self, obj):
        loc = obj.to_branch or obj.to_warehouse
        return loc.name if loc else None


class TransferItemWriteSerializer(serializers.Serializer):
    product_id         = serializers.UUIDField()
    quantity_requested = serializers.DecimalField(max_digits=12, decimal_places=3, min_value=Decimal('0.001'))


class TransferCreateSerializer(serializers.Serializer):
    from_branch_id    = serializers.UUIDField(required=False, allow_null=True)
    from_warehouse_id = serializers.UUIDField(required=False, allow_null=True)
    to_branch_id      = serializers.UUIDField(required=False, allow_null=True)
    to_warehouse_id   = serializers.UUIDField(required=False, allow_null=True)
    items             = TransferItemWriteSerializer(many=True, min_length=1)
    notes             = serializers.CharField(required=False, allow_blank=True)

    def validate(self, data):
        from_b = data.get('from_branch_id')
        from_w = data.get('from_warehouse_id')
        to_b   = data.get('to_branch_id')
        to_w   = data.get('to_warehouse_id')
        if not (bool(from_b) ^ bool(from_w)):
            raise serializers.ValidationError('Provide exactly one of from_branch_id or from_warehouse_id.')
        if not (bool(to_b) ^ bool(to_w)):
            raise serializers.ValidationError('Provide exactly one of to_branch_id or to_warehouse_id.')
        if from_b and from_b == to_b:
            raise serializers.ValidationError('Cannot transfer to the same branch.')
        if from_w and from_w == to_w:
            raise serializers.ValidationError('Cannot transfer to the same warehouse.')
        return data


class DispatchItemSerializer(serializers.Serializer):
    product_id           = serializers.UUIDField()
    quantity_dispatched  = serializers.DecimalField(max_digits=12, decimal_places=3, min_value=Decimal('0.001'))


class ReceiveItemSerializer(serializers.Serializer):
    product_id          = serializers.UUIDField()
    quantity_received   = serializers.DecimalField(max_digits=12, decimal_places=3, min_value=Decimal('0'))


class ConfirmItemSerializer(serializers.Serializer):
    product_id          = serializers.UUIDField()
    quantity_confirmed  = serializers.DecimalField(max_digits=12, decimal_places=3, min_value=Decimal('0'))
