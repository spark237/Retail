from django.urls import path

from apps.transfers.views import (
    TransferApproveView,
    TransferCancelView,
    TransferConfirmView,
    TransferDetailView,
    TransferDispatchView,
    TransferListCreateView,
    TransferReceiveView,
)

urlpatterns = [
    path('',                               TransferListCreateView.as_view(), name='transfer-list'),
    path('<uuid:transfer_id>/',            TransferDetailView.as_view(),     name='transfer-detail'),
    path('<uuid:transfer_id>/approve/',    TransferApproveView.as_view(),    name='transfer-approve'),
    path('<uuid:transfer_id>/dispatch/',   TransferDispatchView.as_view(),   name='transfer-dispatch'),
    path('<uuid:transfer_id>/receive/',    TransferReceiveView.as_view(),    name='transfer-receive'),
    path('<uuid:transfer_id>/confirm/',    TransferConfirmView.as_view(),    name='transfer-confirm'),
    path('<uuid:transfer_id>/cancel/',     TransferCancelView.as_view(),     name='transfer-cancel'),
]
