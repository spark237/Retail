"""
RetailGuard Transfers — StockTransfer, StockTransferItem

5-step workflow: requested → approved → dispatched → received → confirmed

INVENTORY TIMING:
  TRANSFER_OUT movement created at DISPATCH  → source stock deducted immediately
  TRANSFER_IN  movement created at CONFIRM   → destination stock added

During transit: goods are "in-flight". Tracked by transfer status only.
Mismatch between dispatched and received quantities triggers TRANSFER_VARIANCE alert.

RECEIVED_BY RULE: for branch destinations, received_by must be manager or owner.
Cashiers cannot receive warehouse stock — enforced at view permission layer.
"""
import uuid

from django.conf import settings
from django.db import models

from apps.core.models import TimestampedModel


class TransferStatus(models.TextChoices):
    REQUESTED   = 'requested',   'Requested'
    APPROVED    = 'approved',    'Approved'
    DISPATCHED  = 'dispatched',  'Dispatched'
    RECEIVED    = 'received',    'Received'
    CONFIRMED   = 'confirmed',   'Confirmed'
    CANCELLED   = 'cancelled',   'Cancelled'


# Valid status transitions — server enforces these; no arbitrary jumps
VALID_TRANSITIONS = {
    TransferStatus.REQUESTED:  [TransferStatus.APPROVED,   TransferStatus.CANCELLED],
    TransferStatus.APPROVED:   [TransferStatus.DISPATCHED, TransferStatus.CANCELLED],
    TransferStatus.DISPATCHED: [TransferStatus.RECEIVED],
    TransferStatus.RECEIVED:   [TransferStatus.CONFIRMED],
    TransferStatus.CONFIRMED:  [],   # terminal
    TransferStatus.CANCELLED:  [],   # terminal
}


class StockTransfer(TimestampedModel):
    id                  = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    business            = models.ForeignKey('branches.Business', on_delete=models.PROTECT, related_name='transfers')
    transfer_number     = models.CharField(max_length=50, unique=True)

    # Source location (branch XOR warehouse)
    from_branch         = models.ForeignKey(
        'branches.Branch', null=True, blank=True,
        on_delete=models.PROTECT, related_name='outbound_transfers',
    )
    from_warehouse      = models.ForeignKey(
        'branches.Warehouse', null=True, blank=True,
        on_delete=models.PROTECT, related_name='outbound_transfers',
    )

    # Destination location (branch XOR warehouse)
    to_branch           = models.ForeignKey(
        'branches.Branch', null=True, blank=True,
        on_delete=models.PROTECT, related_name='inbound_transfers',
    )
    to_warehouse        = models.ForeignKey(
        'branches.Warehouse', null=True, blank=True,
        on_delete=models.PROTECT, related_name='inbound_transfers',
    )

    status              = models.CharField(max_length=30, choices=TransferStatus.choices, default=TransferStatus.REQUESTED)

    # Workflow actors
    requested_by        = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name='transfers_requested')
    approved_by         = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.PROTECT, related_name='transfers_approved')
    dispatched_by       = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.PROTECT, related_name='transfers_dispatched')
    received_by         = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.PROTECT, related_name='transfers_received')
    confirmed_by        = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.PROTECT, related_name='transfers_confirmed')
    cancelled_by        = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.PROTECT, related_name='transfers_cancelled')

    # Workflow timestamps
    requested_at        = models.DateTimeField(auto_now_add=True)
    approved_at         = models.DateTimeField(null=True, blank=True)
    dispatched_at       = models.DateTimeField(null=True, blank=True)
    received_at         = models.DateTimeField(null=True, blank=True)
    confirmed_at        = models.DateTimeField(null=True, blank=True)
    cancelled_at        = models.DateTimeField(null=True, blank=True)

    notes               = models.TextField(blank=True, null=True)
    cancellation_reason = models.TextField(blank=True, null=True)

    class Meta:
        db_table = 'stock_transfers'
        ordering = ['-requested_at']
        constraints = [
            models.CheckConstraint(
                condition=(
                    models.Q(from_branch__isnull=False, from_warehouse__isnull=True) |
                    models.Q(from_warehouse__isnull=False, from_branch__isnull=True)
                ),
                name='transfer_from_location_exclusive',
            ),
            models.CheckConstraint(
                condition=(
                    models.Q(to_branch__isnull=False, to_warehouse__isnull=True) |
                    models.Q(to_warehouse__isnull=False, to_branch__isnull=True)
                ),
                name='transfer_to_location_exclusive',
            ),
        ]
        indexes = [
            models.Index(fields=['business', 'status'],  name='idx_transfers_status'),
            models.Index(fields=['from_branch'],          name='idx_transfers_from_branch',
                         condition=models.Q(from_branch__isnull=False)),
            models.Index(fields=['to_branch'],            name='idx_transfers_to_branch',
                         condition=models.Q(to_branch__isnull=False)),
        ]

    def __str__(self):
        return f"{self.transfer_number} [{self.status}]"

    def can_transition_to(self, new_status: str) -> bool:
        return new_status in VALID_TRANSITIONS.get(self.status, [])

    @property
    def source_location(self):
        return self.from_branch or self.from_warehouse

    @property
    def destination_location(self):
        return self.to_branch or self.to_warehouse

    @property
    def has_variance(self):
        return self.items.filter(
            quantity_dispatched__isnull=False,
            quantity_received__isnull=False,
        ).exclude(
            quantity_dispatched=models.F('quantity_received')
        ).exists()


class StockTransferItem(models.Model):
    """
    Line item within a transfer. Tracks quantity at each workflow stage.
    dispatch_receive_variance is computed: received - dispatched.
    Negative variance = stock lost in transit → TRANSFER_VARIANCE fraud alert.
    """
    id                      = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    transfer                = models.ForeignKey(StockTransfer, on_delete=models.PROTECT, related_name='items')
    product                 = models.ForeignKey('products.Product', on_delete=models.PROTECT, related_name='transfer_items')

    # All quantities in product.stock_unit (NUMERIC 12,3)
    quantity_requested      = models.DecimalField(max_digits=12, decimal_places=3)
    quantity_dispatched     = models.DecimalField(max_digits=12, decimal_places=3, null=True, blank=True)
    quantity_received       = models.DecimalField(max_digits=12, decimal_places=3, null=True, blank=True)
    quantity_confirmed      = models.DecimalField(max_digits=12, decimal_places=3, null=True, blank=True)
    notes                   = models.TextField(blank=True, null=True)

    class Meta:
        db_table = 'stock_transfer_items'
        constraints = [
            models.CheckConstraint(
                condition=models.Q(quantity_requested__gt=0),
                name='transfer_item_qty_req_pos',
            ),
        ]
        indexes = [
            models.Index(fields=['product'], name='idx_transfer_items_prod'),
        ]

    def __str__(self):
        return f"{self.product.name}: {self.quantity_requested} requested"

    @property
    def dispatch_receive_variance(self):
        """Computed: received - dispatched. Negative = lost in transit."""
        if self.quantity_dispatched is not None and self.quantity_received is not None:
            return self.quantity_received - self.quantity_dispatched
        return None

    @property
    def has_variance(self):
        v = self.dispatch_receive_variance
        return v is not None and v != 0
