"""RetailGuard Transfers — Views"""
from django.db import transaction
from django.utils import timezone
from rest_framework.exceptions import NotFound
from rest_framework.views import APIView

from apps.audit.models import AuditService
from apps.core.exceptions import InsufficientStockForTransferError, InvalidStatusTransitionError
from apps.core.pagination import StandardPagination
from apps.core.permissions import IsAnyActiveStaff, IsManagerOrOwner
from apps.core.utils import generate_transfer_number, success_response
from apps.fraud.services import FraudDetectionService
from apps.inventory.models import InventoryMovement, InventoryStock, MovementType
from apps.products.models import Product
from apps.transfers.models import StockTransfer, StockTransferItem, TransferStatus
from apps.transfers.serializers import (
    ConfirmItemSerializer,
    DispatchItemSerializer,
    ReceiveItemSerializer,
    TransferCreateSerializer,
    TransferSerializer,
)


def _get_transfer(request, transfer_id):
    try:
        return StockTransfer.objects.prefetch_related(
            'items__product'
        ).get(id=transfer_id, business=request.user.business)
    except StockTransfer.DoesNotExist:
        raise NotFound('Transfer not found.')


class TransferListCreateView(APIView):
    permission_classes = [IsManagerOrOwner]

    def get(self, request):
        qs = StockTransfer.objects.filter(
            business=request.user.business
        ).prefetch_related('items__product').order_by('-requested_at')

        if st := request.query_params.get('status'):
            qs = qs.filter(status=st)
        if fbid := request.query_params.get('from_branch_id'):
            qs = qs.filter(from_branch_id=fbid)
        if tbid := request.query_params.get('to_branch_id'):
            qs = qs.filter(to_branch_id=tbid)
        if fwid := request.query_params.get('from_warehouse_id'):
            qs = qs.filter(from_warehouse_id=fwid)

        paginator = StandardPagination()
        page = paginator.paginate_queryset(qs, request)
        return paginator.get_paginated_response(TransferSerializer(page, many=True).data)

    @transaction.atomic
    def post(self, request):
        s = TransferCreateSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        data = s.validated_data

        day_count = StockTransfer.objects.filter(
            business=request.user.business,
            requested_at__date=timezone.now().date(),
        ).count() + 1
        transfer_number = generate_transfer_number(day_count)

        transfer = StockTransfer.objects.create(
            business=request.user.business,
            transfer_number=transfer_number,
            from_branch_id=data.get('from_branch_id'),
            from_warehouse_id=data.get('from_warehouse_id'),
            to_branch_id=data.get('to_branch_id'),
            to_warehouse_id=data.get('to_warehouse_id'),
            requested_by=request.user,
            notes=data.get('notes', ''),
        )

        for item_data in data['items']:
            try:
                product = Product.objects.get(
                    id=item_data['product_id'], business=request.user.business
                )
            except Product.DoesNotExist:
                raise NotFound(f"Product {item_data['product_id']} not found.")
            StockTransferItem.objects.create(
                transfer=transfer,
                product=product,
                quantity_requested=item_data['quantity_requested'],
            )

        AuditService.log(
            action='transfer.requested', entity_type='transfer',
            entity_id=str(transfer.id), business=request.user.business, request=request,
        )
        return success_response(TransferSerializer(transfer).data, status=201)


class TransferDetailView(APIView):
    permission_classes = [IsManagerOrOwner]

    def get(self, request, transfer_id):
        return success_response(TransferSerializer(_get_transfer(request, transfer_id)).data)


class TransferApproveView(APIView):
    permission_classes = [IsManagerOrOwner]

    def post(self, request, transfer_id):
        transfer = _get_transfer(request, transfer_id)
        if not transfer.can_transition_to(TransferStatus.APPROVED):
            raise InvalidStatusTransitionError(
                extra={'current': transfer.status, 'attempted': TransferStatus.APPROVED}
            )
        transfer.status = TransferStatus.APPROVED
        transfer.approved_by = request.user
        transfer.approved_at = timezone.now()
        transfer.save(update_fields=['status', 'approved_by', 'approved_at', 'updated_at'])
        AuditService.log(action='transfer.approved', entity_type='transfer', entity_id=str(transfer.id),
                         business=request.user.business, request=request)
        return success_response(TransferSerializer(transfer).data)


class TransferDispatchView(APIView):
    permission_classes = [IsAnyActiveStaff]

    @transaction.atomic
    def post(self, request, transfer_id):
        transfer = _get_transfer(request, transfer_id)
        if not transfer.can_transition_to(TransferStatus.DISPATCHED):
            raise InvalidStatusTransitionError(
                extra={'current': transfer.status, 'attempted': TransferStatus.DISPATCHED}
            )

        s = DispatchItemSerializer(data=request.data.get('items', []), many=True)
        s.is_valid(raise_exception=True)
        dispatch_map = {str(i['product_id']): i['quantity_dispatched'] for i in s.validated_data}

        # Lock source stock rows
        src_kwargs = (
            {'branch_id': transfer.from_branch_id}
            if transfer.from_branch_id
            else {'warehouse_id': transfer.from_warehouse_id}
        )
        product_ids = list(transfer.items.values_list('product_id', flat=True))
        stock_map = {
            str(s.product_id): s
            for s in InventoryStock.objects.select_for_update().filter(
                product_id__in=product_ids, **src_kwargs
            )
        }

        for item in transfer.items.all():
            pid_str = str(item.product_id)
            qty_dispatched = dispatch_map.get(pid_str, item.quantity_requested)
            stock = stock_map.get(pid_str)
            if not stock or stock.quantity < qty_dispatched:
                raise InsufficientStockForTransferError(
                    extra={
                        'product_id': pid_str,
                        'available': str(stock.quantity if stock else 0),
                        'requested': str(qty_dispatched),
                    }
                )
            qty_before = stock.quantity
            qty_after  = qty_before - qty_dispatched
            stock.quantity = qty_after
            stock.save(update_fields=['quantity', 'updated_at'])

            InventoryMovement.objects.create(
                business=request.user.business,
                product_id=item.product_id,
                branch_id=transfer.from_branch_id,
                warehouse_id=transfer.from_warehouse_id,
                movement_type=MovementType.TRANSFER_OUT,
                quantity_before=qty_before,
                quantity_change=-qty_dispatched,
                quantity_after=qty_after,
                reference_type='transfer',
                reference_id=str(transfer.id),
                performed_by=request.user,
            )
            item.quantity_dispatched = qty_dispatched
            item.save(update_fields=['quantity_dispatched'])

        transfer.status = TransferStatus.DISPATCHED
        transfer.dispatched_by = request.user
        transfer.dispatched_at = timezone.now()
        transfer.save(update_fields=['status', 'dispatched_by', 'dispatched_at', 'updated_at'])

        AuditService.log(action='transfer.dispatched', entity_type='transfer', entity_id=str(transfer.id),
                         business=request.user.business, request=request)
        return success_response(TransferSerializer(transfer).data)


class TransferReceiveView(APIView):
    permission_classes = [IsManagerOrOwner]

    def post(self, request, transfer_id):
        transfer = _get_transfer(request, transfer_id)
        if not transfer.can_transition_to(TransferStatus.RECEIVED):
            raise InvalidStatusTransitionError(
                extra={'current': transfer.status, 'attempted': TransferStatus.RECEIVED}
            )

        s = ReceiveItemSerializer(data=request.data.get('items', []), many=True)
        s.is_valid(raise_exception=True)
        receive_map = {str(i['product_id']): i['quantity_received'] for i in s.validated_data}

        has_variance = False
        for item in transfer.items.all():
            qty_received = receive_map.get(str(item.product_id), item.quantity_dispatched)
            item.quantity_received = qty_received
            item.save(update_fields=['quantity_received'])
            if item.dispatch_receive_variance != 0:
                has_variance = True

        transfer.status = TransferStatus.RECEIVED
        transfer.received_by = request.user
        transfer.received_at = timezone.now()
        transfer.save(update_fields=['status', 'received_by', 'received_at', 'updated_at'])

        if has_variance:
            FraudDetectionService.check_after_transfer_confirm(transfer)

        AuditService.log(action='transfer.received', entity_type='transfer', entity_id=str(transfer.id),
                         business=request.user.business, request=request)
        return success_response(TransferSerializer(transfer).data)


class TransferConfirmView(APIView):
    permission_classes = [IsManagerOrOwner]

    @transaction.atomic
    def post(self, request, transfer_id):
        transfer = _get_transfer(request, transfer_id)
        if not transfer.can_transition_to(TransferStatus.CONFIRMED):
            raise InvalidStatusTransitionError(
                extra={'current': transfer.status, 'attempted': TransferStatus.CONFIRMED}
            )

        s = ConfirmItemSerializer(data=request.data.get('items', []), many=True)
        s.is_valid(raise_exception=True)
        confirm_map = {str(i['product_id']): i['quantity_confirmed'] for i in s.validated_data}

        dst_kwargs = (
            {'branch_id': transfer.to_branch_id}
            if transfer.to_branch_id
            else {'warehouse_id': transfer.to_warehouse_id}
        )
        for item in transfer.items.all():
            qty_confirmed = confirm_map.get(str(item.product_id), item.quantity_received)
            item.quantity_confirmed = qty_confirmed
            item.save(update_fields=['quantity_confirmed'])

            # Add stock at destination
            stock, _ = InventoryStock.objects.get_or_create(
                product_id=item.product_id, **dst_kwargs,
                defaults={'quantity': 0}
            )
            qty_before = stock.quantity
            qty_after  = qty_before + qty_confirmed
            stock.quantity = qty_after
            stock.save(update_fields=['quantity', 'updated_at'])

            InventoryMovement.objects.create(
                business=request.user.business,
                product_id=item.product_id,
                branch_id=transfer.to_branch_id,
                warehouse_id=transfer.to_warehouse_id,
                movement_type=MovementType.TRANSFER_IN,
                quantity_before=qty_before,
                quantity_change=qty_confirmed,
                quantity_after=qty_after,
                reference_type='transfer',
                reference_id=str(transfer.id),
                performed_by=request.user,
            )

        transfer.status = TransferStatus.CONFIRMED
        transfer.confirmed_by = request.user
        transfer.confirmed_at = timezone.now()
        transfer.save(update_fields=['status', 'confirmed_by', 'confirmed_at', 'updated_at'])

        AuditService.log(action='transfer.confirmed', entity_type='transfer', entity_id=str(transfer.id),
                         business=request.user.business, request=request)
        return success_response(TransferSerializer(transfer).data)


class TransferCancelView(APIView):
    permission_classes = [IsManagerOrOwner]

    def post(self, request, transfer_id):
        transfer = _get_transfer(request, transfer_id)
        if not transfer.can_transition_to(TransferStatus.CANCELLED):
            raise InvalidStatusTransitionError(
                extra={'current': transfer.status, 'attempted': TransferStatus.CANCELLED}
            )
        reason = request.data.get('cancellation_reason', '').strip()
        if not reason:
            from rest_framework.exceptions import ValidationError
            raise ValidationError({'cancellation_reason': 'Cancellation reason is required.'})

        transfer.status = TransferStatus.CANCELLED
        transfer.cancelled_by = request.user
        transfer.cancelled_at = timezone.now()
        transfer.cancellation_reason = reason
        transfer.save(update_fields=['status', 'cancelled_by', 'cancelled_at', 'cancellation_reason', 'updated_at'])

        return success_response({'id': str(transfer.id), 'status': 'cancelled'})
