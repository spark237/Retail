from django.apps import AppConfig


class TransfersConfigAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.transfers'
    label = 'transfers'
