# Analytics views return raw dicts — no DRF serializer models needed.
# Serialization is handled directly in the view layer via success_response().
