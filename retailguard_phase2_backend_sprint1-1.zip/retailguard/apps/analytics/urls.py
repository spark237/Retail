from django.urls import path

from apps.analytics.views import (
    BranchAnalyticsView,
    DailyAnalyticsView,
    InventoryAnalyticsView,
    MonthlyAnalyticsView,
)

urlpatterns = [
    path('daily/',      DailyAnalyticsView.as_view(),     name='analytics-daily'),
    path('monthly/',    MonthlyAnalyticsView.as_view(),    name='analytics-monthly'),
    path('branches/',   BranchAnalyticsView.as_view(),     name='analytics-branches'),
    path('inventory/',  InventoryAnalyticsView.as_view(),  name='analytics-inventory'),
]
