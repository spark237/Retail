"""
RetailGuard Analytics — Views

Aggregation-only views. No models — reads from existing tables.
All figures in XAF integers. Quantities in NUMERIC(12,3).
Owner sees all branches. Managers see own branch only.
"""
from django.db.models import Count, Q, Sum
from django.utils import timezone
from rest_framework.exceptions import ValidationError
from rest_framework.views import APIView

from apps.core.permissions import IsManagerOrOwner, IsOwner
from apps.core.utils import success_response
from apps.fraud.models import AlertStatus, FraudAlert
from apps.inventory.models import InventoryStock
from apps.reconciliation.models import CashReconciliation
from apps.sales.models import PaymentMethod, PaymentTransaction, Sale, SaleItem, SaleStatus
from apps.shifts.models import Shift, ShiftStatus


def _parse_date_param(request, param, default=None):
    from datetime import date
    val = request.query_params.get(param, default)
    if val:
        try:
            return date.fromisoformat(val)
        except ValueError:
            raise ValidationError({param: 'Invalid date format. Use YYYY-MM-DD.'})
    return None


def _branch_scope(user):
    """Return branch_ids the user is allowed to query."""
    if user.role == 'owner':
        return None  # No filter — sees all
    return list(
        user.branch_assignments
        .filter(revoked_at__isnull=True, branch_id__isnull=False)
        .values_list('branch_id', flat=True)
    )


class DailyAnalyticsView(APIView):
    permission_classes = [IsManagerOrOwner]

    def get(self, request):
        target_date = _parse_date_param(request, 'date', str(timezone.now().date()))
        branch_id   = request.query_params.get('branch_id')

        scope = _branch_scope(request.user)

        # Base sale filter
        sale_filter = Q(
            business=request.user.business,
            sync_status='synced',
            created_at_device__date=target_date,
            status__in=[SaleStatus.COMPLETED, SaleStatus.PENDING_PAYMENT],
        )
        if branch_id:
            sale_filter &= Q(branch_id=branch_id)
        elif scope is not None:
            sale_filter &= Q(branch_id__in=scope)

        # Revenue by payment method
        payment_totals = PaymentTransaction.objects.filter(
            sale__in=Sale.objects.filter(sale_filter),
            is_confirmed=True,
        ).values('payment_method').annotate(total=Sum('amount'))

        revenue_by_method = {
            PaymentMethod.CASH:          0,
            PaymentMethod.MTN_MOMO:      0,
            PaymentMethod.ORANGE_MONEY:  0,
            PaymentMethod.BANK_TRANSFER: 0,
        }
        for row in payment_totals:
            revenue_by_method[row['payment_method']] = row['total'] or 0

        total_revenue = sum(revenue_by_method.values())

        # Transaction counts
        tx_stats = Sale.objects.filter(
            Q(business=request.user.business, created_at_device__date=target_date)
            & (Q(branch_id=branch_id) if branch_id else Q(branch_id__in=scope) if scope else Q())
        ).aggregate(
            completed=Count('id', filter=Q(status=SaleStatus.COMPLETED, sync_status='synced')),
            voided=Count('id', filter=Q(status=SaleStatus.VOIDED)),
            price_overrides=Count('id', filter=Q(approval_required=True, sync_status='synced')),
        )

        # Shifts
        shift_filter = Q(business=request.user.business, started_at__date=target_date)
        if branch_id:
            shift_filter &= Q(branch_id=branch_id)
        elif scope is not None:
            shift_filter &= Q(branch_id__in=scope)

        shift_stats = Shift.objects.filter(shift_filter).aggregate(
            active=Count('id', filter=Q(status=ShiftStatus.OPEN)),
            closed_pending=Count('id', filter=Q(status=ShiftStatus.CLOSED_PENDING)),
            closed_synced=Count('id', filter=Q(status=ShiftStatus.CLOSED_SYNCED)),
        )

        # Reconciliation summary
        recon_filter = Q(branch__business=request.user.business, created_at__date=target_date)
        if branch_id:
            recon_filter &= Q(branch_id=branch_id)
        elif scope is not None:
            recon_filter &= Q(branch_id__in=scope)

        recon = CashReconciliation.objects.filter(recon_filter).first()
        recon_data = None
        if recon:
            recon_data = {
                'status': recon.status_label,
                'expected_cash': recon.expected_cash_confirmed,
                'actual_cash': recon.actual_cash,
                'difference': recon.difference_confirmed,
                'is_preliminary': recon.is_preliminary,
            }

        # Open fraud alerts
        alert_filter = Q(business=request.user.business, status__in=[AlertStatus.OPEN, AlertStatus.ACKNOWLEDGED])
        if branch_id:
            alert_filter &= Q(branch_id=branch_id)
        elif scope is not None:
            alert_filter &= Q(branch_id__in=scope)

        alert_stats = FraudAlert.objects.filter(alert_filter).aggregate(
            total=Count('id'),
            critical=Count('id', filter=Q(alert_level='critical')),
            high=Count('id', filter=Q(alert_level='high')),
            medium=Count('id', filter=Q(alert_level='medium')),
            low=Count('id', filter=Q(alert_level='low')),
        )

        # Low stock items
        stock_filter = Q(product__business=request.user.business)
        if branch_id:
            stock_filter &= Q(branch_id=branch_id)
        elif scope is not None:
            stock_filter &= Q(branch_id__in=scope)

        low_stock = [
            {
                'product_id': str(s.product_id),
                'product_name': s.product.name,
                'sku': s.product.sku,
                'tile_size': s.product.tile_size,
                'quantity': str(s.quantity),
                'reorder_level': str(s.product.reorder_level),
                'unit': s.product.stock_unit,
            }
            for s in InventoryStock.objects.filter(stock_filter).select_related('product')
            if s.quantity <= s.product.reorder_level
        ]

        # Top products by revenue
        top_products = (
            SaleItem.objects.filter(sale__in=Sale.objects.filter(sale_filter))
            .values('product_id', 'product_name')
            .annotate(
                units_sold=Sum('quantity_in_stock_unit'),
                revenue=Sum('total_price'),
            )
            .order_by('-revenue')[:5]
        )

        return success_response({
            'date': str(target_date),
            'branch_id': branch_id,
            'revenue': {
                'total': total_revenue,
                'by_method': revenue_by_method,
            },
            'transactions': tx_stats,
            'shifts': shift_stats,
            'reconciliation': recon_data,
            'fraud_alerts': {
                'open': alert_stats['total'],
                'by_level': {
                    'critical': alert_stats['critical'],
                    'high':     alert_stats['high'],
                    'medium':   alert_stats['medium'],
                    'low':      alert_stats['low'],
                },
            },
            'low_stock_items': low_stock,
            'top_products': [
                {
                    'product_id': str(p['product_id']),
                    'product_name': p['product_name'],
                    'units_sold': str(p['units_sold'] or 0),
                    'revenue': p['revenue'] or 0,
                }
                for p in top_products
            ],
        })


class MonthlyAnalyticsView(APIView):
    permission_classes = [IsManagerOrOwner]

    def get(self, request):
        year  = int(request.query_params.get('year',  timezone.now().year))
        month = int(request.query_params.get('month', timezone.now().month))
        branch_id = request.query_params.get('branch_id')
        scope = _branch_scope(request.user)

        sale_filter = Q(
            business=request.user.business,
            sync_status='synced',
            created_at_device__year=year,
            created_at_device__month=month,
            status__in=[SaleStatus.COMPLETED, SaleStatus.PENDING_PAYMENT],
        )
        if branch_id:
            sale_filter &= Q(branch_id=branch_id)
        elif scope is not None:
            sale_filter &= Q(branch_id__in=scope)

        sales_qs = Sale.objects.filter(sale_filter)

        # Total revenue
        total_revenue = sales_qs.aggregate(t=Sum('total_amount'))['t'] or 0

        # Daily trend
        from django.db.models.functions import TruncDate
        daily = (
            sales_qs
            .annotate(day=TruncDate('created_at_device'))
            .values('day')
            .annotate(revenue=Sum('total_amount'))
            .order_by('day')
        )

        # Staff performance
        staff_stats = (
            Sale.objects.filter(
                Q(business=request.user.business, sync_status='synced',
                  created_at_device__year=year, created_at_device__month=month)
                & (Q(branch_id=branch_id) if branch_id else Q(branch_id__in=scope) if scope else Q())
            )
            .values('cashier_id', 'cashier__first_name', 'cashier__last_name')
            .annotate(
                sales_count=Count('id', filter=Q(status=SaleStatus.COMPLETED)),
                revenue=Sum('total_amount', filter=Q(status=SaleStatus.COMPLETED)),
                voids=Count('id', filter=Q(status=SaleStatus.VOIDED)),
                price_overrides=Count('id', filter=Q(approval_required=True)),
            )
            .order_by('-revenue')
        )

        # Expense total
        from apps.expenses.models import Expense, ExpenseStatus
        exp_filter = Q(
            business=request.user.business,
            expense_date__year=year, expense_date__month=month,
            status=ExpenseStatus.APPROVED, is_deleted=False,
        )
        if branch_id:
            exp_filter &= Q(branch_id=branch_id)
        expense_total = Expense.objects.filter(exp_filter).aggregate(t=Sum('amount'))['t'] or 0

        # Cash shortages this month
        recon_filter = Q(
            branch__business=request.user.business,
            created_at__year=year, created_at__month=month,
            difference_confirmed__lt=0,
        )
        if branch_id:
            recon_filter &= Q(branch_id=branch_id)
        shortage_data = CashReconciliation.objects.filter(recon_filter).aggregate(
            occurrences=Count('id'),
            total_amount=Sum('difference_confirmed'),
        )

        return success_response({
            'period': f'{year}-{month:02d}',
            'branch_id': branch_id,
            'revenue': {
                'total': total_revenue,
                'daily_trend': [
                    {'date': str(r['day']), 'revenue': r['revenue'] or 0}
                    for r in daily
                ],
            },
            'staff_performance': [
                {
                    'cashier_id': str(r['cashier_id']),
                    'name': f"{r['cashier__first_name']} {r['cashier__last_name']}",
                    'sales_count': r['sales_count'] or 0,
                    'revenue': r['revenue'] or 0,
                    'voids': r['voids'] or 0,
                    'price_overrides': r['price_overrides'] or 0,
                }
                for r in staff_stats
            ],
            'expense_total': expense_total,
            'gross_profit': total_revenue - expense_total,
            'reconciliation_shortages': {
                'total_occurrences': shortage_data['occurrences'] or 0,
                'total_amount': abs(shortage_data['total_amount'] or 0),
            },
        })


class BranchAnalyticsView(APIView):
    """Cross-branch comparison. Owner only."""
    permission_classes = [IsOwner]

    def get(self, request):
        from apps.branches.models import Branch
        from_dt = _parse_date_param(request, 'from_date', str(timezone.now().replace(day=1).date()))
        to_dt   = _parse_date_param(request, 'to_date',   str(timezone.now().date()))

        branches = Branch.objects.filter(business=request.user.business, is_active=True, is_deleted=False)
        result = []

        for branch in branches:
            sale_filter = Q(
                branch=branch, sync_status='synced',
                status__in=[SaleStatus.COMPLETED, SaleStatus.PENDING_PAYMENT],
                created_at_device__date__gte=from_dt,
                created_at_device__date__lte=to_dt,
            )
            stats = Sale.objects.filter(sale_filter).aggregate(
                revenue=Sum('total_amount'),
                transactions=Count('id'),
            )
            open_alerts = FraudAlert.objects.filter(
                branch=branch, status__in=[AlertStatus.OPEN, AlertStatus.ACKNOWLEDGED]
            ).count()

            top_item = (
                SaleItem.objects.filter(sale__in=Sale.objects.filter(sale_filter))
                .values('product_name')
                .annotate(rev=Sum('total_price'))
                .order_by('-rev')
                .first()
            )

            result.append({
                'branch': {'id': str(branch.id), 'name': branch.name, 'code': branch.code},
                'revenue': stats['revenue'] or 0,
                'transactions': stats['transactions'] or 0,
                'open_alerts': open_alerts,
                'top_product': top_item['product_name'] if top_item else None,
            })

        result.sort(key=lambda x: x['revenue'], reverse=True)

        return success_response({
            'period': f'{from_dt} to {to_dt}',
            'branches': result,
            'business_total_revenue': sum(b['revenue'] for b in result),
        })


class InventoryAnalyticsView(APIView):
    permission_classes = [IsManagerOrOwner]

    def get(self, request):
        branch_id = request.query_params.get('branch_id')
        scope = _branch_scope(request.user)

        stock_filter = Q(product__business=request.user.business)
        if branch_id:
            stock_filter &= Q(branch_id=branch_id)
        elif scope is not None:
            stock_filter &= Q(branch_id__in=scope)

        all_stock = InventoryStock.objects.filter(
            stock_filter
        ).select_related('product', 'branch', 'warehouse').order_by('product__name')

        items = []
        for s in all_stock:
            items.append({
                'product_id': str(s.product_id),
                'product_name': s.product.name,
                'sku': s.product.sku,
                'tile_size': s.product.tile_size,
                'stock_unit': s.product.stock_unit,
                'quantity': str(s.quantity),
                'reorder_level': str(s.product.reorder_level),
                'is_low_stock': s.quantity <= s.product.reorder_level,
                'location_type': 'branch' if s.branch_id else 'warehouse',
                'location_id': str(s.branch_id or s.warehouse_id),
                'location_name': (s.branch.name if s.branch else s.warehouse.name) if (s.branch or s.warehouse) else None,
            })

        low_stock_count = sum(1 for i in items if i['is_low_stock'])

        return success_response({
            'total_products': len(items),
            'low_stock_count': low_stock_count,
            'items': items,
        })
