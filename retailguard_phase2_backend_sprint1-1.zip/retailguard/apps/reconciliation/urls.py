from django.urls import path

from apps.reconciliation.views import (
    ReconciliationDetailView,
    ReconciliationListView,
    ReconciliationReviewView,
)

urlpatterns = [
    path('',                          ReconciliationListView.as_view(),   name='reconciliation-list'),
    path('<uuid:shift_id>/',          ReconciliationDetailView.as_view(), name='reconciliation-detail'),
    path('<uuid:recon_id>/review/',   ReconciliationReviewView.as_view(), name='reconciliation-review'),
]
