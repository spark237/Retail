from django.apps import AppConfig


class ReconciliationConfigAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.reconciliation'
    label = 'reconciliation'
