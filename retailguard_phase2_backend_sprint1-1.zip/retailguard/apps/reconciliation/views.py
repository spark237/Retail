"""RetailGuard Reconciliation — Views"""
from django.utils import timezone
from rest_framework.exceptions import NotFound
from rest_framework.views import APIView

from apps.audit.models import AuditService
from apps.core.pagination import StandardPagination
from apps.core.permissions import IsCashierOrAbove, IsManagerOrOwner
from apps.core.utils import success_response
from apps.reconciliation.models import CashReconciliation
from apps.reconciliation.serializers import ReconciliationSerializer


class ReconciliationListView(APIView):
    permission_classes = [IsManagerOrOwner]

    def get(self, request):
        qs = CashReconciliation.objects.filter(
            branch__business=request.user.business
        ).select_related('shift', 'branch', 'cashier').order_by('-created_at')

        if request.user.role != 'owner':
            branch_ids = list(
                request.user.branch_assignments
                .filter(revoked_at__isnull=True, branch_id__isnull=False)
                .values_list('branch_id', flat=True)
            )
            qs = qs.filter(branch_id__in=branch_ids)
        if bid := request.query_params.get('branch_id'):
            qs = qs.filter(branch_id=bid)
        if request.query_params.get('is_preliminary') == 'true':
            qs = qs.filter(is_preliminary=True)
        if from_dt := request.query_params.get('from_date'):
            qs = qs.filter(created_at__date__gte=from_dt)
        if to_dt := request.query_params.get('to_date'):
            qs = qs.filter(created_at__date__lte=to_dt)

        paginator = StandardPagination()
        page = paginator.paginate_queryset(qs, request)
        return paginator.get_paginated_response(ReconciliationSerializer(page, many=True).data)


class ReconciliationDetailView(APIView):
    permission_classes = [IsCashierOrAbove]

    def _get_recon(self, request, shift_id):
        qs = CashReconciliation.objects.select_related('shift', 'branch', 'cashier')
        try:
            recon = qs.get(shift_id=shift_id)
        except CashReconciliation.DoesNotExist:
            raise NotFound('Reconciliation not found.')
        # Scope check
        if request.user.role == 'cashier' and str(recon.cashier_id) != str(request.user.id):
            raise NotFound('Reconciliation not found.')
        if request.user.role == 'manager':
            branch_ids = list(
                request.user.branch_assignments
                .filter(revoked_at__isnull=True, branch_id__isnull=False)
                .values_list('branch_id', flat=True)
            )
            if str(recon.branch_id) not in [str(b) for b in branch_ids]:
                raise NotFound('Reconciliation not found.')
        return recon

    def get(self, request, shift_id):
        return success_response(ReconciliationSerializer(self._get_recon(request, shift_id)).data)


class ReconciliationReviewView(APIView):
    permission_classes = [IsManagerOrOwner]

    def post(self, request, recon_id):
        try:
            recon = CashReconciliation.objects.get(id=recon_id)
        except CashReconciliation.DoesNotExist:
            raise NotFound('Reconciliation not found.')

        review_notes = request.data.get('review_notes', '')
        recon.reviewed_by = request.user
        recon.reviewed_at = timezone.now()
        recon.review_notes = review_notes
        recon.save(update_fields=['reviewed_by', 'reviewed_at', 'review_notes', 'updated_at'])

        AuditService.log(
            action='reconciliation.reviewed', entity_type='cash_reconciliation',
            entity_id=str(recon.id), business=recon.branch.business,
            branch=recon.branch, request=request,
        )
        return success_response(ReconciliationSerializer(recon).data)
