"""RetailGuard Reconciliation — Serializers"""
from rest_framework import serializers

from apps.reconciliation.models import CashReconciliation


class ReconciliationSerializer(serializers.ModelSerializer):
    cashier_name = serializers.CharField(source='cashier.full_name', read_only=True)
    branch_name  = serializers.CharField(source='branch.name',       read_only=True)
    status_label = serializers.ReadOnlyField()
    has_shortage = serializers.ReadOnlyField()

    class Meta:
        model  = CashReconciliation
        fields = [
            'id', 'shift_id', 'branch_id', 'branch_name', 'cashier_id', 'cashier_name',
            'status_label', 'has_shortage',
            'opening_cash', 'confirmed_cash_sales', 'pending_cash_sales',
            'expected_cash_confirmed', 'expected_cash_with_pending',
            'actual_cash', 'difference_confirmed', 'difference_with_pending',
            'is_preliminary', 'finalized_difference', 'finalized_at',
            'reviewed_by_id', 'reviewed_at', 'review_notes', 'created_at',
        ]
