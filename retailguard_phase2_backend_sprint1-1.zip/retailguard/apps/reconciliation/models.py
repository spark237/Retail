"""
RetailGuard Reconciliation — CashReconciliation

One record per shift. The primary anti-theft control.
Created atomically when cashier closes their shift.

PRELIMINARY STATE:
  When is_preliminary=True: unsynced offline sales exist.
  All figures labelled PRELIMINARY in reports and dashboard.
  Owner must not take disciplinary action on preliminary figures.
  is_preliminary flips to False after all pending sales sync and settle.

FORMULA:
  expected_cash_confirmed = opening_cash + confirmed_cash_sales
  difference_confirmed    = actual_cash - expected_cash_confirmed
  (negative = cashier short; positive = cashier over)
"""
import uuid

from django.conf import settings
from django.db import models

from apps.core.models import TimestampedModel


class CashReconciliation(TimestampedModel):
    """
    End-of-shift cash accountability record.
    Separates confirmed (synced) figures from pending (unsynced) estimates.
    Only CASH payment transactions contribute to expected_cash — mobile money excluded.
    """
    id                          = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    shift                       = models.OneToOneField(
        'shifts.Shift',
        on_delete=models.PROTECT,
        related_name='reconciliation',
    )
    branch                      = models.ForeignKey(
        'branches.Branch',
        on_delete=models.PROTECT,
        related_name='reconciliations',
    )
    cashier                     = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name='reconciliations',
    )

    # Cash flow inputs
    opening_cash                = models.IntegerField()           # XAF float given at shift start
    confirmed_cash_sales        = models.IntegerField()           # XAF from synced CASH payments only
    pending_cash_sales          = models.IntegerField(default=0)  # XAF from unsynced sales (estimate)

    # Expected figures
    expected_cash_confirmed     = models.IntegerField()           # opening + confirmed_cash_sales
    expected_cash_with_pending  = models.IntegerField()           # opening + confirmed + pending

    # Actual physical count (entered by cashier at close)
    actual_cash                 = models.IntegerField()

    # Differences
    difference_confirmed        = models.IntegerField()           # actual - expected_confirmed
    difference_with_pending     = models.IntegerField()           # actual - expected_with_pending

    # Preliminary flag — True while any shift sales remain unsynced
    is_preliminary              = models.BooleanField(default=False)
    finalized_difference        = models.IntegerField(null=True, blank=True)
    finalized_at                = models.DateTimeField(null=True, blank=True)

    # Manager review
    reviewed_by                 = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True, blank=True,
        on_delete=models.PROTECT,
        related_name='reviewed_reconciliations',
    )
    reviewed_at                 = models.DateTimeField(null=True, blank=True)
    review_notes                = models.TextField(blank=True, null=True)

    class Meta:
        db_table = 'cash_reconciliation'
        ordering = ['-created_at']
        constraints = [
            models.CheckConstraint(
                # expected_cash_confirmed = opening_cash + confirmed_cash_sales
                # Expressed as: expected - opening - confirmed = 0
                condition=models.Q(
                    expected_cash_confirmed=models.F('opening_cash') + models.F('confirmed_cash_sales')
                ),
                name='recon_expected_math',
            ),
        ]
        indexes = [
            models.Index(fields=['branch', '-created_at'], name='idx_recon_branch_date'),
            models.Index(fields=['cashier'],               name='idx_recon_cashier'),
            models.Index(
                fields=['is_preliminary'],
                name='idx_recon_preliminary',
                condition=models.Q(is_preliminary=True),
            ),
        ]

    def __str__(self):
        status = 'PRELIMINARY' if self.is_preliminary else 'FINAL'
        return f"Reconciliation: {self.cashier.full_name} @ {self.branch.name} [{status}]"

    @property
    def status_label(self):
        if self.is_preliminary:
            return 'PRELIMINARY — Unsynced Sales Pending'
        return 'FINAL'

    @property
    def has_shortage(self):
        """True if confirmed difference shows a cash deficit."""
        return self.difference_confirmed < 0

    def finalize(self):
        """
        Called by sync engine after all pending sales settle.
        Recomputes confirmed figures and removes preliminary flag.
        """
        from django.utils import timezone

        from apps.sales.models import PaymentTransaction, SaleStatus

        # Recompute confirmed cash from now-synced sales
        confirmed_cash = PaymentTransaction.objects.filter(
            sale__shift=self.shift,
            sale__status__in=[SaleStatus.COMPLETED, SaleStatus.PENDING_PAYMENT],
            sale__sync_status='synced',
            payment_method='CASH',
            is_confirmed=True,
        ).aggregate(total=models.Sum('amount'))['total'] or 0

        self.confirmed_cash_sales = confirmed_cash
        self.pending_cash_sales = 0
        self.expected_cash_confirmed = self.opening_cash + confirmed_cash
        self.expected_cash_with_pending = self.expected_cash_confirmed
        self.difference_confirmed = self.actual_cash - self.expected_cash_confirmed
        self.difference_with_pending = self.difference_confirmed
        self.finalized_difference = self.difference_confirmed
        self.finalized_at = timezone.now()
        self.is_preliminary = False
        self.save()
