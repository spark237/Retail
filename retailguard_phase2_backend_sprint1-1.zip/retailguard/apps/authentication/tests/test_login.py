"""
Login flow tests. First real test suite for RetailGuard — this exists
before sales/inventory/fraud tests because everything downstream needs
proof the auth scaffolding itself (factories, JWT issuance, conftest
fixtures) actually works against the real database.
"""
import pytest
from django.urls import reverse

from apps.core.tests.factories import CashierFactory


@pytest.mark.django_db
class TestLogin:
    def test_login_success_with_email(self, api_client, business):
        cashier = CashierFactory(business=business, email='cashier@retailguard.test')

        response = api_client.post(reverse('auth-login'), {
            'identifier': 'cashier@retailguard.test',
            'password': 'TestPass123!',
        }, format='json')

        assert response.status_code == 200
        body = response.data
        assert body['success'] is True
        assert body['data']['token_type'] == 'Bearer'
        assert body['data']['user']['id'] == str(cashier.id)
        # refresh token must never be in the JSON body — HttpOnly cookie only
        assert 'refresh_token' not in body['data']
        assert 'refresh_token' in response.cookies
        assert response.cookies['refresh_token']['httponly'] is True

    def test_login_wrong_password(self, api_client, business):
        CashierFactory(business=business, email='cashier2@retailguard.test')

        response = api_client.post(reverse('auth-login'), {
            'identifier': 'cashier2@retailguard.test',
            'password': 'WrongPassword!',
        }, format='json')

        assert response.status_code == 401
        assert response.data['error']['code'] == 'INVALID_CREDENTIALS'

    def test_login_unknown_identifier(self, api_client, business):
        response = api_client.post(reverse('auth-login'), {
            'identifier': 'nobody@retailguard.test',
            'password': 'whatever',
        }, format='json')

        assert response.status_code == 401
        assert response.data['error']['code'] == 'INVALID_CREDENTIALS'

    def test_login_locks_account_after_max_attempts(self, api_client, business):
        """
        RETAILGUARD['LOGIN_MAX_ATTEMPTS'] = 5 (config/settings/base.py).
        The 5th wrong attempt should trigger the lock itself.
        """
        cashier = CashierFactory(business=business, email='locktest@retailguard.test')

        for _ in range(5):
            response = api_client.post(reverse('auth-login'), {
                'identifier': 'locktest@retailguard.test',
                'password': 'WrongPassword!',
            }, format='json')

        cashier.refresh_from_db()
        assert cashier.is_locked

        # Even the correct password should now be rejected while locked.
        response = api_client.post(reverse('auth-login'), {
            'identifier': 'locktest@retailguard.test',
            'password': 'TestPass123!',
        }, format='json')
        assert response.status_code == 401
        assert response.data['error']['code'] == 'ACCOUNT_LOCKED'

    def test_login_inactive_account_rejected(self, api_client, business):
        CashierFactory(
            business=business, email='inactive@retailguard.test', is_active=False,
        )

        response = api_client.post(reverse('auth-login'), {
            'identifier': 'inactive@retailguard.test',
            'password': 'TestPass123!',
        }, format='json')

        assert response.status_code == 401
        assert response.data['error']['code'] == 'INVALID_CREDENTIALS'

    def test_login_by_phone_number(self, api_client, business):
        CashierFactory(business=business, phone='+237600000001', email=None)

        response = api_client.post(reverse('auth-login'), {
            'identifier': '+237600000001',
            'password': 'TestPass123!',
        }, format='json')

        assert response.status_code == 200

    def test_successful_login_resets_failed_attempts(self, api_client, business):
        cashier = CashierFactory(business=business, email='reset@retailguard.test')

        api_client.post(reverse('auth-login'), {
            'identifier': 'reset@retailguard.test', 'password': 'wrong',
        }, format='json')
        api_client.post(reverse('auth-login'), {
            'identifier': 'reset@retailguard.test', 'password': 'wrong',
        }, format='json')
        cashier.refresh_from_db()
        assert cashier.failed_login_attempts == 2

        api_client.post(reverse('auth-login'), {
            'identifier': 'reset@retailguard.test', 'password': 'TestPass123!',
        }, format='json')
        cashier.refresh_from_db()
        assert cashier.failed_login_attempts == 0
        assert cashier.last_login_at is not None


@pytest.mark.django_db
class TestUserMe:
    def test_me_requires_authentication(self, api_client):
        response = api_client.get(reverse('auth-me'))
        assert response.status_code == 401

    def test_me_returns_authenticated_user(self, cashier_client, cashier):
        response = cashier_client.get(reverse('auth-me'))
        assert response.status_code == 200
        assert response.data['data']['id'] == str(cashier.id)
        assert response.data['data']['role'] == 'cashier'
