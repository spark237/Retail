"""
RetailGuard Authentication — Views

Login flow:
  1. Validate credentials
  2. Check account lock
  3. Check branch terminal occupation (if branch_id provided)
  4. Issue JWT tokens, create UserSession record
  5. Return token + user context

Terminal Takeover flow:
  1. Verify requester is manager/owner (permission class)
  2. Validate override credential (PIN or password)
  3. Atomically: kill old session + force-close shift + create takeover record + issue new token
"""
from django.contrib.auth import get_user_model
from django.db import transaction
from django.utils import timezone
from rest_framework import status
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.exceptions import TokenError
from rest_framework_simplejwt.tokens import RefreshToken

from apps.audit.actions import AuditAction
from apps.audit.models import AuditService
from apps.authentication.backends import RetailGuardAuthBackend
from apps.authentication.serializers import (
    LoginSerializer,
    TerminalTakeoverSerializer,
    UserMeSerializer,
)
from apps.authentication.tokens import RetailGuardAccessToken
from apps.core.exceptions import (
    AccountLockedError,
    InvalidCredentialsError,
    TerminalOccupiedError,
)
from apps.core.permissions import CanOverrideTerminal
from apps.core.utils import get_client_ip, hash_token
from apps.users.models import UserSession

User = get_user_model()


def _build_device_info(request) -> dict:
    return {
        'user_agent': request.META.get('HTTP_USER_AGENT', ''),
        'ip': get_client_ip(request),
    }


def _issue_tokens(user, request, device_fingerprint=None) -> tuple[str, str, UserSession]:
    """
    Issue access + refresh tokens and create a UserSession record.
    Returns (access_token_str, refresh_token_str, session_instance).
    """
    refresh = RefreshToken.for_user(user)
    access_str = str(RetailGuardAccessToken.for_user(user))
    refresh_str = str(refresh)

    session = UserSession.objects.create(
        user=user,
        token_hash=hash_token(access_str),
        device_info=_build_device_info(request),
        device_fingerprint=device_fingerprint,
        ip_address=get_client_ip(request),
        expires_at=timezone.now() + RetailGuardAccessToken.lifetime,
    )
    return access_str, refresh_str, session


# ─── VIEWS ───────────────────────────────────────────────────────────────────

class LoginView(APIView):
    """
    POST /api/v1/auth/login

    Supports phone or email as identifier.
    Detects terminal occupation and returns rich context for takeover decision.
    Rate limited to 10/minute in production (see throttle classes in settings).
    """
    permission_classes  = [AllowAny]
    serializer_class    = LoginSerializer

    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data

        # Step 1: Find user
        backend = RetailGuardAuthBackend()
        user = backend._find_user(data['identifier'])

        if user is None:
            raise InvalidCredentialsError()

        # Step 2: Account lock check (before password validation — timing attack awareness)
        if user.is_locked:
            AuditService.log(
                action=AuditAction.USER_LOGIN_FAILED, entity_type='user',
                entity_id=str(user.id), business=user.business, user=user,
                request=request, new_values={'reason': 'account_locked'},
            )
            raise AccountLockedError(
                extra={'locked_until': user.locked_until.isoformat()}
            )

        # Step 3: Password validation
        if not user.check_password(data['password']):
            user.record_failed_login()
            attempts_remaining = max(
                0,
                5 - user.failed_login_attempts  # 5 = LOGIN_MAX_ATTEMPTS
            )
            AuditService.log(
                action=AuditAction.USER_LOGIN_FAILED, entity_type='user',
                entity_id=str(user.id), business=user.business, user=user,
                request=request,
                new_values={'reason': 'wrong_password', 'attempts_remaining': attempts_remaining},
            )
            if user.is_locked:
                # This failed attempt just crossed LOGIN_MAX_ATTEMPTS — record
                # the lock as its own distinct event, not just another failure.
                AuditService.log(
                    action=AuditAction.USER_LOCKED, entity_type='user',
                    entity_id=str(user.id), business=user.business, user=user,
                    request=request,
                    new_values={'locked_until': user.locked_until.isoformat()},
                )
            raise InvalidCredentialsError(
                extra={'attempts_remaining': attempts_remaining}
            )

        # Step 4: Active + not deleted check
        if not user.is_active or user.is_deleted:
            AuditService.log(
                action=AuditAction.USER_LOGIN_FAILED, entity_type='user',
                entity_id=str(user.id), business=user.business, user=user,
                request=request, new_values={'reason': 'inactive_account'},
            )
            raise InvalidCredentialsError(
                detail='Account is inactive.',
                extra={'attempts_remaining': 0}
            )

        # Step 5: Branch terminal check
        branch_id = data.get('branch_id')
        if branch_id:
            self._check_terminal_availability(user, branch_id)

        # Step 6: Issue tokens + create session
        user.record_successful_login()
        access_str, refresh_str, session = _issue_tokens(
            user, request, data.get('device_fingerprint')
        )

        # session is passed explicitly here — this request has no Bearer
        # header yet (the token above was just issued), so AuditService.log
        # can't auto-resolve it from the request the way it does for
        # already-authenticated requests.
        AuditService.log(
            action=AuditAction.USER_LOGIN, entity_type='user',
            entity_id=str(user.id), business=user.business, user=user,
            session=session, request=request,
            new_values={'branch_id': str(branch_id) if branch_id else None},
        )

        # Refresh token in HttpOnly cookie (production)
        response = Response({
            'success': True,
            'data': {
                'access_token': access_str,
                'token_type': 'Bearer',
                'expires_in': 900,
                'user': UserMeSerializer(user).data,
            }
        }, status=status.HTTP_200_OK)

        response.set_cookie(
            'refresh_token',
            refresh_str,
            httponly=True,
            secure=request.META.get('SERVER_NAME', '') not in ('localhost', '127.0.0.1'),
            samesite='Lax',
            max_age=60 * 60 * 24 * 7,  # 7 days
        )
        return response

    def _check_terminal_availability(self, user, branch_id):
        """
        Raise TerminalOccupiedError if branch has an active shift.
        Include can_override=True for managers/owners.
        """
        from apps.shifts.models import Shift
        open_shift = Shift.objects.filter(
            branch_id=branch_id, status='open'
        ).select_related('cashier').first()

        if open_shift:
            can_override = user.role in ('owner', 'manager')
            raise TerminalOccupiedError(
                extra={
                    'branch_id': str(branch_id),
                    'active_since': open_shift.started_at.isoformat(),
                    'cashier_name': open_shift.cashier.full_name,
                    'can_override': can_override,
                }
            )


class LogoutView(APIView):
    """POST /api/v1/auth/logout — invalidate current session."""
    permission_classes = [IsAuthenticated]

    def post(self, request):
        from apps.core.utils import hash_token as _hash
        auth_header = request.headers.get('Authorization', '')
        if auth_header.startswith('Bearer '):
            token_str = auth_header.split(' ', 1)[1]
            token_hash = _hash(token_str)
            session = UserSession.objects.filter(
                user=request.user, token_hash=token_hash, is_active=True
            ).first()
            if session:
                AuditService.log(
                    action=AuditAction.USER_LOGOUT, entity_type='user',
                    entity_id=str(request.user.id), business=request.user.business,
                    user=request.user, session=session, request=request,
                )
                session.is_active = False
                session.terminated_at = timezone.now()
                session.termination_reason = 'logout'
                session.save(update_fields=['is_active', 'terminated_at', 'termination_reason', 'updated_at'])

        response = Response({'success': True, 'data': {'message': 'Logged out'}})
        response.delete_cookie('refresh_token')
        return response


class TokenRefreshView(APIView):
    """POST /api/v1/auth/refresh — refresh access token from HttpOnly cookie."""
    permission_classes = [AllowAny]

    def post(self, request):
        refresh_str = request.COOKIES.get('refresh_token')
        if not refresh_str:
            return Response(
                {'success': False, 'error': {'code': 'TOKEN_INVALID', 'message': 'No refresh token'}},
                status=status.HTTP_401_UNAUTHORIZED,
            )
        try:
            refresh = RefreshToken(refresh_str)
            access_str = str(refresh.access_token)
            response = Response({
                'success': True,
                'data': {'access_token': access_str, 'expires_in': 900}
            })
            # Rotate: set new refresh cookie
            response.set_cookie(
                'refresh_token', str(refresh),
                httponly=True, secure=True, samesite='Lax', max_age=60 * 60 * 24 * 7,
            )
            return response
        except TokenError as e:
            return Response(
                {'success': False, 'error': {'code': 'TOKEN_INVALID', 'message': str(e)}},
                status=status.HTTP_401_UNAUTHORIZED,
            )


class TerminalTakeoverView(APIView):
    """
    POST /api/v1/auth/terminal/takeover

    Permission: manager or owner only (cashiers get hard 403).

    Atomically:
      1. Validate credential
      2. Terminate old session
      3. Force-close open shift
      4. Create terminal_takeovers audit record
      5. Issue new session token
    """
    permission_classes = [IsAuthenticated, CanOverrideTerminal]

    def post(self, request):
        serializer = TerminalTakeoverSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data

        # Validate override credential
        user = request.user
        self._validate_credential(user, data['approval_method'], data['credential'])

        branch_id = data['branch_id']

        with transaction.atomic():
            result = self._execute_takeover(user, branch_id, data)

        access_str, refresh_str, _ = _issue_tokens(
            user, request,
            device_fingerprint=request.headers.get('X-Device-Fingerprint')
        )

        response = Response({
            'success': True,
            'data': {
                'access_token': access_str,
                'token_type': 'Bearer',
                'expires_in': 900,
                **result,
            }
        })
        response.set_cookie(
            'refresh_token', refresh_str,
            httponly=True, secure=True, samesite='Lax', max_age=60 * 60 * 24 * 7,
        )
        return response

    def _validate_credential(self, user, method, credential):
        from apps.core.exceptions import RetailGuardException
        if method == 'pin':
            if not user.verify_override_pin(credential):
                raise RetailGuardException(
                    detail='Invalid override PIN.',
                    code='INVALID_CREDENTIALS',
                    extra={'method': 'pin'}
                )
        else:  # password or re_auth
            if not user.check_password(credential):
                raise RetailGuardException(
                    detail='Invalid password.',
                    code='INVALID_CREDENTIALS',
                    extra={'method': method}
                )

    def _execute_takeover(self, approving_user, branch_id, data) -> dict:
        from apps.shifts.models import Shift
        from apps.users.terminal_takeover import TerminalTakeover

        # 1. Find and terminate old session (if any)
        old_shift = Shift.objects.filter(branch_id=branch_id, status='open').first()
        old_session = None
        old_device_id = 'unknown'

        if old_shift:
            old_session = UserSession.objects.filter(
                user=old_shift.cashier, is_active=True
            ).first()
            if old_session:
                old_device_id = old_session.device_fingerprint or 'unknown'
                old_session.terminate(
                    reason='terminal_takeover',
                    terminated_by_user=approving_user,
                )

            # 2. Force-close the open shift
            old_shift.status = 'force_closed'
            old_shift.is_force_closed = True
            old_shift.force_closed_by = approving_user
            old_shift.force_closed_at = timezone.now()
            old_shift.force_close_reason = data.get('reason', '')
            old_shift.closed_at = timezone.now()
            old_shift.save(update_fields=[
                'status', 'is_force_closed', 'force_closed_by',
                'force_closed_at', 'force_close_reason', 'closed_at', 'updated_at'
            ])

        # 3. Create takeover audit record
        new_device_id = data.get('device_fingerprint') or self.request.headers.get('X-Device-Fingerprint', 'new')

        TerminalTakeover.objects.create(
            branch_id=branch_id,
            old_shift=old_shift,
            previous_device_id=old_device_id,
            new_device_id=new_device_id,
            previous_session=old_session,
            approved_by=approving_user,
            approval_method=data['approval_method'],
            reason=data.get('reason', ''),
        )

        # session isn't passed explicitly here — self.request carries the
        # approving user's own still-valid Bearer token, so AuditService.log
        # auto-resolves *their* current session, which is the correct actor
        # session for this event (not the terminated cashier's session,
        # which is recorded separately via previous_session on
        # TerminalTakeover above).
        AuditService.log(
            action=AuditAction.TERMINAL_OVERRIDE, entity_type='branch',
            entity_id=str(branch_id), business=approving_user.business,
            user=approving_user, request=self.request,
            new_values={
                'previous_device_id': old_device_id,
                'new_device_id': new_device_id,
                'previous_cashier_id': str(old_shift.cashier_id) if old_shift else None,
                'affected_shift_id': str(old_shift.id) if old_shift else None,
                'approval_method': data['approval_method'],
            },
        )

        return {
            'takeover_recorded': True,
            'previous_shift_force_closed': old_shift is not None,
            'affected_shift_id': str(old_shift.id) if old_shift else None,
        }


class UserMeView(APIView):
    """GET /api/v1/auth/me — current user profile."""
    permission_classes = [IsAuthenticated]

    def get(self, request):
        return Response({
            'success': True,
            'data': UserMeSerializer(request.user).data
        })
