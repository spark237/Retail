"""
RetailGuard Authentication — Auth Backend

Supports login by phone OR email.
Custom JWT token is in apps.authentication.tokens.
"""
from django.contrib.auth import get_user_model

User = get_user_model()


# ─── AUTH BACKEND ────────────────────────────────────────────────────────────

class RetailGuardAuthBackend:
    """
    Authenticates by phone OR email + password.
    Phone is the primary identifier for field staff.
    Email used by office-based staff and admins.

    Does NOT check account lock here — lock check is in the login view
    so we can return rich error details (locked_until timestamp).
    """

    def authenticate(self, request, identifier=None, password=None, **kwargs):
        if not identifier or not password:
            return None

        user = self._find_user(identifier)
        if user is None:
            return None

        if user.check_password(password):
            return user
        return None

    def _find_user(self, identifier: str):
        """Try phone first (most common for cashiers), then email."""
        try:
            return User.all_objects.get(phone=identifier, is_deleted=False)
        except User.DoesNotExist:
            pass
        try:
            return User.all_objects.get(email__iexact=identifier, is_deleted=False)
        except User.DoesNotExist:
            return None

    def get_user(self, user_id):
        try:
            return User.all_objects.get(pk=user_id, is_deleted=False)
        except User.DoesNotExist:
            return None
