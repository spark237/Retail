"""
RetailGuard Authentication — Serializers
"""
from django.contrib.auth import get_user_model
from rest_framework import serializers

User = get_user_model()


class LoginSerializer(serializers.Serializer):
    identifier          = serializers.CharField(help_text='Phone number or email')
    password            = serializers.CharField(write_only=True)
    branch_id           = serializers.UUIDField(required=False, allow_null=True)
    device_fingerprint  = serializers.CharField(required=False, allow_blank=True, max_length=200)


class TerminalTakeoverSerializer(serializers.Serializer):
    branch_id       = serializers.UUIDField()
    approval_method = serializers.ChoiceField(choices=['pin', 'password', 're_auth'])
    credential      = serializers.CharField(write_only=True)
    reason          = serializers.CharField(max_length=500)


class SetOverridePinSerializer(serializers.Serializer):
    current_password    = serializers.CharField(write_only=True)
    override_pin        = serializers.CharField(
        write_only=True, min_length=4, max_length=6
    )

    def validate_override_pin(self, value):
        if not value.isdigit():
            raise serializers.ValidationError('Override PIN must contain digits only.')
        return value


class UserMeSerializer(serializers.ModelSerializer):
    full_name           = serializers.ReadOnlyField()
    primary_branch_id   = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = [
            'id', 'first_name', 'last_name', 'full_name',
            'phone', 'email', 'role', 'business_id',
            'primary_branch_id', 'last_login_at',
        ]
        read_only_fields = fields

    def get_primary_branch_id(self, obj):
        primary = obj.branch_assignments.filter(
            is_primary=True, revoked_at__isnull=True
        ).first()
        if primary and primary.branch_id:
            return str(primary.branch_id)
        return None
