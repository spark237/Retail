"""
RetailGuard Authentication — Custom JWT Token

Separated from backends.py for clean import paths.
Embeds business_id, role, and primary_branch_id into the JWT payload
so every authenticated request has tenant + RBAC context without
an extra database lookup.
"""
from rest_framework_simplejwt.tokens import AccessToken


class RetailGuardAccessToken(AccessToken):
    """
    Extended JWT payload with RetailGuard-specific claims.

    Standard claims (from simplejwt): user_id, exp, iat, jti, token_type
    Added claims:
      business_id:       tenant isolation without DB lookup per request
      role:              RBAC decisions without DB lookup per request
      primary_branch_id: cashier's default branch (null for owner/manager)
    """

    @classmethod
    def for_user(cls, user):
        token = super().for_user(user)
        token['business_id']       = str(user.business_id)
        token['role']              = user.role
        primary = (
            user.branch_assignments
            .filter(is_primary=True, revoked_at__isnull=True)
            .first()
        )
        token['primary_branch_id'] = (
            str(primary.branch_id)
            if primary and primary.branch_id
            else None
        )
        return token
