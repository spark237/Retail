from django.urls import path

from apps.authentication.views import (
    LoginView,
    LogoutView,
    TerminalTakeoverView,
    TokenRefreshView,
    UserMeView,
)

urlpatterns = [
    path('login/',              LoginView.as_view(),            name='auth-login'),
    path('logout/',             LogoutView.as_view(),           name='auth-logout'),
    path('refresh/',            TokenRefreshView.as_view(),     name='auth-refresh'),
    path('terminal/takeover/',  TerminalTakeoverView.as_view(), name='auth-terminal-takeover'),
    path('me/',                 UserMeView.as_view(),           name='auth-me'),
]
