from django.urls import path

from apps.expenses.views import (
    ExpenseApproveView,
    ExpenseCategoryListCreateView,
    ExpenseDetailView,
    ExpenseListCreateView,
    ExpenseRejectView,
)

urlpatterns = [
    path('',                            ExpenseListCreateView.as_view(),     name='expense-list'),
    path('<uuid:expense_id>/',          ExpenseDetailView.as_view(),         name='expense-detail'),
    path('<uuid:expense_id>/approve/',  ExpenseApproveView.as_view(),        name='expense-approve'),
    path('<uuid:expense_id>/reject/',   ExpenseRejectView.as_view(),         name='expense-reject'),
    path('categories/',                 ExpenseCategoryListCreateView.as_view(), name='expense-categories'),
]
