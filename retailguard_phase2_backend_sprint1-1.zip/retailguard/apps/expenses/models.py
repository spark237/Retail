"""
RetailGuard Expenses — ExpenseCategory, Expense

Tracks operational costs per branch for accurate P&L.
Gross Profit = Revenue - COGS - Expenses
All amounts in XAF integer.
"""
import uuid

from django.conf import settings
from django.db import models

from apps.core.models import SoftDeleteModel


class ExpenseCategory(models.Model):
    """Seeded defaults: Rent, Salaries, Fuel, Internet, Restocking, Maintenance, Miscellaneous."""
    id          = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    business    = models.ForeignKey('branches.Business', on_delete=models.PROTECT, related_name='expense_categories')
    name        = models.CharField(max_length=100)
    description = models.TextField(blank=True, null=True)
    is_active   = models.BooleanField(default=True)
    created_at  = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'expense_categories'
        constraints = [
            models.UniqueConstraint(fields=['business', 'name'], name='uq_expense_cat'),
        ]

    def __str__(self):
        return self.name


class ExpenseStatus(models.TextChoices):
    PENDING  = 'pending',  'Pending Approval'
    APPROVED = 'approved', 'Approved'
    REJECTED = 'rejected', 'Rejected'


class Expense(SoftDeleteModel):
    id                  = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    business            = models.ForeignKey('branches.Business', on_delete=models.PROTECT, related_name='expenses')
    branch              = models.ForeignKey('branches.Branch', null=True, blank=True, on_delete=models.PROTECT, related_name='expenses')
    category            = models.ForeignKey(ExpenseCategory, on_delete=models.PROTECT, related_name='expenses')
    amount              = models.IntegerField()   # XAF
    description         = models.TextField()
    expense_date        = models.DateField()
    payment_method      = models.CharField(
        max_length=20,
        choices=[
            ('CASH', 'Cash'), ('MTN_MOMO', 'MTN MoMo'),
            ('ORANGE_MONEY', 'Orange Money'), ('BANK_TRANSFER', 'Bank Transfer'),
        ],
        default='CASH',
    )
    receipt_reference   = models.CharField(max_length=100, blank=True, null=True)
    status              = models.CharField(max_length=20, choices=ExpenseStatus.choices, default=ExpenseStatus.PENDING)
    submitted_by        = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name='submitted_expenses')
    approved_by         = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.PROTECT, related_name='approved_expenses')
    approved_at         = models.DateTimeField(null=True, blank=True)
    rejection_note      = models.TextField(blank=True, null=True)

    class Meta:
        db_table = 'expenses'
        ordering = ['-expense_date', '-created_at']
        constraints = [
            models.CheckConstraint(condition=models.Q(amount__gt=0), name='expense_amount_pos'),
        ]
        indexes = [
            models.Index(fields=['branch', '-expense_date'], name='idx_expenses_branch_date'),
            models.Index(
                fields=['business', 'status'],
                name='idx_expenses_pending',
                condition=models.Q(status='pending'),
            ),
        ]

    def __str__(self):
        return f"{self.category.name}: {self.amount} XAF [{self.status}]"
