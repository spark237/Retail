"""RetailGuard Expenses — Serializers"""
from rest_framework import serializers

from apps.expenses.models import Expense, ExpenseCategory


class ExpenseCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model  = ExpenseCategory
        fields = ['id', 'name', 'description', 'is_active', 'created_at']
        read_only_fields = ['id', 'created_at']


class ExpenseSerializer(serializers.ModelSerializer):
    category_name    = serializers.CharField(source='category.name',        read_only=True)
    submitted_by_name = serializers.CharField(source='submitted_by.full_name', read_only=True)
    approved_by_name = serializers.CharField(source='approved_by.full_name', read_only=True, default=None)
    branch_name      = serializers.CharField(source='branch.name',           read_only=True, default=None)

    class Meta:
        model  = Expense
        fields = [
            'id', 'branch_id', 'branch_name', 'category_id', 'category_name',
            'amount', 'description', 'expense_date', 'payment_method',
            'receipt_reference', 'status',
            'submitted_by_id', 'submitted_by_name',
            'approved_by_id', 'approved_by_name',
            'approved_at', 'rejection_note', 'created_at',
        ]


class ExpenseCreateSerializer(serializers.Serializer):
    branch_id         = serializers.UUIDField(required=False, allow_null=True)
    category_id       = serializers.UUIDField()
    amount            = serializers.IntegerField(min_value=1)
    description       = serializers.CharField(min_length=5)
    expense_date      = serializers.DateField()
    payment_method    = serializers.ChoiceField(
        choices=['CASH', 'MTN_MOMO', 'ORANGE_MONEY', 'BANK_TRANSFER'], default='CASH'
    )
    receipt_reference = serializers.CharField(required=False, allow_blank=True)
