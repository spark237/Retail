"""RetailGuard Expenses — Views"""
from django.utils import timezone
from rest_framework import status as http_status
from rest_framework.exceptions import NotFound
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.audit.models import AuditService
from apps.core.pagination import StandardPagination
from apps.core.permissions import IsManagerOrOwner
from apps.core.utils import success_response
from apps.expenses.models import Expense, ExpenseCategory, ExpenseStatus
from apps.expenses.serializers import ExpenseCategorySerializer, ExpenseCreateSerializer, ExpenseSerializer


class ExpenseListCreateView(APIView):
    permission_classes = [IsManagerOrOwner]

    def get(self, request):
        qs = Expense.objects.filter(
            business=request.user.business, is_deleted=False
        ).select_related('category', 'submitted_by', 'approved_by', 'branch').order_by('-expense_date')

        if request.user.role != 'owner':
            branch_ids = list(
                request.user.branch_assignments
                .filter(revoked_at__isnull=True, branch_id__isnull=False)
                .values_list('branch_id', flat=True)
            )
            qs = qs.filter(branch_id__in=branch_ids)
        if bid := request.query_params.get('branch_id'):
            qs = qs.filter(branch_id=bid)
        if cat := request.query_params.get('category_id'):
            qs = qs.filter(category_id=cat)
        if st := request.query_params.get('status'):
            qs = qs.filter(status=st)
        if from_dt := request.query_params.get('from_date'):
            qs = qs.filter(expense_date__gte=from_dt)
        if to_dt := request.query_params.get('to_date'):
            qs = qs.filter(expense_date__lte=to_dt)

        paginator = StandardPagination()
        page = paginator.paginate_queryset(qs, request)
        return paginator.get_paginated_response(ExpenseSerializer(page, many=True).data)

    def post(self, request):
        s = ExpenseCreateSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        data = s.validated_data

        try:
            category = ExpenseCategory.objects.get(
                id=data['category_id'], business=request.user.business, is_active=True
            )
        except ExpenseCategory.DoesNotExist:
            raise NotFound('Expense category not found.')

        expense = Expense.objects.create(
            business=request.user.business,
            branch_id=data.get('branch_id'),
            category=category,
            amount=data['amount'],
            description=data['description'],
            expense_date=data['expense_date'],
            payment_method=data['payment_method'],
            receipt_reference=data.get('receipt_reference', ''),
            submitted_by=request.user,
            status=ExpenseStatus.PENDING,
        )
        AuditService.log(action='expense.submitted', entity_type='expense', entity_id=str(expense.id),
                         business=request.user.business, request=request)
        return success_response(ExpenseSerializer(expense).data, status=201)


class ExpenseDetailView(APIView):
    permission_classes = [IsManagerOrOwner]

    def _get(self, request, expense_id):
        try:
            return Expense.objects.select_related(
                'category', 'submitted_by', 'approved_by', 'branch'
            ).get(id=expense_id, business=request.user.business, is_deleted=False)
        except Expense.DoesNotExist:
            raise NotFound('Expense not found.')

    def get(self, request, expense_id):
        return success_response(ExpenseSerializer(self._get(request, expense_id)).data)

    def delete(self, request, expense_id):
        expense = self._get(request, expense_id)
        if expense.status == ExpenseStatus.APPROVED:
            from apps.core.exceptions import RetailGuardException
            raise RetailGuardException(
                detail='Cannot delete an approved expense.', code='EXPENSE_ALREADY_APPROVED'
            )
        expense.soft_delete(deleted_by_user=request.user)
        return Response(status=http_status.HTTP_204_NO_CONTENT)


class ExpenseApproveView(APIView):
    permission_classes = [IsManagerOrOwner]

    def post(self, request, expense_id):
        try:
            expense = Expense.objects.get(
                id=expense_id, business=request.user.business, status=ExpenseStatus.PENDING
            )
        except Expense.DoesNotExist:
            raise NotFound('Expense not found or already processed.')
        if str(expense.submitted_by_id) == str(request.user.id):
            from apps.core.exceptions import RetailGuardException
            raise RetailGuardException(
                detail='You cannot approve your own expense.', code='SELF_APPROVAL_FORBIDDEN'
            )
        expense.status = ExpenseStatus.APPROVED
        expense.approved_by = request.user
        expense.approved_at = timezone.now()
        expense.save(update_fields=['status', 'approved_by', 'approved_at', 'updated_at'])
        AuditService.log(action='expense.approved', entity_type='expense', entity_id=str(expense.id),
                         business=request.user.business, request=request)
        return success_response(ExpenseSerializer(expense).data)


class ExpenseRejectView(APIView):
    permission_classes = [IsManagerOrOwner]

    def post(self, request, expense_id):
        try:
            expense = Expense.objects.get(
                id=expense_id, business=request.user.business, status=ExpenseStatus.PENDING
            )
        except Expense.DoesNotExist:
            raise NotFound('Expense not found or already processed.')
        note = request.data.get('rejection_note', '').strip()
        if not note:
            from rest_framework.exceptions import ValidationError
            raise ValidationError({'rejection_note': 'Rejection note is required.'})
        expense.status = ExpenseStatus.REJECTED
        expense.rejection_note = note
        expense.save(update_fields=['status', 'rejection_note', 'updated_at'])
        return success_response(ExpenseSerializer(expense).data)


class ExpenseCategoryListCreateView(APIView):
    permission_classes = [IsManagerOrOwner]

    def get(self, request):
        qs = ExpenseCategory.objects.filter(business=request.user.business, is_active=True)
        return success_response(ExpenseCategorySerializer(qs, many=True).data)

    def post(self, request):
        if request.user.role != 'owner':
            from rest_framework.exceptions import PermissionDenied
            raise PermissionDenied()
        s = ExpenseCategorySerializer(data=request.data)
        s.is_valid(raise_exception=True)
        cat = ExpenseCategory.objects.create(business=request.user.business, **s.validated_data)
        return success_response(ExpenseCategorySerializer(cat).data, status=201)
