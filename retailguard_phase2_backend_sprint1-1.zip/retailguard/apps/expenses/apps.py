from django.apps import AppConfig


class ExpensesConfigAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.expenses'
    label = 'expenses'
