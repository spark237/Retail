"""
RetailGuard Users — User Model

This is AUTH_USER_MODEL. All authentication flows through this model.
UUID primary key. Phone or email required (not both).
Role drives all RBAC decisions.
override_pin_hash is used for quick manager approvals on the POS device.
"""
import uuid

from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin
from django.db import models
from django.utils import timezone

from apps.core.models import TimestampedModel


class UserRole(models.TextChoices):
    OWNER           = 'owner',           'Owner'
    MANAGER         = 'manager',         'Manager'
    CASHIER         = 'cashier',         'Cashier'
    WAREHOUSE_STAFF = 'warehouse_staff', 'Warehouse Staff'


class UserManager(models.Manager):
    """
    Custom manager for the UUID-keyed User model.
    Does not use Django's default create_user / create_superuser
    pattern — RetailGuard users are created through the API only.
    """

    def create_user(self, business, role, password, **extra_fields):
        if not password:
            raise ValueError('Password is required.')
        if not business:
            raise ValueError('Business is required.')
        user = self.model(business=business, role=role, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password, **extra_fields):
        """Only used for initial Django admin setup."""
        extra_fields.setdefault('role', UserRole.OWNER)
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        extra_fields.setdefault('first_name', 'Super')
        extra_fields.setdefault('last_name', 'Admin')
        # Superuser has no business — only for Django admin access
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def get_queryset(self):
        return super().get_queryset().filter(is_deleted=False)


class AllUsersManager(models.Manager):
    """Unfiltered — includes soft-deleted users. Use for admin/audit."""
    pass


class User(AbstractBaseUser, PermissionsMixin):
    """
    RetailGuard User — PRIMARY AUTH MODEL

    Design decisions:
    - UUID PK: prevents user ID enumeration attacks (/api/users/1,2,3...)
    - Phone OR email required: field staff in Cameroon may not have email
    - override_pin_hash: 4-6 digit PIN for quick POS-side manager approvals
      (price overrides, void approvals) without full password entry
    - Soft delete: deactivated users never physically removed — audit integrity
    - Role stored directly on user: no groups/permissions overhead
    - business FK: all data scoped per tenant from the user level up
    """

    # ─── IDENTITY ────────────────────────────────────────────────
    id              = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    business        = models.ForeignKey(
        'branches.Business',
        on_delete=models.PROTECT,
        related_name='users',
    )
    employee_id     = models.CharField(max_length=50, blank=True, null=True)
    first_name      = models.CharField(max_length=100)
    last_name       = models.CharField(max_length=100)
    phone           = models.CharField(max_length=20, unique=True, null=True, blank=True)
    email           = models.EmailField(unique=True, null=True, blank=True)

    # ─── AUTH ────────────────────────────────────────────────────
    # password stored via AbstractBaseUser.set_password() → password field
    override_pin_hash = models.CharField(max_length=255, null=True, blank=True)

    # ─── RBAC ────────────────────────────────────────────────────
    role = models.CharField(
        max_length=30,
        choices=UserRole.choices,
        default=UserRole.CASHIER,
    )

    # ─── STATUS ──────────────────────────────────────────────────
    is_active       = models.BooleanField(default=True)
    is_staff        = models.BooleanField(default=False)   # Django admin access only
    is_deleted      = models.BooleanField(default=False)

    # ─── SECURITY ────────────────────────────────────────────────
    last_login_at           = models.DateTimeField(null=True, blank=True)
    failed_login_attempts   = models.IntegerField(default=0)
    locked_until            = models.DateTimeField(null=True, blank=True)

    # ─── AUDIT ───────────────────────────────────────────────────
    deleted_at  = models.DateTimeField(null=True, blank=True)
    deleted_by  = models.ForeignKey(
        'self', null=True, blank=True,
        on_delete=models.SET_NULL,
        related_name='deleted_users',
    )
    created_by  = models.ForeignKey(
        'self', null=True, blank=True,
        on_delete=models.SET_NULL,
        related_name='created_users',
    )
    created_at  = models.DateTimeField(auto_now_add=True)
    updated_at  = models.DateTimeField(auto_now=True)

    objects     = UserManager()
    all_objects = AllUsersManager()

    USERNAME_FIELD  = 'email'
    REQUIRED_FIELDS = []

    class Meta:
        db_table    = 'users'
        verbose_name = 'User'
        verbose_name_plural = 'Users'
        indexes = [
            models.Index(
                fields=['business', 'role'],
                name='idx_users_business_role',
                condition=models.Q(is_deleted=False),
            ),
        ]
        constraints = [
            models.CheckConstraint(
                condition=models.Q(phone__isnull=False) | models.Q(email__isnull=False),
                name='require_phone_or_email',
            ),
        ]

    def __str__(self):
        return f"{self.full_name} ({self.role}) — {self.business_id}"

    # ─── PROPERTIES ──────────────────────────────────────────────

    @property
    def full_name(self):
        return f"{self.first_name} {self.last_name}"

    @property
    def is_owner(self):
        return self.role == UserRole.OWNER

    @property
    def is_manager(self):
        return self.role == UserRole.MANAGER

    @property
    def is_cashier(self):
        return self.role == UserRole.CASHIER

    @property
    def is_warehouse_staff(self):
        return self.role == UserRole.WAREHOUSE_STAFF

    @property
    def is_manager_or_above(self):
        return self.role in (UserRole.OWNER, UserRole.MANAGER)

    @property
    def is_locked(self):
        if self.locked_until and self.locked_until > timezone.now():
            return True
        return False

    # ─── AUTH METHODS ────────────────────────────────────────────

    def record_failed_login(self):
        from django.conf import settings
        max_attempts = settings.RETAILGUARD['LOGIN_MAX_ATTEMPTS']
        lockout_minutes = settings.RETAILGUARD['LOGIN_LOCKOUT_MINUTES']

        self.failed_login_attempts += 1
        if self.failed_login_attempts >= max_attempts:
            from datetime import timedelta
            self.locked_until = timezone.now() + timedelta(minutes=lockout_minutes)
        self.save(update_fields=['failed_login_attempts', 'locked_until', 'updated_at'])

    def record_successful_login(self):
        self.failed_login_attempts = 0
        self.locked_until = None
        self.last_login_at = timezone.now()
        self.save(update_fields=[
            'failed_login_attempts', 'locked_until', 'last_login_at', 'updated_at'
        ])

    def set_override_pin(self, raw_pin: str):
        from apps.core.utils import hash_pin
        self.override_pin_hash = hash_pin(raw_pin)
        self.save(update_fields=['override_pin_hash', 'updated_at'])

    def verify_override_pin(self, raw_pin: str) -> bool:
        from apps.core.utils import verify_pin
        if not self.override_pin_hash:
            return False
        return verify_pin(raw_pin, self.override_pin_hash)

    # ─── SOFT DELETE ─────────────────────────────────────────────

    def soft_delete(self, deleted_by_user=None):
        self.is_deleted = True
        self.is_active = False
        self.deleted_at = timezone.now()
        self.deleted_by = deleted_by_user
        self.save(update_fields=[
            'is_deleted', 'is_active', 'deleted_at', 'deleted_by', 'updated_at'
        ])


class UserSession(TimestampedModel):
    """
    Tracks every active login session.
    token_hash: SHA-256 of JWT — never store raw tokens.
    device_fingerprint: used to detect terminal occupation at branch.
    Terminated sessions are kept for full audit trail.
    """

    class TerminationReason(models.TextChoices):
        LOGOUT            = 'logout',            'User logout'
        TERMINAL_TAKEOVER = 'terminal_takeover', 'Terminal takeover'
        EXPIRED           = 'expired',           'Token expired'
        ADMIN_REVOKE      = 'admin_revoke',      'Admin revoked'
        FORCE_CLOSE       = 'force_close',       'Shift force closed'

    id                  = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user                = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name='sessions'
    )
    token_hash          = models.CharField(max_length=255)
    device_info         = models.JSONField(default=dict)
    device_fingerprint  = models.CharField(max_length=200, null=True, blank=True)
    ip_address          = models.GenericIPAddressField(null=True, blank=True)
    is_active           = models.BooleanField(default=True)
    expires_at          = models.DateTimeField()
    last_activity       = models.DateTimeField(default=timezone.now)
    terminated_at       = models.DateTimeField(null=True, blank=True)
    terminated_by       = models.ForeignKey(
        User, null=True, blank=True,
        on_delete=models.SET_NULL,
        related_name='terminated_sessions',
    )
    termination_reason  = models.CharField(
        max_length=30,
        choices=TerminationReason.choices,
        null=True, blank=True,
    )

    class Meta:
        db_table = 'user_sessions'
        indexes = [
            models.Index(fields=['token_hash'], name='idx_sessions_token'),
            models.Index(
                fields=['user', 'is_active'],
                name='idx_sessions_user_active',
                condition=models.Q(is_active=True),
            ),
            models.Index(
                fields=['device_fingerprint'],
                name='idx_sessions_fingerprint',
                condition=models.Q(device_fingerprint__isnull=False),
            ),
        ]

    def terminate(self, reason: str, terminated_by_user=None):
        self.is_active = False
        self.terminated_at = timezone.now()
        self.termination_reason = reason
        self.terminated_by = terminated_by_user
        self.save(update_fields=[
            'is_active', 'terminated_at', 'termination_reason', 'terminated_by'
        ])


class UserBranchAssignment(models.Model):
    """Maps users to branches or warehouses. Supports revocation."""

    id              = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user            = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name='branch_assignments'
    )
    branch          = models.ForeignKey(
        'branches.Branch', null=True, blank=True,
        on_delete=models.CASCADE, related_name='assignments',
    )
    warehouse       = models.ForeignKey(
        'branches.Warehouse', null=True, blank=True,
        on_delete=models.CASCADE, related_name='assignments',
    )
    is_primary      = models.BooleanField(default=False)
    assigned_at     = models.DateTimeField(auto_now_add=True)
    assigned_by     = models.ForeignKey(
        User, on_delete=models.PROTECT, related_name='made_assignments'
    )
    revoked_at      = models.DateTimeField(null=True, blank=True)
    revoked_by      = models.ForeignKey(
        User, null=True, blank=True,
        on_delete=models.SET_NULL,
        related_name='revoked_assignments',
    )

    class Meta:
        db_table = 'user_branch_assignments'
        constraints = [
            models.CheckConstraint(
                condition=(
                    models.Q(branch__isnull=False, warehouse__isnull=True) |
                    models.Q(warehouse__isnull=False, branch__isnull=True)
                ),
                name='user_assignment_location_exclusive',
            ),
        ]

    def __str__(self):
        location = self.branch or self.warehouse
        return f"{self.user.full_name} @ {location}"

    @property
    def is_active(self):
        return self.revoked_at is None


# TerminalTakeover lives in its own module (see terminal_takeover.py
# docstring — avoids a circular import: authentication -> shifts -> users).
# It must still be imported here so Django's app registry actually
# discovers and migrates it — a separate module that nothing imports never
# gets its model classes registered at all. This was a real bug: the model
# existed, had correct fields, but was never in any migration and the
# table never existed in the database, because nothing ever imported it.
from apps.users.terminal_takeover import TerminalTakeover  # noqa: E402, F401
