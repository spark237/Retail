"""
RetailGuard Users — TerminalTakeover model
Placed in users app to avoid circular imports (authentication → shifts → users).
"""
import uuid

from django.conf import settings
from django.db import models


class TerminalTakeover(models.Model):
    """
    Immutable audit record for every forced terminal switch.
    Created atomically with session termination + shift force-close.
    Answers the fraud question: "Who killed the original session and why?"

    Fraud rule: FREQUENT_TERMINAL_TAKEOVERS fires if count > threshold in 24h.
    """
    id                  = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    branch              = models.ForeignKey(
        'branches.Branch', on_delete=models.PROTECT, related_name='terminal_takeovers'
    )
    old_shift           = models.ForeignKey(
        'shifts.Shift', on_delete=models.PROTECT,
        related_name='takeovers_as_old_shift',
        null=True, blank=True,
    )
    previous_device_id  = models.CharField(max_length=255)
    new_device_id       = models.CharField(max_length=255)
    previous_session    = models.ForeignKey(
        'users.UserSession',
        null=True, blank=True,
        on_delete=models.SET_NULL,
        related_name='takeovers_as_previous',
    )
    new_session         = models.ForeignKey(
        'users.UserSession',
        null=True, blank=True,
        on_delete=models.SET_NULL,
        related_name='takeovers_as_new',
    )
    approved_by         = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name='approved_takeovers',
    )
    approval_method     = models.CharField(
        max_length=20,
        choices=[('pin', 'PIN'), ('password', 'Password'), ('re_auth', 'Re-Auth')],
    )
    reason              = models.TextField()
    created_at          = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'terminal_takeovers'
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['branch', '-created_at'], name='idx_takeovers_branch'),
            models.Index(fields=['approved_by', '-created_at'], name='idx_takeovers_approved_by'),
        ]

    def __str__(self):
        return f"Takeover at {self.branch} by {self.approved_by} @ {self.created_at}"
