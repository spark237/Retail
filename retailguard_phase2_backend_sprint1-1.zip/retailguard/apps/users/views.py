"""RetailGuard Users — Views"""
from django.contrib.auth import get_user_model
from django.utils import timezone
from rest_framework import status
from rest_framework.exceptions import NotFound
from rest_framework.views import APIView

from apps.audit.models import AuditService
from apps.branches.models import Branch
from apps.core.pagination import StandardPagination
from apps.core.permissions import IsAnyActiveStaff, IsOwner
from apps.core.utils import success_response
from apps.users.models import UserBranchAssignment
from apps.users.serializers import (
    PasswordChangeSerializer,
    SetOverridePinSerializer,
    UserCreateSerializer,
    UserDetailSerializer,
    UserListSerializer,
    UserUpdateSerializer,
)

User = get_user_model()


class UserListCreateView(APIView):
    permission_classes = [IsOwner]

    def get(self, request):
        qs = User.objects.filter(
            business=request.user.business
        ).prefetch_related('branch_assignments__branch').order_by('last_name', 'first_name')

        if role := request.query_params.get('role'):
            qs = qs.filter(role=role)
        if branch_id := request.query_params.get('branch_id'):
            qs = qs.filter(branch_assignments__branch_id=branch_id, branch_assignments__revoked_at__isnull=True)
        if is_active := request.query_params.get('is_active'):
            qs = qs.filter(is_active=is_active.lower() == 'true')

        paginator = StandardPagination()
        page = paginator.paginate_queryset(qs, request)
        return paginator.get_paginated_response(UserListSerializer(page, many=True).data)

    def post(self, request):
        serializer = UserCreateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data

        user = User.objects.create_user(
            business=request.user.business,
            role=data['role'],
            password=data['password'],
            first_name=data['first_name'],
            last_name=data['last_name'],
            phone=data.get('phone'),
            email=data.get('email'),
            employee_id=data.get('employee_id'),
            created_by=request.user,
        )

        if pin := data.get('override_pin'):
            user.set_override_pin(pin)

        if branch_id := data.get('branch_id'):
            try:
                branch = Branch.objects.get(id=branch_id, business=request.user.business)
                UserBranchAssignment.objects.create(
                    user=user, branch=branch, is_primary=True, assigned_by=request.user
                )
            except Branch.DoesNotExist:
                pass

        AuditService.log(
            action='user.created', entity_type='user', entity_id=str(user.id),
            business=request.user.business,
            new_values={'role': user.role, 'name': user.full_name},
            request=request,
        )
        return success_response(UserDetailSerializer(user).data, status=201)


class UserDetailView(APIView):

    def get_permissions(self):
        if self.request.method in ('PATCH',):
            return [IsAnyActiveStaff()]
        return [IsOwner()]

    def _get_user(self, request, user_id):
        # Owners see all users in their business; others can only see themselves
        if request.user.role == 'owner':
            try:
                return User.objects.get(id=user_id, business=request.user.business)
            except User.DoesNotExist:
                raise NotFound('User not found.')
        else:
            if str(request.user.id) != str(user_id):
                raise NotFound('User not found.')
            return request.user

    def get(self, request, user_id):
        user = self._get_user(request, user_id)
        return success_response(UserDetailSerializer(user).data)

    def patch(self, request, user_id):
        user = self._get_user(request, user_id)

        # Non-owners can only edit their own record with limited fields
        if request.user.role != 'owner' and str(request.user.id) != str(user_id):
            from rest_framework.exceptions import PermissionDenied
            raise PermissionDenied()

        if 'current_password' in request.data:
            # Password change path
            s = PasswordChangeSerializer(data=request.data)
            s.is_valid(raise_exception=True)
            if not user.check_password(s.validated_data['current_password']):
                from apps.core.exceptions import InvalidCredentialsError
                raise InvalidCredentialsError(detail='Current password is incorrect.')
            user.set_password(s.validated_data['new_password'])
            user.save(update_fields=['password', 'updated_at'])
            AuditService.log(action='user.password_changed', entity_type='user', entity_id=str(user.id),
                             business=user.business, request=request)
            return success_response({'message': 'Password updated.'})

        serializer = UserUpdateSerializer(data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        for field, value in serializer.validated_data.items():
            setattr(user, field, value)
        user.save()
        return success_response(UserDetailSerializer(user).data)


class UserDeactivateView(APIView):
    permission_classes = [IsOwner]

    def post(self, request, user_id):
        try:
            user = User.objects.get(id=user_id, business=request.user.business)
        except User.DoesNotExist:
            raise NotFound('User not found.')

        if str(user.id) == str(request.user.id):
            from apps.core.exceptions import RetailGuardException
            raise RetailGuardException(detail='You cannot deactivate your own account.', code='SELF_DEACTIVATION')

        # Invalidate active sessions
        user.sessions.filter(is_active=True).update(
            is_active=False, terminated_at=timezone.now(), termination_reason='admin_revoke'
        )
        user.is_active = False
        user.save(update_fields=['is_active', 'updated_at'])

        AuditService.log(action='user.deactivated', entity_type='user', entity_id=str(user.id),
                         business=request.user.business, request=request)
        return success_response({'id': str(user.id), 'is_active': False})


class UserDeleteView(APIView):
    permission_classes = [IsOwner]

    def delete(self, request, user_id):
        try:
            user = User.objects.get(id=user_id, business=request.user.business)
        except User.DoesNotExist:
            raise NotFound('User not found.')

        # Block delete if open shifts exist
        if user.shifts.filter(status='open').exists():
            from apps.core.exceptions import RetailGuardException
            raise RetailGuardException(
                detail='Cannot delete user with an active open shift.',
                code='USER_HAS_OPEN_SHIFT'
            )

        user.soft_delete(deleted_by_user=request.user)
        AuditService.log(action='user.deleted', entity_type='user', entity_id=str(user.id),
                         business=request.user.business, request=request)
        from rest_framework.response import Response
        return Response(status=status.HTTP_204_NO_CONTENT)


class SetOverridePinView(APIView):
    permission_classes = [IsAnyActiveStaff]

    def post(self, request, user_id):
        # Owners can set any user's PIN; others only their own
        if request.user.role != 'owner' and str(request.user.id) != str(user_id):
            from rest_framework.exceptions import PermissionDenied
            raise PermissionDenied()

        try:
            user = User.objects.get(id=user_id, business=request.user.business)
        except User.DoesNotExist:
            raise NotFound('User not found.')

        serializer = SetOverridePinSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        if not user.check_password(serializer.validated_data['current_password']):
            from apps.core.exceptions import InvalidCredentialsError
            raise InvalidCredentialsError(detail='Current password is incorrect.')

        user.set_override_pin(serializer.validated_data['override_pin'])
        AuditService.log(action='user.pin_updated', entity_type='user', entity_id=str(user.id),
                         business=user.business, request=request)
        return success_response({'message': 'Override PIN updated.'})
