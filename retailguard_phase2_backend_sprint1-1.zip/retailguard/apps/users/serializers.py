"""RetailGuard Users — Serializers"""
from django.contrib.auth import get_user_model
from rest_framework import serializers

from apps.users.models import UserBranchAssignment

User = get_user_model()


class UserBranchAssignmentSerializer(serializers.ModelSerializer):
    branch_name    = serializers.CharField(source='branch.name', read_only=True, default=None)
    warehouse_name = serializers.CharField(source='warehouse.name', read_only=True, default=None)

    class Meta:
        model  = UserBranchAssignment
        fields = ['id', 'branch_id', 'branch_name', 'warehouse_id', 'warehouse_name', 'is_primary', 'assigned_at']


class UserListSerializer(serializers.ModelSerializer):
    full_name      = serializers.ReadOnlyField()
    primary_branch = serializers.SerializerMethodField()

    class Meta:
        model  = User
        fields = [
            'id', 'employee_id', 'first_name', 'last_name', 'full_name',
            'phone', 'email', 'role', 'is_active', 'primary_branch',
            'last_login_at', 'created_at',
        ]

    def get_primary_branch(self, obj):
        a = obj.branch_assignments.filter(is_primary=True, revoked_at__isnull=True).first()
        if a and a.branch_id:
            return {'id': str(a.branch_id), 'name': a.branch.name if a.branch else None}
        return None


class UserDetailSerializer(UserListSerializer):
    assignments = UserBranchAssignmentSerializer(
        source='branch_assignments', many=True, read_only=True
    )

    class Meta(UserListSerializer.Meta):
        fields = UserListSerializer.Meta.fields + ['assignments', 'failed_login_attempts', 'locked_until']


class UserCreateSerializer(serializers.Serializer):
    employee_id   = serializers.CharField(required=False, allow_blank=True)
    first_name    = serializers.CharField(max_length=100)
    last_name     = serializers.CharField(max_length=100)
    phone         = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    email         = serializers.EmailField(required=False, allow_blank=True, allow_null=True)
    role          = serializers.ChoiceField(choices=['owner', 'manager', 'cashier', 'warehouse_staff'])
    password      = serializers.CharField(write_only=True, min_length=8)
    override_pin  = serializers.CharField(write_only=True, min_length=4, max_length=6, required=False)
    branch_id     = serializers.UUIDField(required=False, allow_null=True)

    def validate(self, data):
        if not data.get('phone') and not data.get('email'):
            raise serializers.ValidationError('Phone or email is required.')
        if pin := data.get('override_pin'):
            if not pin.isdigit():
                raise serializers.ValidationError({'override_pin': 'PIN must be digits only.'})
        return data

    def validate_phone(self, value):
        if value and User.all_objects.filter(phone=value).exists():
            raise serializers.ValidationError('Phone number already registered.')
        return value

    def validate_email(self, value):
        if value and User.all_objects.filter(email__iexact=value).exists():
            raise serializers.ValidationError('Email already registered.')
        return value


class UserUpdateSerializer(serializers.Serializer):
    first_name   = serializers.CharField(max_length=100, required=False)
    last_name    = serializers.CharField(max_length=100, required=False)
    phone        = serializers.CharField(required=False, allow_null=True)
    email        = serializers.EmailField(required=False, allow_null=True)
    employee_id  = serializers.CharField(required=False, allow_blank=True)


class PasswordChangeSerializer(serializers.Serializer):
    current_password = serializers.CharField(write_only=True)
    new_password     = serializers.CharField(write_only=True, min_length=8)


class SetOverridePinSerializer(serializers.Serializer):
    current_password = serializers.CharField(write_only=True)
    override_pin     = serializers.CharField(write_only=True, min_length=4, max_length=6)

    def validate_override_pin(self, value):
        if not value.isdigit():
            raise serializers.ValidationError('Override PIN must contain digits only.')
        return value
