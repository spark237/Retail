from django.urls import path

from apps.users.views import (
    SetOverridePinView,
    UserDeactivateView,
    UserDeleteView,
    UserDetailView,
    UserListCreateView,
)

urlpatterns = [
    path('',                            UserListCreateView.as_view(),  name='user-list'),
    path('<uuid:user_id>/',             UserDetailView.as_view(),      name='user-detail'),
    path('<uuid:user_id>/deactivate/',  UserDeactivateView.as_view(),  name='user-deactivate'),
    path('<uuid:user_id>/set-override-pin/', SetOverridePinView.as_view(), name='user-set-pin'),
    path('<uuid:user_id>/delete/',      UserDeleteView.as_view(),      name='user-delete'),
]
