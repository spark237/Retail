from django.urls import path

from apps.branches.views import BranchDetailView, BranchListCreateView, WarehouseDetailView, WarehouseListCreateView

urlpatterns = [
    path('',                            BranchListCreateView.as_view(),  name='branch-list'),
    path('<uuid:branch_id>/',           BranchDetailView.as_view(),      name='branch-detail'),
    path('warehouses/',                 WarehouseListCreateView.as_view(), name='warehouse-list'),
    path('warehouses/<uuid:warehouse_id>/', WarehouseDetailView.as_view(), name='warehouse-detail'),
]
