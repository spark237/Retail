"""RetailGuard Branches — Serializers"""
from rest_framework import serializers

from apps.branches.models import Branch, Business, Warehouse


class BusinessSerializer(serializers.ModelSerializer):
    class Meta:
        model  = Business
        fields = ['id', 'name', 'slug', 'phone', 'email', 'address', 'currency', 'timezone', 'is_active']
        read_only_fields = ['id', 'slug']


class BranchListSerializer(serializers.ModelSerializer):
    manager_name = serializers.SerializerMethodField()
    active_shift = serializers.SerializerMethodField()

    class Meta:
        model  = Branch
        fields = ['id', 'name', 'code', 'address', 'phone', 'manager_id', 'manager_name', 'is_active', 'active_shift']

    def get_manager_name(self, obj):
        return obj.manager.full_name if obj.manager else None

    def get_active_shift(self, obj):
        shift = obj.active_shift
        if shift:
            return {
                'id': str(shift.id),
                'cashier': shift.cashier.full_name,
                'started_at': shift.started_at,
                'status': shift.status,
            }
        return None


class BranchCreateSerializer(serializers.Serializer):
    name       = serializers.CharField(max_length=200)
    code       = serializers.CharField(max_length=20)
    address    = serializers.CharField(required=False, allow_blank=True)
    phone      = serializers.CharField(required=False, allow_blank=True)
    manager_id = serializers.UUIDField(required=False, allow_null=True)


class WarehouseSerializer(serializers.ModelSerializer):
    manager_name = serializers.SerializerMethodField()

    class Meta:
        model  = Warehouse
        fields = ['id', 'name', 'code', 'address', 'phone', 'manager_id', 'manager_name', 'is_active']

    def get_manager_name(self, obj):
        return obj.manager.full_name if obj.manager else None
