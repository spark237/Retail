"""
RetailGuard Branches — Business, Branch, Warehouse Models

Business is the top-level multi-tenant entity.
Every operational record links to a business via branch or direct FK.
Branch and Warehouse are peer location types — never mixed in a single stock row.
"""
import uuid

from django.conf import settings
from django.db import models

from apps.core.models import SoftDeleteModel, TimestampedModel


class Business(TimestampedModel):
    """
    Top-level tenant entity. One per client in MVP; SaaS foundation for future.
    settings JSONB holds per-business configurable thresholds — no schema migration needed
    to add new fraud rule parameters.
    """
    id          = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name        = models.CharField(max_length=200)
    slug        = models.SlugField(max_length=100, unique=True)
    phone       = models.CharField(max_length=20, blank=True, null=True)
    email       = models.EmailField(blank=True, null=True)
    address     = models.TextField(blank=True, null=True)
    currency    = models.CharField(max_length=3, default='XAF')
    timezone    = models.CharField(max_length=60, default='Africa/Douala')
    is_active   = models.BooleanField(default=True)
    settings    = models.JSONField(default=dict)

    class Meta:
        db_table = 'businesses'
        verbose_name = 'Business'
        verbose_name_plural = 'Businesses'

    def __str__(self):
        return f"{self.name} ({self.slug})"

    def get_setting(self, key, default=None):
        """Safe accessor for business-level config."""
        return self.settings.get(key, default)

    @classmethod
    def get_default_settings(cls):
        return {
            'unsynced_alert_hours': 4,
            'max_cashier_discount_pct': 5,
            'cash_shortage_alert_xaf': 1000,
            'transfer_variance_alert_units': 1,
            'max_voids_per_shift': 2,
            'max_price_overrides_per_shift': 3,
            'max_price_overrides_per_manager_per_day': 5,
            'require_manager_approval_for_void': True,
            'allow_negative_stock': False,
        }


class Branch(SoftDeleteModel):
    """
    Physical retail branch. Maintains its own isolated stock pool.
    Branch stock and Warehouse stock are NEVER mixed — no global pool.
    One active shift at a time (enforced by DB partial unique index on shifts).
    """
    id          = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    business    = models.ForeignKey(Business, on_delete=models.PROTECT, related_name='branches')
    name        = models.CharField(max_length=200)
    code        = models.CharField(max_length=20)
    address     = models.TextField(blank=True, null=True)
    phone       = models.CharField(max_length=20, blank=True, null=True)
    manager     = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True, blank=True,
        on_delete=models.SET_NULL,
        related_name='managed_branches',
    )
    is_active   = models.BooleanField(default=True)

    class Meta:
        db_table = 'branches'
        verbose_name = 'Branch'
        verbose_name_plural = 'Branches'
        constraints = [
            models.UniqueConstraint(
                fields=['business', 'code'],
                name='uq_branch_code',
            )
        ]

    def __str__(self):
        return f"{self.name} ({self.code})"

    @property
    def active_shift(self):
        """Returns the currently open shift or None."""
        return self.shifts.filter(status='open').first()


class Warehouse(SoftDeleteModel):
    """
    Physical warehouse. Separate stock namespace from branches.
    Stock transfers flow: Warehouse → Branch (manager-confirmed).
    """
    id          = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    business    = models.ForeignKey(Business, on_delete=models.PROTECT, related_name='warehouses')
    name        = models.CharField(max_length=200)
    code        = models.CharField(max_length=20)
    address     = models.TextField(blank=True, null=True)
    phone       = models.CharField(max_length=20, blank=True, null=True)
    manager     = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True, blank=True,
        on_delete=models.SET_NULL,
        related_name='managed_warehouses',
    )
    is_active   = models.BooleanField(default=True)

    class Meta:
        db_table = 'warehouses'
        verbose_name = 'Warehouse'
        verbose_name_plural = 'Warehouses'
        constraints = [
            models.UniqueConstraint(
                fields=['business', 'code'],
                name='uq_warehouse_code',
            )
        ]

    def __str__(self):
        return f"{self.name} ({self.code})"
