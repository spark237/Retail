"""RetailGuard Branches — Views"""
from django.contrib.auth import get_user_model
from rest_framework.exceptions import NotFound
from rest_framework.views import APIView

from apps.audit.models import AuditService
from apps.branches.models import Branch, Warehouse
from apps.branches.serializers import BranchCreateSerializer, BranchListSerializer, WarehouseSerializer
from apps.core.pagination import StandardPagination
from apps.core.permissions import IsCashierOrAbove, IsOwner
from apps.core.utils import success_response

User = get_user_model()


def _scope_branches(user):
    """Return branch queryset scoped to user's business and role."""
    qs = Branch.objects.filter(business=user.business, is_deleted=False).select_related('manager')
    if user.role != 'owner':
        assigned = list(
            user.branch_assignments.filter(revoked_at__isnull=True, branch_id__isnull=False)
            .values_list('branch_id', flat=True)
        )
        qs = qs.filter(id__in=assigned)
    return qs


class BranchListCreateView(APIView):

    def get_permissions(self):
        return [IsOwner()] if self.request.method == 'POST' else [IsCashierOrAbove()]

    def get(self, request):
        qs = _scope_branches(request.user)
        paginator = StandardPagination()
        page = paginator.paginate_queryset(qs, request)
        return paginator.get_paginated_response(BranchListSerializer(page, many=True).data)

    def post(self, request):
        s = BranchCreateSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        data = s.validated_data

        manager = None
        if mid := data.get('manager_id'):
            try:
                manager = User.objects.get(id=mid, business=request.user.business)
            except User.DoesNotExist:
                raise NotFound('Manager user not found.')

        branch = Branch.objects.create(business=request.user.business, manager=manager, **{
            k: v for k, v in data.items() if k != 'manager_id'
        })
        AuditService.log(action='branch.created', entity_type='branch', entity_id=str(branch.id),
                         business=request.user.business, new_values={'name': branch.name}, request=request)
        return success_response(BranchListSerializer(branch).data, status=201)


class BranchDetailView(APIView):
    permission_classes = [IsCashierOrAbove]

    def _get_branch(self, request, branch_id):
        qs = _scope_branches(request.user)
        try:
            return qs.get(id=branch_id)
        except Branch.DoesNotExist:
            raise NotFound('Branch not found.')

    def get(self, request, branch_id):
        return success_response(BranchListSerializer(self._get_branch(request, branch_id)).data)

    def patch(self, request, branch_id):
        if request.user.role != 'owner':
            from rest_framework.exceptions import PermissionDenied
            raise PermissionDenied()
        branch = self._get_branch(request, branch_id)
        s = BranchCreateSerializer(data=request.data, partial=True)
        s.is_valid(raise_exception=True)
        for field, value in s.validated_data.items():
            if field == 'manager_id':
                if value:
                    try:
                        branch.manager = User.objects.get(id=value, business=request.user.business)
                    except User.DoesNotExist:
                        raise NotFound('Manager not found.')
                else:
                    branch.manager = None
            else:
                setattr(branch, field, value)
        branch.save()
        return success_response(BranchListSerializer(branch).data)


class WarehouseListCreateView(APIView):
    def get_permissions(self):
        return [IsOwner()] if self.request.method == 'POST' else [IsCashierOrAbove()]

    def get(self, request):
        qs = Warehouse.objects.filter(business=request.user.business, is_deleted=False)
        return success_response(WarehouseSerializer(qs, many=True).data)

    def post(self, request):
        s = WarehouseSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        wh = Warehouse.objects.create(business=request.user.business, **s.validated_data)
        return success_response(WarehouseSerializer(wh).data, status=201)


class WarehouseDetailView(APIView):
    permission_classes = [IsOwner]

    def patch(self, request, warehouse_id):
        try:
            wh = Warehouse.objects.get(id=warehouse_id, business=request.user.business)
        except Warehouse.DoesNotExist:
            raise NotFound('Warehouse not found.')
        s = WarehouseSerializer(wh, data=request.data, partial=True)
        s.is_valid(raise_exception=True)
        s.save()
        return success_response(WarehouseSerializer(wh).data)
