"""RetailGuard Fraud — Serializers"""
from rest_framework import serializers

from apps.fraud.models import FraudAlert, FraudRule


class FraudRuleSerializer(serializers.ModelSerializer):
    class Meta:
        model  = FraudRule
        fields = [
            'id', 'rule_code', 'name', 'description',
            'threshold_value', 'threshold_percentage',
            'alert_level', 'is_active', 'updated_at',
        ]
        read_only_fields = ['id', 'rule_code', 'name']


class FraudAlertSerializer(serializers.ModelSerializer):
    branch_name      = serializers.CharField(source='branch.name',           read_only=True, default=None)
    triggered_by_name = serializers.CharField(source='triggered_by.full_name', read_only=True, default=None)
    acknowledged_by_name = serializers.CharField(source='acknowledged_by.full_name', read_only=True, default=None)
    resolved_by_name = serializers.CharField(source='resolved_by.full_name', read_only=True, default=None)

    class Meta:
        model  = FraudAlert
        fields = [
            'id', 'alert_type', 'alert_level', 'title', 'description',
            'branch_id', 'branch_name',
            'reference_type', 'reference_id',
            'triggered_by_id', 'triggered_by_name',
            'status',
            'acknowledged_by_id', 'acknowledged_by_name', 'acknowledged_at',
            'resolved_by_id', 'resolved_by_name', 'resolved_at', 'resolution_notes',
            'created_at',
        ]
