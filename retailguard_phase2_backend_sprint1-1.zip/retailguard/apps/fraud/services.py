"""
RetailGuard Fraud Detection — Rule Evaluation Engine

Called after key events: sale created, sale voided, price override approved,
terminal takeover, shift closed, damage report approved.

All checks are lightweight DB queries — no ML, no external services.
Designed to run synchronously in MVP (move to Celery tasks when volume warrants).

ALERT CREATION RULES:
  - Each rule check is idempotent for the same reference_id
  - Duplicate alerts for the same event are suppressed
  - Alert level escalates: MEDIUM → HIGH on repeat within window
"""
from datetime import timedelta

from django.utils import timezone


class FraudDetectionService:

    @classmethod
    def check_after_sale(cls, sale):
        """Run relevant fraud checks after a sale is committed."""
        cls._check_rapid_sequential_sales(sale)

    @classmethod
    def check_after_void(cls, sale):
        """Run fraud checks after a sale is voided."""
        cls._check_excessive_sale_voids(sale)
        cls._check_excessive_voids_per_shift(sale)

    @classmethod
    def check_after_price_override(cls, approval):
        """Run fraud checks after a manager approves a price override."""
        cls._check_repeated_price_override(approval)
        cls._check_excessive_discount_approvals(approval)

    @classmethod
    def check_after_terminal_takeover(cls, takeover):
        """Run fraud checks after a terminal takeover."""
        cls._check_frequent_terminal_takeovers(takeover)

    @classmethod
    def check_after_shift_close(cls, reconciliation):
        """Run cash shortage check after shift reconciliation is created."""
        cls._check_cash_shortage(reconciliation)

    @classmethod
    def check_after_transfer_confirm(cls, transfer):
        """Run variance check after transfer is confirmed."""
        cls._check_transfer_variance(transfer)

    # ─── INDIVIDUAL RULE CHECKS ───────────────────────────────────────────

    @classmethod
    def _check_cash_shortage(cls, reconciliation):
        from apps.fraud.models import RuleCode
        rule = cls._get_rule(reconciliation.branch.business, RuleCode.CASH_SHORTAGE)
        if not rule or not rule.is_active:
            return
        threshold = int(rule.threshold_value or 1000)
        if reconciliation.difference_confirmed < -threshold:
            cls._create_alert(
                business=reconciliation.branch.business,
                branch=reconciliation.branch,
                rule=rule,
                title=f'Cash shortage — {reconciliation.branch.name}',
                description=(
                    f'Shift #{reconciliation.shift_id}: '
                    f'Expected {reconciliation.expected_cash_confirmed:,} XAF. '
                    f'Actual {reconciliation.actual_cash:,} XAF. '
                    f'Shortage: {abs(reconciliation.difference_confirmed):,} XAF.'
                ),
                reference_type='shift',
                reference_id=str(reconciliation.shift_id),
                triggered_by=reconciliation.cashier,
            )

    @classmethod
    def _check_excessive_sale_voids(cls, sale):
        """EXCESSIVE_SALE_VOIDS: cashier void count in last 24h."""
        from apps.fraud.models import AlertLevel, RuleCode
        from apps.inventory.models import InventoryMovement, MovementType

        rule = cls._get_rule(sale.business, RuleCode.EXCESSIVE_SALE_VOIDS)
        if not rule or not rule.is_active:
            return

        threshold_medium = int(rule.threshold_value or 5)
        threshold_high = threshold_medium * 2
        since = timezone.now() - timedelta(hours=24)

        void_count = InventoryMovement.objects.filter(
            movement_type=MovementType.SALE_VOID,
            performed_by=sale.voided_by,
            created_at__gte=since,
        ).count()

        if void_count >= threshold_high:
            level = AlertLevel.HIGH
        elif void_count >= threshold_medium:
            level = AlertLevel.MEDIUM
        else:
            return

        cls._create_alert(
            business=sale.business,
            branch=sale.branch,
            rule=rule,
            alert_level=level,
            title=f'Excessive sale voids — {sale.voided_by.full_name}',
            description=f'{sale.voided_by.full_name} has voided {void_count} sales in the last 24 hours.',
            reference_type='sale',
            reference_id=str(sale.id),
            triggered_by=sale.voided_by,
        )

    @classmethod
    def _check_excessive_voids_per_shift(cls, sale):
        """EXCESSIVE_VOIDS: total voids in current shift."""
        from apps.fraud.models import RuleCode
        from apps.sales.models import SaleStatus

        rule = cls._get_rule(sale.business, RuleCode.EXCESSIVE_VOIDS)
        if not rule or not rule.is_active:
            return

        threshold = int(rule.threshold_value or 2)
        void_count = sale.shift.sales.filter(status=SaleStatus.VOIDED).count()

        if void_count > threshold:
            cls._create_alert(
                business=sale.business,
                branch=sale.branch,
                rule=rule,
                title=f'Excessive voids in shift — {sale.branch.name}',
                description=f'{void_count} sales voided in shift #{sale.shift_id}. Threshold: {threshold}.',
                reference_type='shift',
                reference_id=str(sale.shift_id),
                triggered_by=sale.voided_by,
            )

    @classmethod
    def _check_rapid_sequential_sales(cls, sale):
        """RAPID_SEQUENTIAL_SALES: detect unusually fast consecutive transactions."""
        from apps.fraud.models import RuleCode

        rule = cls._get_rule(sale.business, RuleCode.RAPID_SEQUENTIAL_SALES)
        if not rule or not rule.is_active:
            return

        count_threshold = int(rule.threshold_value or 3)
        window_seconds = 60
        since = timezone.now() - timedelta(seconds=window_seconds)

        recent = sale.__class__.objects.filter(
            cashier=sale.cashier,
            synced_at__gte=since,
        ).count()

        if recent >= count_threshold:
            cls._create_alert(
                business=sale.business,
                branch=sale.branch,
                rule=rule,
                title=f'Rapid sequential sales — {sale.cashier.full_name}',
                description=f'{recent} sales recorded in {window_seconds}s by {sale.cashier.full_name}.',
                reference_type='sale',
                reference_id=str(sale.id),
                triggered_by=sale.cashier,
            )

    @classmethod
    def _check_repeated_price_override(cls, approval):
        """REPEATED_PRICE_OVERRIDE: cashier exceeds override count per shift."""
        from apps.fraud.models import RuleCode
        from apps.sales.models import PriceOverrideApproval

        rule = cls._get_rule(approval.branch.business, RuleCode.REPEATED_PRICE_OVERRIDE)
        if not rule or not rule.is_active:
            return

        threshold = int(rule.threshold_value or 3)
        # Count approvals for this cashier in the current open shift window (today)
        today_start = timezone.now().replace(hour=0, minute=0, second=0, microsecond=0)
        count = PriceOverrideApproval.objects.filter(
            cashier=approval.cashier,
            branch=approval.branch,
            status='approved',
            approved_at__gte=today_start,
        ).count()

        if count >= threshold:
            cls._create_alert(
                business=approval.branch.business,
                branch=approval.branch,
                rule=rule,
                title=f'Repeated price overrides — {approval.cashier.full_name}',
                description=f'{approval.cashier.full_name} has had {count} price overrides approved today at {approval.branch.name}.',
                reference_type='price_override_approval',
                reference_id=str(approval.id),
                triggered_by=approval.cashier,
            )

    @classmethod
    def _check_excessive_discount_approvals(cls, approval):
        """EXCESSIVE_DISCOUNT_APPROVALS: manager approves too many overrides per day."""
        from apps.fraud.models import RuleCode
        from apps.sales.models import PriceOverrideApproval

        rule = cls._get_rule(approval.branch.business, RuleCode.EXCESSIVE_DISCOUNT_APPROVALS)
        if not rule or not rule.is_active:
            return

        threshold = int(rule.threshold_value or 3)
        today_start = timezone.now().replace(hour=0, minute=0, second=0, microsecond=0)
        count = PriceOverrideApproval.objects.filter(
            approved_by=approval.approved_by,
            status='approved',
            approved_at__gte=today_start,
        ).count()

        if count >= threshold:
            cls._create_alert(
                business=approval.branch.business,
                branch=approval.branch,
                rule=rule,
                title=f'Excessive discount approvals — {approval.approved_by.full_name}',
                description=(
                    f'{approval.approved_by.full_name} has approved {count} '
                    f'below-minimum price overrides today.'
                ),
                reference_type='price_override_approval',
                reference_id=str(approval.id),
                triggered_by=approval.approved_by,
            )

    @classmethod
    def _check_frequent_terminal_takeovers(cls, takeover):
        """FREQUENT_TERMINAL_TAKEOVERS: 2+ takeovers at same branch in 24h."""
        from apps.fraud.models import RuleCode
        from apps.users.terminal_takeover import TerminalTakeover

        rule = cls._get_rule(takeover.branch.business, RuleCode.FREQUENT_TERMINAL_TAKEOVERS)
        if not rule or not rule.is_active:
            return

        threshold = int(rule.threshold_value or 2)
        since = timezone.now() - timedelta(hours=24)
        count = TerminalTakeover.objects.filter(
            branch=takeover.branch,
            created_at__gte=since,
        ).count()

        if count >= threshold:
            cls._create_alert(
                business=takeover.branch.business,
                branch=takeover.branch,
                rule=rule,
                title=f'Frequent terminal takeovers — {takeover.branch.name}',
                description=(
                    f'{count} terminal takeovers at {takeover.branch.name} in the last 24 hours. '
                    f'Possible device-swapping or evasion activity.'
                ),
                reference_type='terminal_takeover',
                reference_id=str(takeover.id),
                triggered_by=takeover.approved_by,
            )

    @classmethod
    def _check_transfer_variance(cls, transfer):
        """TRANSFER_VARIANCE: any dispatched != received discrepancy."""
        from apps.fraud.models import RuleCode

        if not transfer.has_variance:
            return

        rule = cls._get_rule(transfer.business, RuleCode.TRANSFER_VARIANCE)
        if not rule or not rule.is_active:
            return

        variance_items = [
            item for item in transfer.items.all()
            if item.has_variance
        ]
        detail = ', '.join(
            f"{item.product.name}: dispatched {item.quantity_dispatched} received {item.quantity_received}"
            for item in variance_items
        )

        cls._create_alert(
            business=transfer.business,
            branch=transfer.to_branch,
            rule=rule,
            title=f'Transfer variance — {transfer.transfer_number}',
            description=f'Quantity mismatch in transfer {transfer.transfer_number}. {detail}',
            reference_type='transfer',
            reference_id=str(transfer.id),
            triggered_by=transfer.received_by,
        )

    # ─── HELPERS ─────────────────────────────────────────────────────────────

    @classmethod
    def _get_rule(cls, business, rule_code):
        from apps.fraud.models import FraudRule
        return FraudRule.objects.filter(business=business, rule_code=rule_code).first()

    @classmethod
    def _create_alert(cls, *, business, branch=None, rule, title, description,
                      reference_type=None, reference_id=None, triggered_by=None,
                      alert_level=None):
        from apps.fraud.models import FraudAlert

        # Suppress duplicate alert for same reference
        if reference_type and reference_id:
            exists = FraudAlert.objects.filter(
                business=business,
                alert_type=rule.rule_code,
                reference_type=reference_type,
                reference_id=reference_id,
            ).exists()
            if exists:
                return None

        return FraudAlert.objects.create(
            business=business,
            branch=branch,
            rule=rule,
            alert_type=rule.rule_code,
            alert_level=alert_level or rule.alert_level,
            title=title,
            description=description,
            reference_type=reference_type,
            reference_id=reference_id,
            triggered_by=triggered_by,
        )
