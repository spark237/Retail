"""
RetailGuard Fraud — FraudRule, FraudAlert

Rule-based fraud detection engine.
Rules are configurable per business. Alerts are immutable records.
Only owners can dismiss alerts (and dismissal itself is audit-logged).

ALL 14 RULES (v4 final):
  CASH_SHORTAGE, PRICE_BELOW_MINIMUM, EXCESS_DISCOUNT,
  INVENTORY_MISMATCH, TRANSFER_VARIANCE, UNSYNCED_SHIFT_TIMEOUT,
  EXCESSIVE_VOIDS, EXCESSIVE_SALE_VOIDS, RAPID_SEQUENTIAL_SALES,
  DAMAGE_REPORT_PATTERN, UNAPPROVED_ADJUSTMENT,
  REPEATED_PRICE_OVERRIDE, EXCESSIVE_DISCOUNT_APPROVALS,
  FREQUENT_TERMINAL_TAKEOVERS
"""
import uuid

from django.conf import settings
from django.db import models

from apps.core.models import TimestampedModel


class RuleCode(models.TextChoices):
    CASH_SHORTAGE               = 'CASH_SHORTAGE',               'Cash Shortage'
    PRICE_BELOW_MINIMUM         = 'PRICE_BELOW_MINIMUM',         'Price Below Minimum'
    EXCESS_DISCOUNT             = 'EXCESS_DISCOUNT',             'Excess Discount'
    INVENTORY_MISMATCH          = 'INVENTORY_MISMATCH',          'Inventory Mismatch'
    TRANSFER_VARIANCE           = 'TRANSFER_VARIANCE',           'Transfer Variance'
    UNSYNCED_SHIFT_TIMEOUT      = 'UNSYNCED_SHIFT_TIMEOUT',      'Unsynced Shift Timeout'
    EXCESSIVE_VOIDS             = 'EXCESSIVE_VOIDS',             'Excessive Voids'
    EXCESSIVE_SALE_VOIDS        = 'EXCESSIVE_SALE_VOIDS',        'Excessive Sale Voids'  # v4
    RAPID_SEQUENTIAL_SALES      = 'RAPID_SEQUENTIAL_SALES',      'Rapid Sequential Sales'
    DAMAGE_REPORT_PATTERN       = 'DAMAGE_REPORT_PATTERN',       'Damage Report Pattern'
    UNAPPROVED_ADJUSTMENT       = 'UNAPPROVED_ADJUSTMENT',       'Unapproved Adjustment'
    REPEATED_PRICE_OVERRIDE     = 'REPEATED_PRICE_OVERRIDE',     'Repeated Price Override'
    EXCESSIVE_DISCOUNT_APPROVALS = 'EXCESSIVE_DISCOUNT_APPROVALS', 'Excessive Discount Approvals'  # v4
    FREQUENT_TERMINAL_TAKEOVERS = 'FREQUENT_TERMINAL_TAKEOVERS', 'Frequent Terminal Takeovers'  # v4


class AlertLevel(models.TextChoices):
    LOW      = 'low',      'Low'
    MEDIUM   = 'medium',   'Medium'
    HIGH     = 'high',     'High'
    CRITICAL = 'critical', 'Critical'


# Default rules seeded on business creation
DEFAULT_FRAUD_RULES = [
    {'rule_code': RuleCode.CASH_SHORTAGE,               'threshold_value': 1000,  'threshold_percentage': None, 'alert_level': AlertLevel.HIGH},
    {'rule_code': RuleCode.PRICE_BELOW_MINIMUM,         'threshold_value': 0,     'threshold_percentage': None, 'alert_level': AlertLevel.CRITICAL},
    {'rule_code': RuleCode.EXCESS_DISCOUNT,             'threshold_value': None,  'threshold_percentage': '5.00', 'alert_level': AlertLevel.MEDIUM},
    {'rule_code': RuleCode.INVENTORY_MISMATCH,          'threshold_value': 1,     'threshold_percentage': None, 'alert_level': AlertLevel.HIGH},
    {'rule_code': RuleCode.TRANSFER_VARIANCE,           'threshold_value': 1,     'threshold_percentage': None, 'alert_level': AlertLevel.HIGH},
    {'rule_code': RuleCode.UNSYNCED_SHIFT_TIMEOUT,      'threshold_value': 4,     'threshold_percentage': None, 'alert_level': AlertLevel.MEDIUM},
    {'rule_code': RuleCode.EXCESSIVE_VOIDS,             'threshold_value': 2,     'threshold_percentage': None, 'alert_level': AlertLevel.MEDIUM},
    {'rule_code': RuleCode.EXCESSIVE_SALE_VOIDS,        'threshold_value': 5,     'threshold_percentage': None, 'alert_level': AlertLevel.MEDIUM},
    {'rule_code': RuleCode.RAPID_SEQUENTIAL_SALES,      'threshold_value': 3,     'threshold_percentage': None, 'alert_level': AlertLevel.LOW},
    {'rule_code': RuleCode.DAMAGE_REPORT_PATTERN,       'threshold_value': 3,     'threshold_percentage': None, 'alert_level': AlertLevel.MEDIUM},
    {'rule_code': RuleCode.UNAPPROVED_ADJUSTMENT,       'threshold_value': 0,     'threshold_percentage': None, 'alert_level': AlertLevel.CRITICAL},
    {'rule_code': RuleCode.REPEATED_PRICE_OVERRIDE,     'threshold_value': 3,     'threshold_percentage': None, 'alert_level': AlertLevel.HIGH},
    {'rule_code': RuleCode.EXCESSIVE_DISCOUNT_APPROVALS,'threshold_value': 3,     'threshold_percentage': None, 'alert_level': AlertLevel.HIGH},
    {'rule_code': RuleCode.FREQUENT_TERMINAL_TAKEOVERS, 'threshold_value': 2,     'threshold_percentage': None, 'alert_level': AlertLevel.HIGH},
]


class FraudRule(TimestampedModel):
    """Configurable detection rules. One set per business, seeded from DEFAULT_FRAUD_RULES."""
    id                      = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    business                = models.ForeignKey('branches.Business', on_delete=models.PROTECT, related_name='fraud_rules')
    rule_code               = models.CharField(max_length=60, choices=RuleCode.choices)
    name                    = models.CharField(max_length=200)
    description             = models.TextField(blank=True, null=True)
    threshold_value         = models.DecimalField(max_digits=12, decimal_places=3, null=True, blank=True)
    threshold_percentage    = models.DecimalField(max_digits=5, decimal_places=2, null=True, blank=True)
    alert_level             = models.CharField(max_length=20, choices=AlertLevel.choices)
    is_active               = models.BooleanField(default=True)

    class Meta:
        db_table = 'fraud_rules'
        constraints = [
            models.UniqueConstraint(fields=['business', 'rule_code'], name='uq_rule_per_business'),
        ]

    def __str__(self):
        return f"{self.rule_code} [{self.alert_level}]"

    @classmethod
    def seed_for_business(cls, business):
        """Called when a new business is created."""
        for rule_data in DEFAULT_FRAUD_RULES:
            cls.objects.get_or_create(
                business=business,
                rule_code=rule_data['rule_code'],
                defaults={
                    'name': rule_data['rule_code'].replace('_', ' ').title(),
                    'threshold_value': rule_data.get('threshold_value'),
                    'threshold_percentage': rule_data.get('threshold_percentage'),
                    'alert_level': rule_data['alert_level'],
                }
            )


class AlertStatus(models.TextChoices):
    OPEN          = 'open',          'Open'
    ACKNOWLEDGED  = 'acknowledged',  'Acknowledged'
    INVESTIGATING = 'investigating', 'Investigating'
    RESOLVED      = 'resolved',      'Resolved'
    DISMISSED     = 'dismissed',     'Dismissed'


class FraudAlert(models.Model):
    """
    Immutable fraud alert record. Status transitions only.
    Only owners can dismiss. Dismissal is itself audit-logged.
    triggered_by: the employee whose action triggered this (not the reviewer).
    """
    id              = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    business        = models.ForeignKey('branches.Business', on_delete=models.PROTECT, related_name='fraud_alerts')
    branch          = models.ForeignKey('branches.Branch', null=True, blank=True, on_delete=models.PROTECT, related_name='fraud_alerts')
    rule            = models.ForeignKey(FraudRule, null=True, blank=True, on_delete=models.SET_NULL, related_name='alerts')
    alert_type      = models.CharField(max_length=60)     # mirrors rule_code
    alert_level     = models.CharField(max_length=20, choices=AlertLevel.choices)
    title           = models.CharField(max_length=200)
    description     = models.TextField()
    reference_type  = models.CharField(max_length=50, blank=True, null=True)  # 'sale', 'shift', etc.
    reference_id    = models.CharField(max_length=100, blank=True, null=True)
    triggered_by    = models.ForeignKey(
        settings.AUTH_USER_MODEL, null=True, blank=True,
        on_delete=models.SET_NULL, related_name='triggered_alerts',
    )
    status          = models.CharField(max_length=20, choices=AlertStatus.choices, default=AlertStatus.OPEN)
    acknowledged_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name='acknowledged_alerts')
    acknowledged_at = models.DateTimeField(null=True, blank=True)
    resolved_by     = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name='resolved_alerts')
    resolved_at     = models.DateTimeField(null=True, blank=True)
    resolution_notes = models.TextField(blank=True, null=True)
    created_at      = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'fraud_alerts'
        ordering = ['-created_at']
        indexes = [
            models.Index(
                fields=['business', 'alert_level', 'status'],
                name='idx_alerts_open',
                condition=models.Q(status__in=['open', 'acknowledged', 'investigating']),
            ),
            models.Index(fields=['triggered_by', '-created_at'], name='idx_alerts_triggered_by'),
            models.Index(fields=['alert_type', '-created_at'],   name='idx_alerts_type'),
            models.Index(fields=['branch'],                      name='idx_alerts_branch'),
        ]

    def __str__(self):
        return f"[{self.alert_level.upper()}] {self.title}"
