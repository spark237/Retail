"""RetailGuard Fraud — Views"""
from django.utils import timezone
from rest_framework.exceptions import NotFound
from rest_framework.views import APIView

from apps.audit.models import AuditService
from apps.core.pagination import StandardPagination
from apps.core.permissions import IsManagerOrOwner, IsOwner
from apps.core.utils import success_response
from apps.fraud.models import AlertStatus, FraudAlert, FraudRule
from apps.fraud.serializers import FraudAlertSerializer, FraudRuleSerializer


class FraudAlertListView(APIView):
    permission_classes = [IsManagerOrOwner]

    def get(self, request):
        qs = FraudAlert.objects.filter(
            business=request.user.business
        ).select_related('branch', 'triggered_by', 'rule').order_by('-created_at')

        if request.user.role != 'owner':
            branch_ids = list(
                request.user.branch_assignments
                .filter(revoked_at__isnull=True, branch_id__isnull=False)
                .values_list('branch_id', flat=True)
            )
            qs = qs.filter(branch_id__in=branch_ids)
        if bid := request.query_params.get('branch_id'):
            qs = qs.filter(branch_id=bid)
        if lvl := request.query_params.get('alert_level'):
            qs = qs.filter(alert_level=lvl)
        if st := request.query_params.get('status'):
            qs = qs.filter(status=st)
        if at := request.query_params.get('alert_type'):
            qs = qs.filter(alert_type=at)
        if from_dt := request.query_params.get('from_date'):
            qs = qs.filter(created_at__date__gte=from_dt)

        paginator = StandardPagination()
        page = paginator.paginate_queryset(qs, request)
        return paginator.get_paginated_response(FraudAlertSerializer(page, many=True).data)


def _get_alert(request, alert_id):
    try:
        alert = FraudAlert.objects.select_related('branch', 'triggered_by').get(
            id=alert_id, business=request.user.business
        )
    except FraudAlert.DoesNotExist:
        raise NotFound('Alert not found.')
    if request.user.role == 'manager':
        branch_ids = list(
            request.user.branch_assignments
            .filter(revoked_at__isnull=True, branch_id__isnull=False)
            .values_list('branch_id', flat=True)
        )
        if alert.branch_id and str(alert.branch_id) not in [str(b) for b in branch_ids]:
            raise NotFound('Alert not found.')
    return alert


class FraudAlertAcknowledgeView(APIView):
    permission_classes = [IsManagerOrOwner]

    def post(self, request, alert_id):
        alert = _get_alert(request, alert_id)
        if alert.status not in (AlertStatus.OPEN,):
            from apps.core.exceptions import RetailGuardException
            raise RetailGuardException(
                detail=f'Alert is already {alert.status}.', code='INVALID_STATUS_TRANSITION'
            )
        alert.status = AlertStatus.ACKNOWLEDGED
        alert.acknowledged_by = request.user
        alert.acknowledged_at = timezone.now()
        alert.save(update_fields=['status', 'acknowledged_by', 'acknowledged_at'])
        return success_response(FraudAlertSerializer(alert).data)


class FraudAlertResolveView(APIView):
    permission_classes = [IsManagerOrOwner]

    def post(self, request, alert_id):
        alert = _get_alert(request, alert_id)
        if alert.status in (AlertStatus.RESOLVED, AlertStatus.DISMISSED):
            from apps.core.exceptions import RetailGuardException
            raise RetailGuardException(detail='Alert is already closed.', code='INVALID_STATUS_TRANSITION')

        resolution_notes = request.data.get('resolution_notes', '').strip()
        if not resolution_notes:
            from rest_framework.exceptions import ValidationError
            raise ValidationError({'resolution_notes': 'Resolution notes are required.'})

        alert.status = AlertStatus.RESOLVED
        alert.resolved_by = request.user
        alert.resolved_at = timezone.now()
        alert.resolution_notes = resolution_notes
        alert.save(update_fields=['status', 'resolved_by', 'resolved_at', 'resolution_notes'])

        AuditService.log(action='alert.resolved', entity_type='fraud_alert', entity_id=str(alert.id),
                         business=request.user.business, request=request)
        return success_response(FraudAlertSerializer(alert).data)


class FraudAlertDismissView(APIView):
    permission_classes = [IsOwner]

    def post(self, request, alert_id):
        alert = _get_alert(request, alert_id)
        if alert.status == AlertStatus.DISMISSED:
            from apps.core.exceptions import RetailGuardException
            raise RetailGuardException(detail='Alert already dismissed.', code='INVALID_STATUS_TRANSITION')

        resolution_notes = request.data.get('resolution_notes', '').strip()
        if not resolution_notes:
            from rest_framework.exceptions import ValidationError
            raise ValidationError({'resolution_notes': 'Dismissal reason is required.'})

        alert.status = AlertStatus.DISMISSED
        alert.resolved_by = request.user
        alert.resolved_at = timezone.now()
        alert.resolution_notes = resolution_notes
        alert.save(update_fields=['status', 'resolved_by', 'resolved_at', 'resolution_notes'])

        # Dismissal itself is audit-logged — owners cannot silently clear alerts
        AuditService.log(action='alert.dismissed', entity_type='fraud_alert', entity_id=str(alert.id),
                         business=request.user.business,
                         new_values={'dismissed_by': str(request.user.id), 'reason': resolution_notes},
                         request=request)
        return success_response(FraudAlertSerializer(alert).data)


class FraudRuleListView(APIView):
    permission_classes = [IsManagerOrOwner]

    def get(self, request):
        qs = FraudRule.objects.filter(business=request.user.business).order_by('rule_code')
        return success_response(FraudRuleSerializer(qs, many=True).data)


class FraudRuleDetailView(APIView):
    permission_classes = [IsOwner]

    def patch(self, request, rule_id):
        try:
            rule = FraudRule.objects.get(id=rule_id, business=request.user.business)
        except FraudRule.DoesNotExist:
            raise NotFound('Fraud rule not found.')
        s = FraudRuleSerializer(rule, data=request.data, partial=True)
        s.is_valid(raise_exception=True)
        s.save()
        AuditService.log(action='fraud_rule.updated', entity_type='fraud_rule', entity_id=str(rule.id),
                         business=request.user.business, new_values=s.validated_data, request=request)
        return success_response(FraudRuleSerializer(rule).data)
