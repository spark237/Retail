from django.urls import path

from apps.fraud.views import (
    FraudAlertAcknowledgeView,
    FraudAlertDismissView,
    FraudAlertListView,
    FraudAlertResolveView,
    FraudRuleDetailView,
    FraudRuleListView,
)

urlpatterns = [
    path('',                                FraudAlertListView.as_view(),         name='alert-list'),
    path('<uuid:alert_id>/acknowledge/',    FraudAlertAcknowledgeView.as_view(),  name='alert-acknowledge'),
    path('<uuid:alert_id>/resolve/',        FraudAlertResolveView.as_view(),      name='alert-resolve'),
    path('<uuid:alert_id>/dismiss/',        FraudAlertDismissView.as_view(),      name='alert-dismiss'),
    path('rules/',                          FraudRuleListView.as_view(),          name='fraud-rules'),
    path('rules/<uuid:rule_id>/',           FraudRuleDetailView.as_view(),        name='fraud-rule-detail'),
]
