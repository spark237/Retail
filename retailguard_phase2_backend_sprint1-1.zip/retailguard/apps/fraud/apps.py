from django.apps import AppConfig


class FraudConfigAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.fraud'
    label = 'fraud'
