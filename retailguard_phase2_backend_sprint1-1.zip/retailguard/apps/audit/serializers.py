"""RetailGuard Audit — Serializers"""
from rest_framework import serializers

from apps.audit.models import AuditLog


class AuditLogSerializer(serializers.ModelSerializer):
    user_name   = serializers.SerializerMethodField()
    branch_name = serializers.CharField(source='branch.name', read_only=True, default=None)

    class Meta:
        model  = AuditLog
        fields = [
            'id', 'action', 'entity_type', 'entity_id',
            'user_id', 'user_name', 'branch_id', 'branch_name',
            'old_values', 'new_values',
            'ip_address', 'created_at',
        ]

    def get_user_name(self, obj):
        return obj.user.full_name if obj.user_id and obj.user else None
