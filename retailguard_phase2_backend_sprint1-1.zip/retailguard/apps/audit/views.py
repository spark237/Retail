"""RetailGuard Audit — Views (read-only)"""
from rest_framework.views import APIView

from apps.audit.models import AuditLog
from apps.audit.serializers import AuditLogSerializer
from apps.core.pagination import StandardPagination
from apps.core.permissions import IsManagerOrOwner


class AuditLogListView(APIView):
    """
    GET /api/v1/audit-logs/
    Read-only. Append-only table — no create/update/delete via API.
    Owners see all. Managers see own branch, limited action scope.
    """
    permission_classes = [IsManagerOrOwner]

    def get(self, request):
        qs = AuditLog.objects.filter(
            business=request.user.business
        ).select_related('user', 'branch').order_by('-created_at')

        # Managers: own branch only, exclude sensitive user.* events for other branches
        if request.user.role != 'owner':
            branch_ids = list(
                request.user.branch_assignments
                .filter(revoked_at__isnull=True, branch_id__isnull=False)
                .values_list('branch_id', flat=True)
            )
            qs = qs.filter(branch_id__in=branch_ids)

        if et := request.query_params.get('entity_type'):
            qs = qs.filter(entity_type=et)
        if eid := request.query_params.get('entity_id'):
            qs = qs.filter(entity_id=eid)
        if action := request.query_params.get('action'):
            qs = qs.filter(action=action)
        if uid := request.query_params.get('user_id'):
            qs = qs.filter(user_id=uid)
        if bid := request.query_params.get('branch_id'):
            qs = qs.filter(branch_id=bid)
        if from_dt := request.query_params.get('from_date'):
            qs = qs.filter(created_at__date__gte=from_dt)
        if to_dt := request.query_params.get('to_date'):
            qs = qs.filter(created_at__date__lte=to_dt)

        paginator = StandardPagination()
        page = paginator.paginate_queryset(qs, request)
        return paginator.get_paginated_response(AuditLogSerializer(page, many=True).data)
