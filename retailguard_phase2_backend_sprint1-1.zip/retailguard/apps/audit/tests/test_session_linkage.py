"""
Regression tests for AuditLog.session linkage (High Priority technical
debt item, Sprint 1). Proves:
  1. Successful login creates an audit record with the correct session.
  2. Failed login creates an audit record without a session.
  3. Account lockout creates an audit record.
  4. Logout creates an audit record linked to the session being terminated.
  5. Terminal takeover creates an audit record with the acting user and
     affected terminal/session.
  6. Audit logging failure does not break authentication.
"""
from unittest.mock import patch

import pytest
from django.urls import reverse
from django.utils import timezone

from apps.audit.actions import AuditAction
from apps.audit.models import AuditLog
from apps.core.tests.factories import CashierFactory, ManagerFactory
from apps.users.models import UserSession


@pytest.mark.django_db
class TestLoginAuditLinkage:
    def test_successful_login_creates_audit_record_with_session(self, api_client, business):
        cashier = CashierFactory(business=business, email='auditme@retailguard.test')

        response = api_client.post(reverse('auth-login'), {
            'identifier': 'auditme@retailguard.test',
            'password': 'TestPass123!',
        }, format='json')
        assert response.status_code == 200

        log = AuditLog.objects.get(action=AuditAction.USER_LOGIN, entity_id=str(cashier.id))
        assert log.session is not None
        assert log.user_id == cashier.id
        # The session on the audit record must be the one actually issued
        # by this login, not just any session belonging to the user.
        issued_session = UserSession.objects.get(user=cashier)
        assert log.session_id == issued_session.id

    def test_failed_login_creates_audit_record_without_session(self, api_client, business):
        cashier = CashierFactory(business=business, email='auditfail@retailguard.test')

        response = api_client.post(reverse('auth-login'), {
            'identifier': 'auditfail@retailguard.test',
            'password': 'WrongPassword!',
        }, format='json')
        assert response.status_code == 401

        log = AuditLog.objects.get(
            action=AuditAction.USER_LOGIN_FAILED, entity_id=str(cashier.id)
        )
        assert log.session is None
        assert log.user_id == cashier.id
        assert log.new_values['reason'] == 'wrong_password'
        # No session should have been created at all for a failed login.
        assert not UserSession.objects.filter(user=cashier).exists()

    def test_account_lockout_creates_audit_record(self, api_client, business):
        cashier = CashierFactory(business=business, email='auditlock@retailguard.test')

        for _ in range(5):
            api_client.post(reverse('auth-login'), {
                'identifier': 'auditlock@retailguard.test',
                'password': 'WrongPassword!',
            }, format='json')

        # 5 failed-login records plus exactly one distinct lockout record.
        failed = AuditLog.objects.filter(
            action=AuditAction.USER_LOGIN_FAILED, entity_id=str(cashier.id)
        )
        locked = AuditLog.objects.filter(
            action=AuditAction.USER_LOCKED, entity_id=str(cashier.id)
        )
        assert failed.count() == 5
        assert locked.count() == 1
        assert locked.first().session is None

        # A subsequent attempt against the now-locked account is itself
        # audited too (reason: account_locked), not silently dropped.
        api_client.post(reverse('auth-login'), {
            'identifier': 'auditlock@retailguard.test',
            'password': 'TestPass123!',
        }, format='json')
        locked_attempt = AuditLog.objects.filter(
            action=AuditAction.USER_LOGIN_FAILED, entity_id=str(cashier.id),
            new_values__reason='account_locked',
        )
        assert locked_attempt.exists()


@pytest.mark.django_db
class TestLogoutAuditLinkage:
    def test_logout_creates_audit_record_linked_to_terminated_session(
        self, api_client, business
    ):
        cashier = CashierFactory(business=business, email='auditlogout@retailguard.test')

        login_response = api_client.post(reverse('auth-login'), {
            'identifier': 'auditlogout@retailguard.test',
            'password': 'TestPass123!',
        }, format='json')
        access_token = login_response.data['data']['access_token']
        session = UserSession.objects.get(user=cashier)

        api_client.credentials(HTTP_AUTHORIZATION=f'Bearer {access_token}')
        logout_response = api_client.post(reverse('auth-logout'), format='json')
        assert logout_response.status_code == 200

        log = AuditLog.objects.get(action=AuditAction.USER_LOGOUT, entity_id=str(cashier.id))
        assert log.session_id == session.id

        session.refresh_from_db()
        assert session.is_active is False
        assert session.termination_reason == 'logout'


@pytest.mark.django_db
class TestTerminalTakeoverAuditLinkage:
    def test_terminal_takeover_creates_audit_record_with_actor_and_affected_session(
        self, api_client, business, branch
    ):
        from apps.shifts.models import Shift

        old_cashier = CashierFactory(business=business)
        manager = ManagerFactory(business=business)
        manager.set_override_pin('1234')

        old_session = UserSession.objects.create(
            user=old_cashier,
            token_hash='irrelevant-for-this-test',
            expires_at=timezone.now(),
        )
        old_shift = Shift.objects.create(
            business=business, branch=branch, cashier=old_cashier, status='open',
        )

        api_client.credentials(
            HTTP_AUTHORIZATION=f'Bearer {_manager_token(manager)}'
        )
        response = api_client.post(reverse('auth-terminal-takeover'), {
            'branch_id': str(branch.id),
            'approval_method': 'pin',
            'credential': '1234',
            'reason': 'Cashier device lost',
        }, format='json')

        assert response.status_code == 200

        log = AuditLog.objects.get(
            action=AuditAction.TERMINAL_OVERRIDE, entity_id=str(branch.id)
        )
        assert log.user_id == manager.id  # acting user is the manager, not the old cashier
        assert log.new_values['previous_cashier_id'] == str(old_cashier.id)
        assert log.new_values['affected_shift_id'] == str(old_shift.id)

        old_shift.refresh_from_db()
        assert old_shift.status == 'force_closed'
        old_session.refresh_from_db()
        assert old_session.is_active is False


def _manager_token(manager):
    from apps.authentication.tokens import RetailGuardAccessToken
    return str(RetailGuardAccessToken.for_user(manager))


@pytest.mark.django_db
class TestAuditLoggingIsBestEffort:
    def test_audit_logging_failure_does_not_break_login(self, api_client, business):
        cashier = CashierFactory(business=business, email='resilience@retailguard.test')

        with patch(
            'apps.audit.models.AuditLog.objects.create',
            side_effect=Exception('simulated DB error writing audit log'),
        ):
            response = api_client.post(reverse('auth-login'), {
                'identifier': 'resilience@retailguard.test',
                'password': 'TestPass123!',
            }, format='json')

        # The login itself must succeed even though audit logging blew up.
        assert response.status_code == 200
        assert response.data['data']['access_token']
        # And no audit record exists for it, since the write genuinely failed —
        # this proves the failure was swallowed, not that it silently worked.
        assert not AuditLog.objects.filter(
            action=AuditAction.USER_LOGIN, entity_id=str(cashier.id)
        ).exists()
