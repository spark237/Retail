"""
Centralized audit action names.

Only the actions touched by this authentication-auditing work are defined
here for now (login/logout/lockout/terminal-override). The ~21 other
AuditService.log() call sites across the codebase (sales, inventory,
transfers, etc.) still use string literals matching the ACTION CATALOGUE
documented in apps/audit/models.py — migrating those to this enum is a
separate, larger backlog item, not done as part of this change, to avoid
an unscoped repo-wide refactor riding on top of the auth-auditing fix.
"""
from django.db import models


class AuditAction(models.TextChoices):
    USER_LOGIN         = 'user.login',         'User Login'
    USER_LOGIN_FAILED  = 'user.login_failed',  'User Login Failed'
    USER_LOCKED        = 'user.locked',        'User Account Locked'
    USER_LOGOUT        = 'user.logout',        'User Logout'
    TERMINAL_OVERRIDE  = 'terminal.override',  'Terminal Override'
