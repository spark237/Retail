"""
RetailGuard Audit — AuditLog

IMMUTABLE — append-only. No UPDATE or DELETE ever.
Partitioned monthly for query performance at scale.
Feeds from all 28 tables via the audit_service.

ACTION FORMAT: 'entity.verb'
  sale.created        sale.voided         sale.synced
  product.created     product.price_changed
  user.login          user.login_failed   user.locked
  inventory.adjusted  inventory.damage_approved
  transfer.dispatched transfer.confirmed
  shift.opened        shift.force_closed
  terminal.override
  approval.price_override_granted
  alert.dismissed     alert.resolved
"""
import uuid

from django.conf import settings
from django.db import models


class AuditLog(models.Model):
    """
    System-wide immutable event log.
    Partitioned by created_at in PostgreSQL (monthly).
    Django model is the parent — partitions created via raw SQL migrations.

    No application code should UPDATE or DELETE rows from this table.
    In production: REVOKE UPDATE, DELETE ON audit_logs FROM app_user;
    """
    id              = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    business        = models.ForeignKey('branches.Business', on_delete=models.DO_NOTHING, related_name='audit_logs', db_constraint=False)
    user            = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.DO_NOTHING, related_name='audit_logs', db_constraint=False)
    branch          = models.ForeignKey('branches.Branch', null=True, blank=True, on_delete=models.DO_NOTHING, related_name='audit_logs', db_constraint=False)
    session         = models.ForeignKey('users.UserSession', null=True, blank=True, on_delete=models.DO_NOTHING, related_name='audit_logs', db_constraint=False)

    # Action: 'entity.verb' format
    action          = models.CharField(max_length=100)
    entity_type     = models.CharField(max_length=50)
    entity_id       = models.CharField(max_length=100)

    old_values      = models.JSONField(null=True, blank=True)
    new_values      = models.JSONField(null=True, blank=True)

    ip_address      = models.GenericIPAddressField(null=True, blank=True)
    device_info     = models.JSONField(default=dict, blank=True)
    created_at      = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'audit_logs'
        ordering = ['-created_at']
        # db_constraint=False on FKs because partitioned tables don't support FK constraints in PostgreSQL
        indexes = [
            models.Index(fields=['entity_type', 'entity_id'], name='idx_audit_entity'),
            models.Index(fields=['user', '-created_at'],       name='idx_audit_user'),
            models.Index(fields=['action', '-created_at'],     name='idx_audit_action'),
            models.Index(fields=['business', '-created_at'],   name='idx_audit_business'),
        ]

    def __str__(self):
        return f"[{self.created_at}] {self.action} on {self.entity_type}:{self.entity_id}"


# ─── AUDIT SERVICE ────────────────────────────────────────────────────────────

class AuditService:
    """
    Centralised audit log writer. Called from views, services, and signals.
    Reads request context from thread-local (set by AuditMiddleware).
    """

    @classmethod
    def log(
        cls,
        *,
        action: str,
        entity_type: str,
        entity_id: str,
        business,
        old_values: dict = None,
        new_values: dict = None,
        user=None,
        branch=None,
        session=None,
        request=None,
    ):
        """
        Write an audit log entry. Best-effort: any failure here (DB error,
        bad lookup, whatever) is logged and swallowed, never raised — audit
        logging must never be able to block a legitimate login, sale, or
        any other business action. This is a deliberate trade-off: a missed
        audit row is recoverable in a way that a blocked sale is not.

        Args:
            action:       'entity.verb' string, e.g. 'sale.voided' (prefer
                          apps.audit.actions.AuditAction constants for new
                          call sites)
            entity_type:  model name, e.g. 'sale'
            entity_id:    PK of affected record as string
            business:     Business instance
            old_values:   dict of fields before change (None for creates)
            new_values:   dict of fields after change (None for deletes)
            user:         User instance (None for system actions, or when
                          the action itself represents a failed/anonymous
                          attempt — pass explicitly, since request.user
                          won't be authenticated in that case)
            branch:       Branch instance (optional context)
            session:      UserSession instance, if already known by the
                          caller (e.g. login just created it, so the
                          request itself carries no Bearer token yet to
                          auto-resolve from). Takes precedence over
                          auto-resolution from the request.
            request:      Django request (optional; used to extract IP and,
                          if `session` isn't passed explicitly, to
                          auto-resolve the session from the request's
                          Bearer token — same lookup LogoutView uses).
        """
        import logging

        logger = logging.getLogger(__name__)

        try:
            from apps.core.middleware import get_current_request
            from apps.core.utils import get_client_ip
            from apps.core.utils import hash_token as _hash_token

            if request is None:
                request = get_current_request()

            ip = get_client_ip(request) if request else None
            device_info = {}

            if request and hasattr(request, 'user') and request.user.is_authenticated:
                if user is None:
                    user = request.user
                device_info = {'user_agent': request.META.get('HTTP_USER_AGENT', '')}

                if session is None:
                    auth_header = request.headers.get('Authorization', '')
                    if auth_header.startswith('Bearer '):
                        from apps.users.models import UserSession
                        token_str = auth_header.split(' ', 1)[1]
                        token_hash = _hash_token(token_str)
                        session = UserSession.objects.filter(
                            user=user, token_hash=token_hash, is_active=True
                        ).first()

            AuditLog.objects.create(
                business=business,
                user=user,
                branch=branch,
                session=session,
                action=action,
                entity_type=entity_type,
                entity_id=str(entity_id),
                old_values=old_values,
                new_values=new_values,
                ip_address=ip,
                device_info=device_info,
            )
        except Exception:
            logger.exception(
                "AuditService.log failed for action=%s entity_type=%s entity_id=%s "
                "— continuing without blocking the caller",
                action, entity_type, entity_id,
            )
