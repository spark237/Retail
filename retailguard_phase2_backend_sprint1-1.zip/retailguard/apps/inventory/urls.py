from django.urls import path

from apps.inventory.views import (
    DamageReportApproveView,
    DamageReportListCreateView,
    DamageReportRejectView,
    InventoryAdjustmentView,
    InventoryMovementListView,
    InventoryStockView,
)

urlpatterns = [
    path('',                                         InventoryStockView.as_view(),          name='inventory-stock'),
    path('adjustments/',                             InventoryAdjustmentView.as_view(),     name='inventory-adjust'),
    path('movements/',                               InventoryMovementListView.as_view(),   name='inventory-movements'),
    path('damage-reports/',                          DamageReportListCreateView.as_view(),  name='damage-report-list'),
    path('damage-reports/<uuid:report_id>/approve/', DamageReportApproveView.as_view(),    name='damage-report-approve'),
    path('damage-reports/<uuid:report_id>/reject/',  DamageReportRejectView.as_view(),     name='damage-report-reject'),
]
