"""RetailGuard Inventory — Views"""
from decimal import Decimal

from django.db import transaction
from django.utils import timezone
from rest_framework.exceptions import NotFound
from rest_framework.views import APIView

from apps.audit.models import AuditService
from apps.core.pagination import StandardPagination
from apps.core.permissions import IsAnyActiveStaff, IsCashierOrAbove, IsManagerOrOwner
from apps.core.utils import convert_to_stock_unit, success_response
from apps.inventory.models import InventoryDamageReport, InventoryMovement, InventoryStock, MovementType
from apps.inventory.serializers import (
    AdjustmentSerializer,
    DamageReportCreateSerializer,
    DamageReportSerializer,
    InventoryMovementSerializer,
    InventoryStockSerializer,
)
from apps.products.models import Product


class InventoryStockView(APIView):
    permission_classes = [IsCashierOrAbove]

    def get(self, request):
        qs = InventoryStock.objects.filter(
            product__business=request.user.business
        ).select_related('product', 'branch', 'warehouse')

        if bid := request.query_params.get('branch_id'):
            qs = qs.filter(branch_id=bid)
        if wid := request.query_params.get('warehouse_id'):
            qs = qs.filter(warehouse_id=wid)
        if pid := request.query_params.get('product_id'):
            qs = qs.filter(product_id=pid)
        if request.query_params.get('low_stock') == 'true':
            # Filter items at or below reorder level
            qs = [s for s in qs if s.quantity <= s.product.reorder_level]

        paginator = StandardPagination()
        if isinstance(qs, list):
            page = paginator.paginate_queryset(qs, request)
        else:
            page = paginator.paginate_queryset(qs, request)
        return paginator.get_paginated_response(InventoryStockSerializer(page, many=True).data)


class InventoryAdjustmentView(APIView):
    permission_classes = [IsManagerOrOwner]

    @transaction.atomic
    def post(self, request):
        s = AdjustmentSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        data = s.validated_data

        try:
            product = Product.objects.get(id=data['product_id'], business=request.user.business)
        except Product.DoesNotExist:
            raise NotFound('Product not found.')

        stock = InventoryStock.objects.select_for_update().filter(
            product=product,
            branch_id=data.get('branch_id'),
            warehouse_id=data.get('warehouse_id'),
        ).first()

        if not stock:
            raise NotFound('Stock record not found for this product at this location.')

        qty_before = stock.quantity
        qty_after  = Decimal(str(data['new_quantity']))
        qty_change = qty_after - qty_before

        stock.quantity = qty_after
        stock.updated_at = timezone.now()
        stock.save(update_fields=['quantity', 'updated_at'])

        movement = InventoryMovement.objects.create(
            business=request.user.business,
            product=product,
            branch_id=data.get('branch_id'),
            warehouse_id=data.get('warehouse_id'),
            movement_type=MovementType.ADJUSTMENT,
            quantity_before=qty_before,
            quantity_change=qty_change,
            quantity_after=qty_after,
            notes=data.get('notes') or data['reason'],
            performed_by=request.user,
            approved_by=request.user,
        )

        AuditService.log(
            action='inventory.adjusted', entity_type='inventory_movement', entity_id=str(movement.id),
            business=request.user.business,
            old_values={'quantity': str(qty_before)},
            new_values={'quantity': str(qty_after), 'reason': data['reason']},
            request=request,
        )

        # Check if large adjustment warrants fraud alert
        from apps.fraud.models import FraudRule, RuleCode
        from apps.fraud.services import FraudDetectionService
        rule = FraudRule.objects.filter(business=request.user.business, rule_code=RuleCode.INVENTORY_MISMATCH).first()
        if rule and rule.is_active and abs(qty_change) >= (rule.threshold_value or 1):
            FraudDetectionService._create_alert(
                business=request.user.business,
                branch_id=data.get('branch_id'),
                rule=rule,
                title=f'Stock adjustment — {product.name}',
                description=f'Manual adjustment: {qty_before} → {qty_after} ({qty_change:+}). Reason: {data["reason"]}',
                reference_type='inventory_movement',
                reference_id=str(movement.id),
                triggered_by=request.user,
            )

        return success_response(InventoryMovementSerializer(movement).data, status=201)


class InventoryMovementListView(APIView):
    permission_classes = [IsManagerOrOwner]

    def get(self, request):
        qs = InventoryMovement.objects.filter(
            business=request.user.business
        ).select_related('product', 'performed_by').order_by('-created_at')

        if pid := request.query_params.get('product_id'):
            qs = qs.filter(product_id=pid)
        if bid := request.query_params.get('branch_id'):
            qs = qs.filter(branch_id=bid)
        if mt := request.query_params.get('movement_type'):
            qs = qs.filter(movement_type=mt)
        if from_dt := request.query_params.get('from_date'):
            qs = qs.filter(created_at__date__gte=from_dt)
        if to_dt := request.query_params.get('to_date'):
            qs = qs.filter(created_at__date__lte=to_dt)

        paginator = StandardPagination()
        page = paginator.paginate_queryset(qs, request)
        return paginator.get_paginated_response(InventoryMovementSerializer(page, many=True).data)


class DamageReportListCreateView(APIView):
    def get_permissions(self):
        return [IsManagerOrOwner()] if self.request.method == 'GET' else [IsAnyActiveStaff()]

    def get(self, request):
        qs = InventoryDamageReport.objects.filter(
            business=request.user.business, is_deleted=False
        ).select_related('product', 'reported_by', 'approved_by').order_by('-created_at')

        if bid := request.query_params.get('branch_id'):
            qs = qs.filter(branch_id=bid)
        if st := request.query_params.get('status'):
            qs = qs.filter(status=st)

        paginator = StandardPagination()
        page = paginator.paginate_queryset(qs, request)
        return paginator.get_paginated_response(DamageReportSerializer(page, many=True).data)

    def post(self, request):
        s = DamageReportCreateSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        data = s.validated_data

        try:
            product = Product.objects.get(id=data['product_id'], business=request.user.business)
        except Product.DoesNotExist:
            raise NotFound('Product not found.')

        qty_in_stock_unit = convert_to_stock_unit(
            data['quantity_damaged'], data['unit_reported'], product
        )

        report = InventoryDamageReport.objects.create(
            business=request.user.business,
            product=product,
            branch_id=data.get('branch_id'),
            warehouse_id=data.get('warehouse_id'),
            quantity_damaged=data['quantity_damaged'],
            unit_reported=data['unit_reported'],
            quantity_in_stock_unit=qty_in_stock_unit,
            damage_type=data['damage_type'],
            description=data['description'],
            photo_reference=data.get('photo_reference'),
            reported_by=request.user,
        )

        # Fraud pattern check
        # (pattern check runs async in production; inline for MVP)

        AuditService.log(action='inventory.damage_reported', entity_type='damage_report',
                         entity_id=str(report.id), business=request.user.business, request=request)
        return success_response(DamageReportSerializer(report).data, status=201)


class DamageReportApproveView(APIView):
    permission_classes = [IsManagerOrOwner]

    @transaction.atomic
    def post(self, request, report_id):
        try:
            report = InventoryDamageReport.objects.select_for_update().get(
                id=report_id, business=request.user.business, status='pending'
            )
        except InventoryDamageReport.DoesNotExist:
            raise NotFound('Damage report not found or already processed.')

        if str(report.reported_by_id) == str(request.user.id):
            from apps.core.exceptions import RetailGuardException
            raise RetailGuardException(
                detail='You cannot approve your own damage report.', code='SELF_APPROVAL_FORBIDDEN'
            )

        stock = InventoryStock.objects.select_for_update().filter(
            product=report.product,
            branch_id=report.branch_id,
            warehouse_id=report.warehouse_id,
        ).first()

        if not stock:
            raise NotFound('Stock record not found.')

        qty_before = stock.quantity
        qty_change = -report.quantity_in_stock_unit
        qty_after  = qty_before + qty_change

        if qty_after < 0:
            from apps.core.exceptions import NegativeStockPreventedError
            raise NegativeStockPreventedError(
                extra={'available': str(qty_before), 'damage_qty': str(report.quantity_in_stock_unit)}
            )

        stock.quantity = qty_after
        stock.save(update_fields=['quantity', 'updated_at'])

        movement = InventoryMovement.objects.create(
            business=request.user.business,
            product=report.product,
            branch_id=report.branch_id,
            warehouse_id=report.warehouse_id,
            movement_type=MovementType.DAMAGE,
            quantity_before=qty_before,
            quantity_change=qty_change,
            quantity_after=qty_after,
            reference_type='damage_report',
            reference_id=str(report.id),
            performed_by=request.user,
            approved_by=request.user,
        )

        report.status = 'approved'
        report.approved_by = request.user
        report.approved_at = timezone.now()
        report.movement = movement
        report.save(update_fields=['status', 'approved_by', 'approved_at', 'movement', 'updated_at'])

        AuditService.log(action='inventory.damage_approved', entity_type='damage_report',
                         entity_id=str(report.id), business=request.user.business, request=request)
        return success_response({
            'id': str(report.id), 'status': 'approved',
            'movement_id': movement.id,
            'quantity_deducted': str(report.quantity_in_stock_unit),
            'new_stock': str(qty_after),
        })


class DamageReportRejectView(APIView):
    permission_classes = [IsManagerOrOwner]

    def post(self, request, report_id):
        try:
            report = InventoryDamageReport.objects.get(
                id=report_id, business=request.user.business, status='pending'
            )
        except InventoryDamageReport.DoesNotExist:
            raise NotFound('Damage report not found or already processed.')

        if str(report.reported_by_id) == str(request.user.id):
            from apps.core.exceptions import RetailGuardException
            raise RetailGuardException(detail='Cannot reject your own report.', code='SELF_APPROVAL_FORBIDDEN')

        rejection_note = request.data.get('rejection_note', '').strip()
        if not rejection_note:
            from rest_framework.exceptions import ValidationError
            raise ValidationError({'rejection_note': 'Rejection note is required.'})

        report.status = 'rejected'
        report.rejection_note = rejection_note
        report.approved_by = request.user
        report.save(update_fields=['status', 'rejection_note', 'approved_by', 'updated_at'])

        return success_response({'id': str(report.id), 'status': 'rejected'})
