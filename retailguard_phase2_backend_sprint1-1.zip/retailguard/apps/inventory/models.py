"""
RetailGuard Inventory — InventoryStock, InventoryMovement, InventoryDamageReport

ARCHITECTURE RULES (locked):
  1. inventory_stock is a DENORMALIZED SNAPSHOT — not the source of truth
  2. inventory_movements is the IMMUTABLE SOURCE OF TRUTH
  3. Both are updated atomically in the same DB transaction
  4. No stock change without a movement record — ever
  5. SALE_VOID is a distinct movement type — not an adjustment
  6. quantity_non_negative CHECK is the last line of defence after SELECT FOR UPDATE
"""
import uuid

from django.conf import settings
from django.db import models

from apps.core.models import QuantityField, SoftDeleteModel


class MovementType(models.TextChoices):
    OPENING_STOCK   = 'OPENING_STOCK',  'Opening Stock'
    RESTOCK         = 'RESTOCK',        'Restock'
    SALE            = 'SALE',           'Sale'
    SALE_VOID       = 'SALE_VOID',      'Sale Void'      # v4: distinct from ADJUSTMENT
    TRANSFER_OUT    = 'TRANSFER_OUT',   'Transfer Out'
    TRANSFER_IN     = 'TRANSFER_IN',    'Transfer In'
    DAMAGE          = 'DAMAGE',         'Damage'
    ADJUSTMENT      = 'ADJUSTMENT',     'Adjustment'
    COUNT_CORRECTION = 'COUNT_CORRECTION', 'Count Correction'


class InventoryStock(models.Model):
    """
    Live quantity snapshot per product per location.
    BRANCH ISOLATION: each (product, branch) pair has its own row.
    There is no global stock pool.

    Never update this directly — always through a movement transaction.
    Reconstruct any past state from inventory_movements WHERE created_at <= T.
    """
    id          = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    product     = models.ForeignKey('products.Product', on_delete=models.PROTECT, related_name='stock_levels')
    branch      = models.ForeignKey('branches.Branch', null=True, blank=True, on_delete=models.PROTECT, related_name='stock_levels')
    warehouse   = models.ForeignKey('branches.Warehouse', null=True, blank=True, on_delete=models.PROTECT, related_name='stock_levels')
    # LOCKED: NUMERIC(12,3) — SQM fractional deductions require 3dp
    quantity    = QuantityField(default=0)
    updated_at  = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'inventory_stock'
        constraints = [
            models.UniqueConstraint(
                fields=['product', 'branch', 'warehouse'],
                name='uq_stock_per_location',
            ),
            models.CheckConstraint(
                condition=(
                    models.Q(branch__isnull=False, warehouse__isnull=True) |
                    models.Q(warehouse__isnull=False, branch__isnull=True)
                ),
                name='inv_stock_location_exclusive',
            ),
            models.CheckConstraint(
                condition=models.Q(quantity__gte=0),
                name='quantity_non_negative',  # Last safety net after SELECT FOR UPDATE
            ),
        ]
        indexes = [
            models.Index(
                fields=['product', 'branch'],
                name='idx_inv_stock_branch',
                condition=models.Q(branch__isnull=False),
            ),
            models.Index(
                fields=['product', 'warehouse'],
                name='idx_inv_stock_warehouse',
                condition=models.Q(warehouse__isnull=False),
            ),
        ]

    def __str__(self):
        location = self.branch or self.warehouse
        return f"{self.product.name} @ {location}: {self.quantity}"


class InventoryMovement(models.Model):
    """
    IMMUTABLE SOURCE OF TRUTH for all stock changes.
    BIGSERIAL PK: highest insert volume in the system.
    Every movement validates: quantity_before + quantity_change = quantity_after.

    SALE_VOID is distinct from ADJUSTMENT:
      - Enables clean fraud query: cashier void frequency
      - Prevents voids from polluting manual adjustment reports
      - SELECT COUNT(*) ... WHERE movement_type='SALE_VOID' = meaningful fraud signal
    """
    # BigAutoField → BIGSERIAL
    id              = models.BigAutoField(primary_key=True)
    business        = models.ForeignKey('branches.Business', on_delete=models.PROTECT, related_name='inventory_movements')
    product         = models.ForeignKey('products.Product', on_delete=models.PROTECT, related_name='movements')
    branch          = models.ForeignKey('branches.Branch', null=True, blank=True, on_delete=models.PROTECT, related_name='inventory_movements')
    warehouse       = models.ForeignKey('branches.Warehouse', null=True, blank=True, on_delete=models.PROTECT, related_name='inventory_movements')
    movement_type   = models.CharField(max_length=30, choices=MovementType.choices)
    quantity_before = QuantityField()
    quantity_change = QuantityField()  # negative = stock out
    quantity_after  = QuantityField()
    reference_type  = models.CharField(max_length=50, blank=True, null=True)
    reference_id    = models.CharField(max_length=100, blank=True, null=True)
    notes           = models.TextField(blank=True, null=True)
    performed_by    = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name='inventory_movements',
    )
    approved_by     = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True, blank=True,
        on_delete=models.PROTECT,
        related_name='approved_movements',
    )
    created_at      = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'inventory_movements'
        ordering = ['-created_at']
        constraints = [
            models.CheckConstraint(
                # quantity_before + quantity_change = quantity_after
                # Django can't express this directly; enforced in clean() + DB CHECK
                condition=models.Q(quantity_after__gte=0),
                name='movement_qty_after_non_negative',
            ),
            models.CheckConstraint(
                condition=(
                    models.Q(branch__isnull=False, warehouse__isnull=True) |
                    models.Q(warehouse__isnull=False, branch__isnull=True)
                ),
                name='inv_movement_location_exclusive',
            ),
        ]
        indexes = [
            models.Index(fields=['product', '-created_at'], name='idx_inv_movements_product'),
            models.Index(fields=['movement_type', '-created_at'], name='idx_inv_movements_type'),
            models.Index(fields=['reference_type', 'reference_id'], name='idx_inv_movements_ref'),
            models.Index(
                fields=['performed_by', 'movement_type', '-created_at'],
                name='idx_inv_movements_voids',
                condition=models.Q(movement_type='SALE_VOID'),
            ),
        ]

    def __str__(self):
        return f"{self.movement_type} {self.quantity_change} of {self.product.name}"

    def clean(self):
        from decimal import Decimal

        from django.core.exceptions import ValidationError
        if (self.quantity_before is not None and
            self.quantity_change is not None and
            self.quantity_after is not None):
            expected = Decimal(str(self.quantity_before)) + Decimal(str(self.quantity_change))
            actual = Decimal(str(self.quantity_after))
            if abs(expected - actual) > Decimal('0.0001'):
                raise ValidationError(
                    f'Movement math error: {self.quantity_before} + {self.quantity_change} '
                    f'≠ {self.quantity_after}'
                )


class DamageType(models.TextChoices):
    LOADING_BREAKAGE  = 'loading_breakage',  'Loading Breakage'
    TRANSIT_BREAKAGE  = 'transit_breakage',  'Transit Breakage'
    HANDLING_BREAKAGE = 'handling_breakage', 'Handling Breakage'
    WATER_DAMAGE      = 'water_damage',      'Water Damage'
    EXPIRED           = 'expired',           'Expired'
    OTHER             = 'other',             'Other'


class InventoryDamageReport(SoftDeleteModel):
    """
    Tiles break — this is a first-class business event.
    Approval required before any inventory deduction.

    FRAUD CONTROL:
      reported_by != approved_by enforced at service layer.
      DAMAGE_REPORT_PATTERN fraud rule monitors frequency per reporter.
      Photo evidence links to external storage (S3 in production).

    WORKFLOW:
      pending → approved: movement created, inventory deducted, movement_id set
      pending → rejected: no inventory change, rejection_note mandatory
    """
    class Status(models.TextChoices):
        PENDING  = 'pending',  'Pending Approval'
        APPROVED = 'approved', 'Approved'
        REJECTED = 'rejected', 'Rejected'

    id              = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    business        = models.ForeignKey('branches.Business', on_delete=models.PROTECT, related_name='damage_reports')
    product         = models.ForeignKey('products.Product', on_delete=models.PROTECT, related_name='damage_reports')
    branch          = models.ForeignKey('branches.Branch', null=True, blank=True, on_delete=models.PROTECT, related_name='damage_reports')
    warehouse       = models.ForeignKey('branches.Warehouse', null=True, blank=True, on_delete=models.PROTECT, related_name='damage_reports')
    quantity_damaged        = QuantityField()
    unit_reported           = models.CharField(max_length=20, choices=[
        (u, u) for u in ['PIECE', 'BOX', 'SQM', 'PALLET']
    ])
    quantity_in_stock_unit  = QuantityField()  # computed at submission from conversion factors
    damage_type     = models.CharField(max_length=30, choices=DamageType.choices)
    description     = models.TextField()
    photo_reference = models.TextField(blank=True, null=True)  # URL or S3 path
    reported_by     = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name='damage_reports_submitted',
    )
    approved_by     = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True, blank=True,
        on_delete=models.PROTECT,
        related_name='damage_reports_approved',
    )
    status          = models.CharField(max_length=20, choices=Status.choices, default=Status.PENDING)
    movement        = models.ForeignKey(
        InventoryMovement, null=True, blank=True,
        on_delete=models.PROTECT,
        related_name='damage_reports',
    )
    approved_at     = models.DateTimeField(null=True, blank=True)
    rejection_note  = models.TextField(blank=True, null=True)

    class Meta:
        db_table = 'inventory_damage_reports'
        constraints = [
            models.CheckConstraint(
                condition=(
                    models.Q(branch__isnull=False, warehouse__isnull=True) |
                    models.Q(warehouse__isnull=False, branch__isnull=True)
                ),
                name='damage_report_location_exclusive',
            ),
        ]
        indexes = [
            models.Index(
                fields=['business', 'status'],
                name='idx_damage_pending',
                condition=models.Q(status='pending'),
            ),
            models.Index(fields=['reported_by', '-created_at'], name='idx_damage_reporter'),
        ]

    def __str__(self):
        return f"Damage: {self.quantity_damaged} {self.unit_reported} of {self.product.name} [{self.status}]"
