"""RetailGuard Inventory — Serializers"""
from decimal import Decimal

from rest_framework import serializers

from apps.inventory.models import InventoryDamageReport, InventoryMovement, InventoryStock


class InventoryStockSerializer(serializers.ModelSerializer):
    product_name = serializers.CharField(source='product.name', read_only=True)
    product_sku  = serializers.CharField(source='product.sku',  read_only=True)
    tile_size    = serializers.CharField(source='product.tile_size', read_only=True)
    stock_unit   = serializers.CharField(source='product.stock_unit', read_only=True)
    reorder_level = serializers.DecimalField(source='product.reorder_level', max_digits=12, decimal_places=3, read_only=True)
    is_low_stock = serializers.SerializerMethodField()
    location     = serializers.SerializerMethodField()

    class Meta:
        model  = InventoryStock
        fields = [
            'product_id', 'product_name', 'product_sku', 'tile_size',
            'stock_unit', 'quantity', 'reorder_level', 'is_low_stock',
            'location', 'updated_at',
        ]

    def get_is_low_stock(self, obj):
        return obj.quantity <= obj.product.reorder_level

    def get_location(self, obj):
        if obj.branch_id:
            return {'type': 'branch', 'id': str(obj.branch_id), 'name': obj.branch.name if obj.branch else None}
        return {'type': 'warehouse', 'id': str(obj.warehouse_id), 'name': obj.warehouse.name if obj.warehouse else None}


class InventoryMovementSerializer(serializers.ModelSerializer):
    product_name    = serializers.CharField(source='product.name', read_only=True)
    performed_by_name = serializers.CharField(source='performed_by.full_name', read_only=True)
    location        = serializers.SerializerMethodField()

    class Meta:
        model  = InventoryMovement
        fields = [
            'id', 'product_id', 'product_name', 'location',
            'movement_type', 'quantity_before', 'quantity_change', 'quantity_after',
            'reference_type', 'reference_id', 'notes',
            'performed_by_id', 'performed_by_name', 'created_at',
        ]

    def get_location(self, obj):
        if obj.branch_id:
            return {'type': 'branch', 'id': str(obj.branch_id)}
        return {'type': 'warehouse', 'id': str(obj.warehouse_id)}


class AdjustmentSerializer(serializers.Serializer):
    product_id   = serializers.UUIDField()
    branch_id    = serializers.UUIDField(required=False, allow_null=True)
    warehouse_id = serializers.UUIDField(required=False, allow_null=True)
    new_quantity = serializers.DecimalField(max_digits=12, decimal_places=3, min_value=Decimal('0'))
    reason       = serializers.CharField(min_length=10)
    notes        = serializers.CharField(required=False, allow_blank=True)

    def validate(self, data):
        if not data.get('branch_id') and not data.get('warehouse_id'):
            raise serializers.ValidationError('branch_id or warehouse_id is required.')
        if data.get('branch_id') and data.get('warehouse_id'):
            raise serializers.ValidationError('Provide only one of branch_id or warehouse_id.')
        return data


class DamageReportSerializer(serializers.ModelSerializer):
    reported_by_name = serializers.CharField(source='reported_by.full_name', read_only=True)
    approved_by_name = serializers.CharField(source='approved_by.full_name', read_only=True, default=None)
    product_name     = serializers.CharField(source='product.name', read_only=True)

    class Meta:
        model  = InventoryDamageReport
        fields = [
            'id', 'product_id', 'product_name', 'branch_id', 'warehouse_id',
            'quantity_damaged', 'unit_reported', 'quantity_in_stock_unit',
            'damage_type', 'description', 'photo_reference', 'status',
            'reported_by_id', 'reported_by_name',
            'approved_by_id', 'approved_by_name',
            'approved_at', 'rejection_note', 'created_at',
        ]


class DamageReportCreateSerializer(serializers.Serializer):
    product_id       = serializers.UUIDField()
    branch_id        = serializers.UUIDField(required=False, allow_null=True)
    warehouse_id     = serializers.UUIDField(required=False, allow_null=True)
    quantity_damaged = serializers.DecimalField(max_digits=12, decimal_places=3, min_value=Decimal('0.001'))
    unit_reported    = serializers.ChoiceField(choices=['PIECE', 'BOX', 'SQM', 'PALLET'])
    damage_type      = serializers.ChoiceField(choices=[
        'loading_breakage', 'transit_breakage', 'handling_breakage',
        'water_damage', 'expired', 'other'
    ])
    description      = serializers.CharField(min_length=10)
    photo_reference  = serializers.CharField(required=False, allow_blank=True)

    def validate(self, data):
        if not data.get('branch_id') and not data.get('warehouse_id'):
            raise serializers.ValidationError('branch_id or warehouse_id is required.')
        return data
