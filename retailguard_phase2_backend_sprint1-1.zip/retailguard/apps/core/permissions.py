"""
RetailGuard Core — DRF Permission Classes

All permissions are role-based (RBAC). Roles are stored on the User model.
No permission groups or Django permissions system — just role checks.

Roles (ascending privilege):
  warehouse_staff < cashier < manager < owner
"""
from rest_framework.permissions import BasePermission

OWNER           = 'owner'
MANAGER         = 'manager'
CASHIER         = 'cashier'
WAREHOUSE_STAFF = 'warehouse_staff'

MANAGER_AND_ABOVE = [OWNER, MANAGER]
CASHIER_AND_ABOVE = [OWNER, MANAGER, CASHIER]
ALL_ROLES         = [OWNER, MANAGER, CASHIER, WAREHOUSE_STAFF]


def _is_active_staff(user):
    return (
        user and
        user.is_authenticated and
        user.is_active and
        not user.is_deleted
    )


class IsOwner(BasePermission):
    message = 'This action requires owner role.'

    def has_permission(self, request, view):
        return _is_active_staff(request.user) and request.user.role == OWNER


class IsManagerOrOwner(BasePermission):
    message = 'This action requires manager or owner role.'

    def has_permission(self, request, view):
        return _is_active_staff(request.user) and request.user.role in MANAGER_AND_ABOVE


class IsCashierOrAbove(BasePermission):
    message = 'This action requires cashier role or above.'

    def has_permission(self, request, view):
        return _is_active_staff(request.user) and request.user.role in CASHIER_AND_ABOVE


class IsAnyActiveStaff(BasePermission):
    message = 'Active staff account required.'

    def has_permission(self, request, view):
        return _is_active_staff(request.user) and request.user.role in ALL_ROLES


class CanOverrideTerminal(BasePermission):
    """terminal.override — manager and owner only."""
    message = 'Terminal override requires manager or owner role. Cashiers cannot override.'

    def has_permission(self, request, view):
        return _is_active_staff(request.user) and request.user.role in MANAGER_AND_ABOVE


class CanApproveDiscount(BasePermission):
    """discount.approve — manager and owner only."""
    message = 'Discount approval requires manager or owner role.'

    def has_permission(self, request, view):
        return _is_active_staff(request.user) and request.user.role in MANAGER_AND_ABOVE


class IsSameBusiness(BasePermission):
    """
    Object-level: resource must belong to the same business as the requester.
    Call check_object_permissions() in view.retrieve/update/destroy.
    """
    def has_object_permission(self, request, view, obj):
        resource_business_id = getattr(obj, 'business_id', None)
        if resource_business_id is None and hasattr(obj, 'business'):
            resource_business_id = obj.business.id
        return str(resource_business_id) == str(request.user.business_id)


class IsSameBranchOrOwner(BasePermission):
    """
    Object-level: owner sees all branches; other roles see only their assigned branches.
    """
    def has_object_permission(self, request, view, obj):
        user = request.user
        if user.role == OWNER:
            return str(getattr(obj, 'business_id', None)) == str(user.business_id)

        branch_id = str(getattr(obj, 'branch_id', ''))
        user_branch_ids = set(
            str(b) for b in user.branch_assignments
            .filter(revoked_at__isnull=True, branch_id__isnull=False)
            .values_list('branch_id', flat=True)
        )
        return branch_id in user_branch_ids
