"""
RetailGuard Core — Abstract Base Models
Every domain model in RetailGuard inherits from one of these.
"""
from django.conf import settings
from django.db import models
from django.utils import timezone

# ─── QUANTITY FIELD ──────────────────────────────────────────────────────────
# LOCKED: NUMERIC(12,3) for all tile/inventory quantities.
# Rationale: 1 SQM ÷ 1.44 SQM/BOX = 0.694 BOX — 3dp required.
# DecimalField(12,3) maps directly to PostgreSQL NUMERIC(12,3).

class QuantityField(models.DecimalField):
    """
    Standardised quantity field for inventory, sale quantities, and movements.
    Maps to NUMERIC(12,3) in PostgreSQL. Supports SQM fractional box quantities.
    """
    def __init__(self, *args, **kwargs):
        kwargs.setdefault('max_digits', 12)
        kwargs.setdefault('decimal_places', 3)
        kwargs.setdefault('default', 0)
        super().__init__(*args, **kwargs)


# ─── MANAGERS ────────────────────────────────────────────────────────────────

class SoftDeleteQuerySet(models.QuerySet):

    def alive(self):
        """Exclude soft-deleted records."""
        return self.filter(is_deleted=False)

    def deleted(self):
        """Return only soft-deleted records."""
        return self.filter(is_deleted=True)


class SoftDeleteManager(models.Manager):
    """
    Default manager. Automatically excludes soft-deleted records.
    Attach as `objects` on SoftDeleteModel subclasses.
    """
    def get_queryset(self):
        return SoftDeleteQuerySet(self.model, using=self._db).filter(is_deleted=False)


class AllObjectsManager(models.Manager):
    """
    Unfiltered manager. Includes deleted records.
    Use Model.all_objects for admin panels, audit queries, and migrations.
    """
    def get_queryset(self):
        return SoftDeleteQuerySet(self.model, using=self._db)


# ─── ABSTRACT BASE MODELS ────────────────────────────────────────────────────

class TimestampedModel(models.Model):
    """
    Abstract base model. Provides created_at and updated_at.
    All RetailGuard models inherit from this.
    """
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True


class SoftDeleteModel(TimestampedModel):
    """
    Abstract model with soft delete support.

    Usage:
        MyModel.objects.all()          → excludes deleted (default)
        MyModel.all_objects.all()      → includes deleted (admin/audit)
        instance.soft_delete(user)     → marks deleted
        instance.restore()             → reverses soft delete

    Database: is_deleted is indexed via partial indexes on child tables.
    """
    is_deleted = models.BooleanField(default=False)
    deleted_at = models.DateTimeField(null=True, blank=True)
    deleted_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name='+',
    )

    objects = SoftDeleteManager()
    all_objects = AllObjectsManager()

    class Meta:
        abstract = True

    def soft_delete(self, deleted_by_user=None):
        self.is_deleted = True
        self.deleted_at = timezone.now()
        self.deleted_by = deleted_by_user
        self.save(update_fields=['is_deleted', 'deleted_at', 'deleted_by', 'updated_at'])

    def restore(self):
        self.is_deleted = False
        self.deleted_at = None
        self.deleted_by = None
        self.save(update_fields=['is_deleted', 'deleted_at', 'deleted_by', 'updated_at'])
