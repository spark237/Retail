"""
RetailGuard Core — Shared Utilities

StandardPagination lives in apps.core.pagination (not here) to avoid
circular imports — views import pagination, utils imports nothing from views.
"""
import hashlib
from decimal import ROUND_HALF_UP, Decimal

from django.utils import timezone

# ─── RESPONSE HELPERS ────────────────────────────────────────────────────────

def success_response(data, status=200):
    """Wrap data in the standard success envelope."""
    from rest_framework.response import Response
    return Response({'success': True, 'data': data}, status=status)


# ─── TOKEN UTILITIES ─────────────────────────────────────────────────────────

def hash_token(raw_token: str) -> str:
    """
    SHA-256 hash of a raw JWT token.
    Stored in user_sessions.token_hash — never store raw tokens.
    """
    return hashlib.sha256(raw_token.encode()).hexdigest()


def hash_pin(raw_pin: str) -> str:
    """SHA-256 hash of an override PIN. Never store raw PINs."""
    return hashlib.sha256(raw_pin.encode()).hexdigest()


def verify_pin(raw_pin: str, stored_hash: str) -> bool:
    """Constant-time comparison of PIN hash."""
    import hmac
    return hmac.compare_digest(hash_pin(raw_pin), stored_hash)


# ─── IP EXTRACTION ───────────────────────────────────────────────────────────

def get_client_ip(request) -> str | None:
    """Extract real client IP, handling proxies."""
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        return x_forwarded_for.split(',')[0].strip()
    return request.META.get('REMOTE_ADDR')


# ─── QUANTITY CONVERSION ─────────────────────────────────────────────────────

def convert_to_stock_unit(quantity: Decimal, unit_sold: str, product) -> Decimal:
    """
    Convert a sale quantity from the sold unit to the product's stock_unit.

    Args:
        quantity:   quantity in unit_sold
        unit_sold:  'PIECE' | 'BOX' | 'SQM' | 'PALLET'
        product:    Product instance with conversion fields

    Returns:
        Decimal quantity in product.stock_unit, rounded to 3dp.

    Raises:
        ConversionFactorMissingError if required conversion factor is not set.
    """
    from apps.core.exceptions import ConversionFactorMissingError

    stock_unit = product.stock_unit
    quantity = Decimal(str(quantity))

    if unit_sold == stock_unit:
        return quantity.quantize(Decimal('0.001'), rounding=ROUND_HALF_UP)

    # BOX is the base unit for most tile products
    if stock_unit == 'BOX':
        if unit_sold == 'PIECE':
            if not product.pieces_per_box:
                raise ConversionFactorMissingError(
                    f"Product '{product.name}' has no pieces_per_box conversion factor.",
                    extra={'product_id': str(product.id), 'missing_factor': 'pieces_per_box'}
                )
            result = quantity / Decimal(str(product.pieces_per_box))

        elif unit_sold == 'SQM':
            if not product.sqm_per_box:
                raise ConversionFactorMissingError(
                    f"Product '{product.name}' has no sqm_per_box conversion factor.",
                    extra={'product_id': str(product.id), 'missing_factor': 'sqm_per_box'}
                )
            result = quantity / Decimal(str(product.sqm_per_box))

        elif unit_sold == 'PALLET':
            if not product.boxes_per_pallet:
                raise ConversionFactorMissingError(
                    f"Product '{product.name}' has no boxes_per_pallet conversion factor.",
                    extra={'product_id': str(product.id), 'missing_factor': 'boxes_per_pallet'}
                )
            result = quantity * Decimal(str(product.boxes_per_pallet))

        else:
            raise ConversionFactorMissingError(
                f"Unknown unit_sold: '{unit_sold}'",
                extra={'unit_sold': unit_sold}
            )
    else:
        raise ConversionFactorMissingError(
            f"Unsupported stock_unit: '{stock_unit}'",
            extra={'stock_unit': stock_unit}
        )

    return result.quantize(Decimal('0.001'), rounding=ROUND_HALF_UP)


def compute_total_price(unit_price: int, quantity_in_stock_unit: Decimal) -> int:
    """
    Compute total price in XAF.
    total = ROUND(unit_price × quantity_in_stock_unit)
    Always returns integer XAF — no decimal money.
    """
    total = Decimal(str(unit_price)) * quantity_in_stock_unit
    return int(total.quantize(Decimal('1'), rounding=ROUND_HALF_UP))


# ─── RECEIPT NUMBER GENERATION ───────────────────────────────────────────────

def generate_receipt_number(branch_code: str, counter: int) -> str:
    """
    Generate deterministic receipt number.
    Format: RCP-{BRANCHCODE}-{YYYYMMDD}-{COUNTER:04d}
    Example: RCP-BR003-20260627-0047
    """
    date_str = timezone.now().strftime('%Y%m%d')
    return f"RCP-{branch_code}-{date_str}-{counter:04d}"


def generate_transfer_number(counter: int) -> str:
    """
    Format: TRF-{YYYYMMDD}-{COUNTER:03d}
    Example: TRF-20260627-001
    """
    date_str = timezone.now().strftime('%Y%m%d')
    return f"TRF-{date_str}-{counter:03d}"
