"""
RetailGuard Core — Audit Middleware
Attaches request context to thread-local storage so audit logging
functions can access IP and session data without threading request
objects through every service call.
"""
import threading

_thread_locals = threading.local()


def get_current_request():
    return getattr(_thread_locals, 'request', None)


def get_current_user():
    request = get_current_request()
    if request and hasattr(request, 'user') and request.user.is_authenticated:
        return request.user
    return None


class AuditMiddleware:
    """Stores the current request in thread-local storage."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        _thread_locals.request = request
        try:
            response = self.get_response(request)
        finally:
            # Clean up to prevent memory leaks in long-lived processes
            if hasattr(_thread_locals, 'request'):
                del _thread_locals.request
        return response
