"""
Shared factory-boy factories for RetailGuard's core tenant/identity models.

Import these from any app's test suite rather than constructing Business/
Branch/User objects by hand — keeps required-field drift (e.g. a future
migration adding a new mandatory field) contained to one place instead of
scattered across every test file.
"""
import factory
from factory.django import DjangoModelFactory

from apps.branches.models import Branch, Business, Warehouse
from apps.users.models import User, UserRole


class BusinessFactory(DjangoModelFactory):
    class Meta:
        model = Business

    name = factory.Sequence(lambda n: f"Test Business {n}")
    slug = factory.Sequence(lambda n: f"test-business-{n}")
    currency = 'XAF'
    timezone = 'Africa/Douala'
    is_active = True


class BranchFactory(DjangoModelFactory):
    class Meta:
        model = Branch

    business = factory.SubFactory(BusinessFactory)
    name = factory.Sequence(lambda n: f"Test Branch {n}")
    code = factory.Sequence(lambda n: f"BR{n:03d}")
    is_active = True


class WarehouseFactory(DjangoModelFactory):
    class Meta:
        model = Warehouse

    business = factory.SubFactory(BusinessFactory)
    name = factory.Sequence(lambda n: f"Test Warehouse {n}")
    code = factory.Sequence(lambda n: f"WH{n:03d}")
    is_active = True


class UserFactory(DjangoModelFactory):
    """
    Uses User.objects.create_user (the real manager method, not raw
    .create()) so password hashing and required-field validation match
    production behavior exactly.
    """
    class Meta:
        model = User
        django_get_or_create = ('email',)

    business = factory.SubFactory(BusinessFactory)
    first_name = 'Test'
    last_name = factory.Sequence(lambda n: f"User{n}")
    email = factory.Sequence(lambda n: f"testuser{n}@retailguard.test")
    role = UserRole.CASHIER
    is_active = True

    @classmethod
    def _create(cls, model_class, *args, **kwargs):
        password = kwargs.pop('password', 'TestPass123!')
        business = kwargs.pop('business')
        role = kwargs.pop('role')
        manager = cls._get_manager(model_class)
        return manager.create_user(business=business, role=role, password=password, **kwargs)


class OwnerFactory(UserFactory):
    role = UserRole.OWNER


class ManagerFactory(UserFactory):
    role = UserRole.MANAGER


class CashierFactory(UserFactory):
    role = UserRole.CASHIER


class WarehouseStaffFactory(UserFactory):
    role = UserRole.WAREHOUSE_STAFF
