"""
RBAC permission class tests. These are unit-level (constructing requests
directly, not hitting real endpoints) because the thing under test is the
permission logic itself — role-gating behavior that every other app's
views depend on.
"""
import pytest
from rest_framework.test import APIRequestFactory

from apps.core.middleware import get_current_request, get_current_user
from apps.core.permissions import (
    CanApproveDiscount,
    CanOverrideTerminal,
    IsAnyActiveStaff,
    IsCashierOrAbove,
    IsManagerOrOwner,
    IsOwner,
    IsSameBusiness,
)
from apps.core.tests.factories import (
    BusinessFactory,
    CashierFactory,
    ManagerFactory,
    OwnerFactory,
    WarehouseStaffFactory,
)

factory = APIRequestFactory()


def _request_as(user):
    req = factory.get('/')
    req.user = user
    return req


@pytest.mark.django_db
class TestRolePermissions:
    def test_is_owner_allows_only_owner(self, business):
        owner = OwnerFactory(business=business)
        manager = ManagerFactory(business=business)

        assert IsOwner().has_permission(_request_as(owner), None) is True
        assert IsOwner().has_permission(_request_as(manager), None) is False

    def test_is_manager_or_owner_excludes_cashier(self, business):
        manager = ManagerFactory(business=business)
        cashier = CashierFactory(business=business)

        assert IsManagerOrOwner().has_permission(_request_as(manager), None) is True
        assert IsManagerOrOwner().has_permission(_request_as(cashier), None) is False

    def test_is_cashier_or_above_excludes_warehouse_staff(self, business):
        cashier = CashierFactory(business=business)
        warehouse_staff = WarehouseStaffFactory(business=business)

        assert IsCashierOrAbove().has_permission(_request_as(cashier), None) is True
        assert IsCashierOrAbove().has_permission(_request_as(warehouse_staff), None) is False

    def test_is_any_active_staff_covers_all_four_roles(self, business):
        for factory_cls in (OwnerFactory, ManagerFactory, CashierFactory, WarehouseStaffFactory):
            user = factory_cls(business=business)
            assert IsAnyActiveStaff().has_permission(_request_as(user), None) is True

    def test_inactive_user_denied_regardless_of_role(self, business):
        owner = OwnerFactory(business=business, is_active=False)
        assert IsOwner().has_permission(_request_as(owner), None) is False

    def test_deleted_user_denied_regardless_of_role(self, business):
        owner = OwnerFactory(business=business)
        owner.is_deleted = True
        owner.save(update_fields=['is_deleted'])
        assert IsOwner().has_permission(_request_as(owner), None) is False

    def test_anonymous_user_denied(self):
        from django.contrib.auth.models import AnonymousUser
        req = _request_as(AnonymousUser())
        assert IsAnyActiveStaff().has_permission(req, None) is False

    def test_terminal_override_requires_manager_or_owner(self, business):
        manager = ManagerFactory(business=business)
        cashier = CashierFactory(business=business)

        assert CanOverrideTerminal().has_permission(_request_as(manager), None) is True
        assert CanOverrideTerminal().has_permission(_request_as(cashier), None) is False

    def test_discount_approval_requires_manager_or_owner(self, business):
        owner = OwnerFactory(business=business)
        cashier = CashierFactory(business=business)

        assert CanApproveDiscount().has_permission(_request_as(owner), None) is True
        assert CanApproveDiscount().has_permission(_request_as(cashier), None) is False


@pytest.mark.django_db
class TestIsSameBusiness:
    def test_object_without_business_attribute_denied_gracefully(self, business):
        """
        IsSameBusiness expects an object with a `business_id` attribute or a
        `business` FK. Passing something that has neither (like a raw
        Business instance — it has `.id`, not `.business_id`) should deny
        access cleanly rather than raising. Real usage is objects like
        Sale/Product that carry a business_id or business FK.
        """
        owner = OwnerFactory(business=business)
        req = _request_as(owner)
        assert IsSameBusiness().has_object_permission(req, None, business) is False

    def test_denies_object_in_different_business(self, business):
        owner = OwnerFactory(business=business)
        other_business = BusinessFactory()

        class FakeResource:
            business_id = other_business.id

        req = _request_as(owner)
        assert IsSameBusiness().has_object_permission(req, None, FakeResource()) is False

    def test_allows_object_with_matching_business_id(self, business):
        owner = OwnerFactory(business=business)

        class FakeResource:
            business_id = business.id

        req = _request_as(owner)
        assert IsSameBusiness().has_object_permission(req, None, FakeResource()) is True


@pytest.mark.django_db
class TestAuditMiddlewareHelpers:
    def test_get_current_request_returns_none_outside_request_cycle(self):
        # Middleware only sets thread-local state during __call__; outside
        # of a real request/response cycle (i.e. here, in a unit test),
        # nothing has populated it.
        assert get_current_request() is None

    def test_get_current_user_returns_none_without_request(self):
        assert get_current_user() is None
