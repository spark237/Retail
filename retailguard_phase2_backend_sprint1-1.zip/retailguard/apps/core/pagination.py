"""
RetailGuard Core — Pagination

Centralised pagination class used by all list views.
Settings reference: 'DEFAULT_PAGINATION_CLASS': 'apps.core.pagination.StandardPagination'
View import: from apps.core.pagination import StandardPagination
"""
from rest_framework.pagination import PageNumberPagination
from rest_framework.response import Response


class StandardPagination(PageNumberPagination):
    page_size              = 50
    page_size_query_param  = 'per_page'
    max_page_size          = 200

    def get_paginated_response(self, data):
        return Response({
            'success': True,
            'data': data,
            'meta': {
                'page':        self.page.number,
                'per_page':    self.get_page_size(self.request),
                'total':       self.page.paginator.count,
                'total_pages': self.page.paginator.num_pages,
            }
        })
