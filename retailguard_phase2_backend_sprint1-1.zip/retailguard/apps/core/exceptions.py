"""
RetailGuard Core — Custom Exceptions & DRF Exception Handler

All API errors return a consistent envelope:
{
  "success": false,
  "error": {
    "code": "ERROR_CODE",
    "message": "Human-readable description",
    "details": { ... }
  }
}
"""
from rest_framework import status
from rest_framework.exceptions import APIException
from rest_framework.views import exception_handler

# ─── BASE EXCEPTION ──────────────────────────────────────────────────────────

class RetailGuardException(APIException):
    """
    Base for all RetailGuard business logic exceptions.
    Subclass with a specific status_code and default_code.
    """
    status_code = status.HTTP_400_BAD_REQUEST
    default_code = 'RETAILGUARD_ERROR'
    default_detail = 'A business logic error occurred.'

    def __init__(self, detail=None, code=None, extra=None):
        self.extra = extra or {}
        super().__init__(detail=detail, code=code)


# ─── AUTH EXCEPTIONS ─────────────────────────────────────────────────────────

class InvalidCredentialsError(RetailGuardException):
    status_code = status.HTTP_401_UNAUTHORIZED
    default_code = 'INVALID_CREDENTIALS'
    default_detail = 'Invalid phone/email or password.'


class AccountLockedError(RetailGuardException):
    status_code = status.HTTP_401_UNAUTHORIZED
    default_code = 'ACCOUNT_LOCKED'
    default_detail = 'Account locked due to too many failed attempts.'


class TerminalOccupiedError(RetailGuardException):
    """Branch already has an active session. Returned with takeover context."""
    status_code = status.HTTP_409_CONFLICT
    default_code = 'TERMINAL_OCCUPIED'
    default_detail = 'Branch already has an active terminal session.'


class TakeoverDeniedError(RetailGuardException):
    """Cashier attempted terminal.override — not allowed."""
    status_code = status.HTTP_403_FORBIDDEN
    default_code = 'TAKEOVER_DENIED'
    default_detail = 'Terminal override requires manager or owner role.'


# ─── SALE EXCEPTIONS ─────────────────────────────────────────────────────────

class InsufficientStockError(RetailGuardException):
    status_code = status.HTTP_422_UNPROCESSABLE_ENTITY
    default_code = 'INSUFFICIENT_STOCK'
    default_detail = 'Insufficient stock at this branch.'


class ManagerApprovalRequiredError(RetailGuardException):
    """Sale price is below min_selling_price and no valid approval provided."""
    status_code = status.HTTP_402_PAYMENT_REQUIRED
    default_code = 'MANAGER_APPROVAL_REQUIRED'
    default_detail = 'Sale price is below minimum. Manager approval required.'


class InvalidPaymentTotalError(RetailGuardException):
    status_code = status.HTTP_422_UNPROCESSABLE_ENTITY
    default_code = 'INVALID_PAYMENT_TOTAL'
    default_detail = 'Sum of payment amounts does not equal sale total.'


class PaymentUnconfirmedError(RetailGuardException):
    """Non-cash payment not yet confirmed. Sale cannot be marked completed."""
    status_code = status.HTTP_422_UNPROCESSABLE_ENTITY
    default_code = 'PAYMENT_UNCONFIRMED'
    default_detail = 'Non-cash payment must be confirmed before sale can be completed.'


class NoActiveShiftError(RetailGuardException):
    status_code = status.HTTP_422_UNPROCESSABLE_ENTITY
    default_code = 'NO_ACTIVE_SHIFT'
    default_detail = 'No open shift found for this cashier at this branch.'


class DuplicateSaleError(RetailGuardException):
    status_code = status.HTTP_409_CONFLICT
    default_code = 'DUPLICATE_SALE_ID'
    default_detail = 'A sale with this UUID already exists.'


class SaleAlreadyVoidedError(RetailGuardException):
    status_code = status.HTTP_409_CONFLICT
    default_code = 'SALE_ALREADY_VOIDED'
    default_detail = 'This sale has already been voided.'


class ApprovalInvalidError(RetailGuardException):
    status_code = status.HTTP_422_UNPROCESSABLE_ENTITY
    default_code = 'APPROVAL_INVALID'
    default_detail = 'Price override approval is invalid, expired, or already used.'


# ─── SHIFT EXCEPTIONS ────────────────────────────────────────────────────────

class ShiftAlreadyOpenError(RetailGuardException):
    status_code = status.HTTP_409_CONFLICT
    default_code = 'SHIFT_ALREADY_OPEN'
    default_detail = 'This branch already has an active shift.'


class ShiftAlreadyClosedError(RetailGuardException):
    status_code = status.HTTP_409_CONFLICT
    default_code = 'SHIFT_ALREADY_CLOSED'
    default_detail = 'This shift is already closed.'


# ─── INVENTORY EXCEPTIONS ────────────────────────────────────────────────────

class NegativeStockPreventedError(RetailGuardException):
    status_code = status.HTTP_422_UNPROCESSABLE_ENTITY
    default_code = 'NEGATIVE_STOCK_PREVENTED'
    default_detail = 'This operation would result in negative stock, which is not allowed.'


class ConversionFactorMissingError(RetailGuardException):
    status_code = status.HTTP_422_UNPROCESSABLE_ENTITY
    default_code = 'CONVERSION_FACTOR_MISSING'
    default_detail = 'Product does not have the required unit conversion factor.'


# ─── TRANSFER EXCEPTIONS ─────────────────────────────────────────────────────

class InvalidStatusTransitionError(RetailGuardException):
    status_code = status.HTTP_422_UNPROCESSABLE_ENTITY
    default_code = 'INVALID_STATUS_TRANSITION'
    default_detail = 'This status transition is not allowed at the current state.'


class InsufficientStockForTransferError(RetailGuardException):
    status_code = status.HTTP_422_UNPROCESSABLE_ENTITY
    default_code = 'INSUFFICIENT_STOCK_FOR_TRANSFER'
    default_detail = 'Source location does not have sufficient stock for this transfer.'


# ─── DRF EXCEPTION HANDLER ───────────────────────────────────────────────────

def retailguard_exception_handler(exc, context):
    """
    Custom DRF exception handler.
    Wraps all errors in the standard RetailGuard envelope:
      { "success": false, "error": { "code": ..., "message": ..., "details": ... } }
    """
    response = exception_handler(exc, context)

    if response is not None:
        error_payload = {
            'success': False,
            'error': {
                'code': _get_error_code(exc),
                'message': _get_error_message(response.data),
                'details': getattr(exc, 'extra', {}),
            }
        }
        response.data = error_payload

    return response


def _get_error_code(exc):
    if hasattr(exc, 'default_code') and isinstance(exc.default_code, str):
        return exc.default_code
    if hasattr(exc, 'detail') and hasattr(exc.detail, 'code'):
        return str(exc.detail.code).upper()
    return 'ERROR'


def _get_error_message(data):
    if isinstance(data, dict):
        # DRF validation errors — flatten first field's first error
        for _key, value in data.items():
            if isinstance(value, list) and value:
                return str(value[0])
            if isinstance(value, str):
                return value
    if isinstance(data, list) and data:
        return str(data[0])
    return str(data)
