# RetailGuard Backend

Django 6.0 / DRF backend for offline-first retail fraud detection and POS.
13 business domain apps + `core` (shared infra) — see `SCHEMA_V4_FINAL.md`
for the full DB design.

## Setup (target: under 30 minutes)

**Requirements:** Python 3.12, PostgreSQL 16, Redis (for cache/Celery).

```bash
git clone <repo-url>
cd retailguard
python3 -m venv venv
source venv/bin/activate
pip install -r requirements/development.txt

cp .env.example .env
# edit .env — at minimum set SECRET_KEY and DB_PASSWORD to match your local Postgres

# create the database and user matching your .env, e.g.:
#   createuser retailguard_user --createdb
#   createdb retailguard -O retailguard_user

python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

## Scripts

| Command | What it does |
|---|---|
| `python manage.py runserver` | Dev server |
| `python manage.py check` | Django system check |
| `python manage.py makemigrations --check --dry-run` | Detect model/migration drift |
| `pytest` | Run tests with coverage (config in `pytest.ini` / `.coveragerc`) |
| `ruff check .` | Lint |
| `ruff check . --fix` | Auto-fix safe categories (import sorting, unused imports) |

## Architecture notes that aren't obvious from the file layout

- **`branches` and `users` have a genuine circular model dependency**
  (`Branch.manager`/`deleted_by` → `users`, `User.business` → `branches`).
  `branches/migrations/0001_initial.py` creates the tables without the
  user-referencing fields; `branches/migrations/0002_add_user_relations.py`
  adds them back once `users` exists. If you add new FKs between these two
  apps, watch for this — Django can't resolve two apps' initial migrations
  pointing at each other in one shot.
- **`shifts/migrations/0002_one_active_terminal_per_branch.py` is raw SQL**,
  not the Django ORM — it creates a partial unique index
  (`WHERE status = 'open'`) enforcing one active POS terminal per branch at
  the database level. This is deliberate: no application-level bug can
  create two active terminals for the same branch, because the DB itself
  rejects it.
- **`inventory_stock` is a denormalized snapshot**, derived from summing
  `inventory_movements`. Never update it directly outside a movement
  transaction — see the atomic transaction spec in `SCHEMA_V4_FINAL.md`.
- **All money is `IntegerField` (XAF, no subunits). All quantities are
  `DecimalField` with 3 decimal places** (tiles are sold by SQM, which
  needs fractional precision — see the schema doc's math proof for why
  2 decimal places caused phantom shrinkage).

## Testing

No tests exist yet — this is the known, tracked gap the whole Sprint 1/2
plan exists to close (see `ENGINEERING_STANDARDS.md` for the risk-ordered
backend testing priority: sales → inventory → fraud → payments → shifts →
auth → transfers → reconciliation → expenses → audit → analytics →
products → users).

`pytest.ini` runs with migrations **on** (not `--nomigrations`) deliberately
— real migration bugs were found and fixed during Sprint 0 (see below), so
running the actual migration chain against the test DB is a correctness
check in itself, not just setup overhead.

## Known gaps (tracked, not blocking)

- `DJ001` (nullable string fields) and `B904` (raise-without-from) lint
  findings are informational-only in CI for now — real findings, not
  blocking merges until a deliberate cleanup pass (same treatment as the
  frontend's pre-existing lint warnings).
- `AuditLog.session` (FK to `UserSession`) is never populated by
  `AuditService.log()` — every audit log currently has `session=NULL`
  regardless of context. Found during Sprint 0 lint cleanup; needs a real
  fix (extracting the session from the auth token), not a quick patch.
- No coverage threshold enforced yet for backend — Sprint 1 target is 50%,
  rising to 80%/90% by Sprint 3 (critical modules: sales, inventory,
  payments, fraud). See the Phase 4 Baseline Plan.

## CI

See `.github/workflows/backend-ci.yml`. Runs against real Postgres 16 +
Redis service containers. Required check for merging to `main`:
`Backend CI / build-and-test` — see `docs/BRANCH_PROTECTION.md`.
