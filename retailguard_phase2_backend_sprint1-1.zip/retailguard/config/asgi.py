"""
RetailGuard ASGI Configuration
Reserved for future WebSocket support (real-time dashboard, live alerts).
Currently unused — all traffic routes through WSGI.
"""
import os

from django.core.asgi import get_asgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings.production')
application = get_asgi_application()
