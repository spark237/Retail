from django.conf import settings
from django.contrib import admin
from django.urls import include, path

API_PREFIX = 'api/v1/'

urlpatterns = [
    path('admin/', admin.site.urls),
    path(API_PREFIX + 'auth/',          include('apps.authentication.urls')),
    path(API_PREFIX + 'users/',         include('apps.users.urls')),
    path(API_PREFIX + 'branches/',      include('apps.branches.urls')),
    path(API_PREFIX + 'products/',      include('apps.products.urls')),
    path(API_PREFIX + 'inventory/',     include('apps.inventory.urls')),
    path(API_PREFIX + 'shifts/',        include('apps.shifts.urls')),
    path(API_PREFIX + 'sales/',         include('apps.sales.urls')),
    path(API_PREFIX + 'reconciliation/',include('apps.reconciliation.urls')),
    path(API_PREFIX + 'transfers/',     include('apps.transfers.urls')),
    path(API_PREFIX + 'expenses/',      include('apps.expenses.urls')),
    path(API_PREFIX + 'alerts/',        include('apps.fraud.urls')),
    path(API_PREFIX + 'audit-logs/',    include('apps.audit.urls')),
    path(API_PREFIX + 'analytics/',     include('apps.analytics.urls')),
]

if settings.DEBUG:
    import debug_toolbar
    urlpatterns += [path('__debug__/', include(debug_toolbar.urls))]
