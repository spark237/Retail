# Branch Protection — `main`

GitHub branch protection is configured in repo Settings → Branches, not in a
committed file. This doc is the source of truth for what that setting should
be, so it survives even if someone reconfigures the repo.

## Required settings for `main`

- **Require a pull request before merging** — no direct pushes to `main`.
- **Require status checks to pass before merging**, specifically:
  - `Backend CI / build-and-test`
- **Require branches to be up to date before merging.**
- **Require at least 1 approval** (adjust once team size is known).
- **Do not allow bypassing the above settings**, including for admins.

## Why this matters here specifically

Per the Phase 4 Baseline Plan's CI Quality Gates: green CI is a merge
prerequisite, not a status indicator. Branch protection is the mechanism that
actually enforces that. This is especially important for this repo given
Sprint 0 found and fixed real migration bugs (a circular dependency between
`branches` and `users`, 13 of 14 apps missing migrations entirely) — the
whole point of `makemigrations --check --dry-run` running in CI is to catch
drift like that before it lands on `main` again.

Same policy as the frontend repo (`retailguard-pwa/docs/BRANCH_PROTECTION.md`).
