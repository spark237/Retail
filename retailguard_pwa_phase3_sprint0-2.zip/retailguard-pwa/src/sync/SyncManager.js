/**
 * RetailGuard — Background Sync Manager
 * STANDALONE MODULE — not inside React.
 */
import { syncQueueDB, SyncStatus, EntityType } from '../db/syncQueue'
import { inventoryDB } from '../db/inventory'
import { salesDB } from '../db/sales'
import { apiClient } from '../api/client'
import { getDB } from '../db/schema'

class SyncEventBus extends EventTarget {
  emit(type, detail) {
    this.dispatchEvent(new CustomEvent(type, { detail }))
  }
}

export const syncEvents = new SyncEventBus()

export const SyncEvent = {
  STARTED:         'sync:started',
  COMPLETED:       'sync:completed',
  ITEM_SUCCESS:    'sync:item:success',
  ITEM_CONFLICT:   'sync:item:conflict',
  ITEM_FAILED:     'sync:item:failed',
  QUEUE_EMPTY:     'sync:queue:empty',
  CONNECTIVITY:    'sync:connectivity',
}

function backoffDelay(retryCount) {
  return Math.min(2000 * Math.pow(2, retryCount), 32000)
}

const syncHandlers = {
  async [EntityType.SALE](entry) {
    const { payload } = entry
    let response

    try {
      response = await apiClient.post('/sales/', payload)
    } catch (err) {
      if (err.response?.status === 409) {
        const data = err.response.data
        if (data?.data?.id) {
          await salesDB.updateSyncStatus(payload.id, 'synced', data.data.receipt_number)
          return { status: 'completed', duplicate: true }
        }
      }
      throw err
    }

    const synced = response.data.data
    await salesDB.updateSyncStatus(payload.id, 'synced', synced.receipt_number)

    syncEvents.emit(SyncEvent.ITEM_SUCCESS, {
      entityType:    EntityType.SALE,
      entityId:      payload.id,
      receiptNumber: synced.receipt_number,
    })

    return { status: 'completed', receiptNumber: synced.receipt_number }
  },

  async [EntityType.DAMAGE_REPORT](entry) {
    const response = await apiClient.post('/inventory/damage-reports/', entry.payload)
    syncEvents.emit(SyncEvent.ITEM_SUCCESS, {
      entityType: EntityType.DAMAGE_REPORT,
      entityId:   entry.entity_id,
    })
    return { status: 'completed', data: response.data.data }
  },

  async [EntityType.SHIFT_CLOSE](entry) {
    const { shiftId, payload } = entry.payload
    const response = await apiClient.post(`/shifts/${shiftId}/close/`, payload)
    syncEvents.emit(SyncEvent.ITEM_SUCCESS, {
      entityType: EntityType.SHIFT_CLOSE,
      entityId:   shiftId,
    })
    return { status: 'completed', data: response.data.data }
  },

  async [EntityType.ATTENDANCE](entry) {
    await apiClient.post('/shifts/attendance/check-in/', entry.payload)
    return { status: 'completed' }
  },
}

class BackgroundSyncManager {
  constructor() {
    this._isOnline      = navigator.onLine
    this._isSyncing     = false
    this._syncInterval  = null
    this._initialized   = false
  }

  init() {
    if (this._initialized) return
    this._initialized = true

    window.addEventListener('online',  () => this._onOnline())
    window.addEventListener('offline', () => this._onOffline())

    this._syncInterval = setInterval(() => {
      if (this._isOnline && !this._isSyncing) {
        this.flush()
      }
    }, 30_000)

    console.log('[SyncManager] Initialized. Online:', this._isOnline)
  }

  destroy() {
    window.removeEventListener('online',  this._onOnline)
    window.removeEventListener('offline', this._onOffline)
    clearInterval(this._syncInterval)
    this._initialized = false
  }

  get isOnline()  { return this._isOnline  }
  get isSyncing() { return this._isSyncing }

  async _onOnline() {
    this._isOnline = true
    syncEvents.emit(SyncEvent.CONNECTIVITY, { online: true })
    console.log('[SyncManager] Online — flushing queue')

    await syncQueueDB.requeueFailed()
    await this._refreshInventory()
    await this.flush()
  }

  _onOffline() {
    this._isOnline = false
    syncEvents.emit(SyncEvent.CONNECTIVITY, { online: false })
    console.log('[SyncManager] Offline — queuing enabled')
  }

  async _refreshInventory() {
    try {
      const session = await this._getSession()
      if (!session?.primary_branch_id) return

      const response = await apiClient.get('/inventory/', {
        params: { branch_id: session.primary_branch_id, per_page: 500 },
      })

      const items = response.data.data || []
      if (items.length > 0) {
        await inventoryDB.bulkPut(items)
        console.log(`[SyncManager] Inventory refreshed: ${items.length} items`)
      }
    } catch (err) {
      console.warn('[SyncManager] Inventory refresh failed:', err.message)
    }
  }

  async _getSession() {
    const db = await getDB()
    return db.get('auth', 'session')
  }

  async flush() {
    if (this._isSyncing || !this._isOnline) return
    this._isSyncing = true
    syncEvents.emit(SyncEvent.STARTED)

    try {
      const queued = await syncQueueDB.getQueued()
      if (queued.length === 0) {
        syncEvents.emit(SyncEvent.QUEUE_EMPTY)
        return
      }

      console.log(`[SyncManager] Processing ${queued.length} queued items`)

      for (const entry of queued) {
        await this._processEntry(entry)
        await new Promise(r => setTimeout(r, 100))
      }

      syncEvents.emit(SyncEvent.COMPLETED, { processed: queued.length })
    } finally {
      this._isSyncing = false
    }
  }

  async _processEntry(entry) {
    const handler = syncHandlers[entry.entity_type]

    if (!handler) {
      console.error(`[SyncManager] No handler for entity_type: ${entry.entity_type}`)
      await syncQueueDB.markFailed(entry.id, `No handler for ${entry.entity_type}`)
      return
    }

    await syncQueueDB.markProcessing(entry.id)

    try {
      const result = await handler(entry)

      if (result.status === 'conflict') {
        await syncQueueDB.markConflict(entry.id, result.detail)
        syncEvents.emit(SyncEvent.ITEM_CONFLICT, {
          entityType: entry.entity_type,
          entityId:   entry.entity_id,
          detail:     result.detail,
        })
      } else {
        await syncQueueDB.markCompleted(entry.id)
      }
    } catch (err) {
      const message = err.response?.data?.error?.message || err.message

      if (err.response?.status === 422) {
        const code = err.response?.data?.error?.code
        if (code === 'INSUFFICIENT_STOCK') {
          await syncQueueDB.markConflict(entry.id, { code, ...err.response.data.error.details })
          await salesDB.updateSyncStatus(entry.entity_id, 'conflict')
          syncEvents.emit(SyncEvent.ITEM_CONFLICT, {
            entityType: entry.entity_type,
            entityId:   entry.entity_id,
            detail:     err.response.data.error,
          })
          return
        }
      }

      console.warn(`[SyncManager] Entry ${entry.id} failed (retry ${entry.retry_count}):`, message)
      await syncQueueDB.markFailed(entry.id, message)
      syncEvents.emit(SyncEvent.ITEM_FAILED, {
        entityType:  entry.entity_type,
        entityId:    entry.entity_id,
        error:       message,
        retryCount:  entry.retry_count + 1,
        willRetry:   (entry.retry_count + 1) < 5,
      })

      if (entry.retry_count < 5) {
        await new Promise(r => setTimeout(r, backoffDelay(entry.retry_count)))
      }
    }
  }
}

export const SyncManager = new BackgroundSyncManager()
