/**
 * RetailGuard — Shift Close Screen
 *
 * Enforces the reporting rule: unsynced sales are shown separately
 * from confirmed sales. Reconciliation labeled PRELIMINARY when
 * pending sales exist — never silently merged into confirmed totals.
 */
import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { AppShell } from '../../components/Layout'
import { Button, Input, Alert, Badge, Card } from '../../components/ui'
import { useShiftStore } from '../../store/shiftStore'
import { useShiftSales, useSync } from '../../hooks/index'
import { formatXAFShort } from '../../utils/currency'

export default function ShiftCloseScreen() {
  const navigate    = useNavigate()
  const shift        = useShiftStore(s => s.shift)
  const closeShift    = useShiftStore(s => s.closeShift)
  const isLoading      = useShiftStore(s => s.isLoading)
  const error          = useShiftStore(s => s.error)
  const clearShift     = useShiftStore(s => s.clearShift)

  const { summary } = useShiftSales(shift?.id)
  const { pendingCount, isOnline } = useSync()

  const [actualCash, setActualCash] = useState('')
  const [notes, setNotes]           = useState('')
  const [confirmClose, setConfirmClose] = useState(false)
  const [result, setResult]         = useState(null)

  const hasPending = summary?.pending > 0

  async function handleClose() {
    const cash = parseInt(actualCash) || 0
    const res  = await closeShift(cash, notes)
    if (res.success) {
      setResult(res.data)
    }
  }

  async function handleDone() {
    await clearShift()
    navigate('/login')
  }

  if (!shift) {
    navigate('/pos')
    return null
  }

  if (result) {
    const recon = result.reconciliation
    return (
      <AppShell title='Shift Closed' hideNav>
        <div className='px-4 py-6'>
          <div className='text-center mb-6'>
            <div className='text-5xl mb-2'>✅</div>
            <h2 className='text-xl font-bold text-slate-100'>
              {result.status === 'closed_pending' ? 'Shift Closed — Pending Sync' : 'Shift Closed'}
            </h2>
          </div>

          {recon.is_preliminary && (
            <Alert variant='warning' title='⚠️ PRELIMINARY — Unsynced Sales Pending' className='mb-4'>
              These figures include estimates from {result.unsynced_sales} unsynced sale(s).
              Final reconciliation will be available once sync completes.
            </Alert>
          )}

          <Card className='mb-3'>
            <p className='text-xs text-slate-500 mb-1'>
              {recon.is_preliminary ? 'CONFIRMED (Synced)' : 'FINAL'}
            </p>
            <div className='flex justify-between mb-2'>
              <span className='text-slate-400 text-sm'>Opening Cash</span>
              <span className='text-slate-100'>{formatXAFShort(recon.opening_cash)}</span>
            </div>
            <div className='flex justify-between mb-2'>
              <span className='text-slate-400 text-sm'>Confirmed Cash Sales</span>
              <span className='text-slate-100'>{formatXAFShort(recon.confirmed_cash_sales)}</span>
            </div>
            <div className='flex justify-between mb-2'>
              <span className='text-slate-400 text-sm'>Expected Cash</span>
              <span className='text-slate-100'>{formatXAFShort(recon.expected_cash_confirmed)}</span>
            </div>
            <div className='flex justify-between mb-2'>
              <span className='text-slate-400 text-sm'>Actual Cash</span>
              <span className='text-slate-100'>{formatXAFShort(recon.actual_cash)}</span>
            </div>
            <div className='flex justify-between pt-2 border-t border-slate-800'>
              <span className='text-slate-300 font-medium'>Difference</span>
              <span className={`font-bold ${recon.difference_confirmed < 0 ? 'text-red-400' : 'text-emerald-400'}`}>
                {formatXAFShort(recon.difference_confirmed)}
              </span>
            </div>
          </Card>

          {recon.is_preliminary && (
            <Card className='mb-4 border-orange-800'>
              <p className='text-xs text-orange-400 mb-2'>PENDING (Unsynced) ⚠️</p>
              <p className='text-sm text-slate-400'>
                {result.unsynced_sales} sale(s) not yet confirmed. These will sync automatically when online.
              </p>
            </Card>
          )}

          <Button size='lg' fullWidth onClick={handleDone}>
            Done
          </Button>
        </div>
      </AppShell>
    )
  }

  return (
    <AppShell title='Close Shift' showBack onBack={() => navigate('/pos')}>
      <div className='px-4 py-4'>
        {error && <Alert variant='danger' className='mb-4'>{error.message}</Alert>}

        {!isOnline && (
          <Alert variant='warning' className='mb-4'>
            You're offline. Sales will sync when connection returns. Shift will close as "Pending Sync".
          </Alert>
        )}

        <Card className='mb-4'>
          <div className='flex justify-between mb-2'>
            <span className='text-slate-400 text-sm'>Total Sales</span>
            <span className='text-slate-100'>{summary?.total || 0}</span>
          </div>
          <div className='flex justify-between mb-2'>
            <span className='text-slate-400 text-sm'>Synced</span>
            <Badge variant='synced'>{summary?.synced || 0}</Badge>
          </div>
          {hasPending && (
            <div className='flex justify-between mb-2'>
              <span className='text-slate-400 text-sm'>Pending Sync</span>
              <Badge variant='pending'>{summary?.pending || 0}</Badge>
            </div>
          )}
          <div className='flex justify-between pt-2 border-t border-slate-800'>
            <span className='text-slate-300 font-medium'>Cash Expected</span>
            <span className='font-bold text-slate-100'>{formatXAFShort(summary?.cashTotal || 0)}</span>
          </div>
        </Card>

        <Input
          label='Actual Cash Count (XAF)'
          value={actualCash}
          onChange={setActualCash}
          inputMode='numeric'
          suffix='XAF'
          className='mb-4'
        />

        <Input
          label='Notes (optional)'
          value={notes}
          onChange={setNotes}
          placeholder='Any comments about this shift...'
          className='mb-6'
        />

        <Button
          size='lg'
          fullWidth
          loading={isLoading}
          disabled={!actualCash}
          onClick={handleClose}
          variant={hasPending ? 'warning' : 'primary'}
        >
          {hasPending ? 'Close Shift (Preliminary)' : 'Close Shift'}
        </Button>
      </div>
    </AppShell>
  )
}
