/**
 * RetailGuard — Inventory Screen
 * Read-only stock view from IndexedDB. Low stock highlighted.
 */
import { useState, useMemo } from 'react'
import { AppShell } from '../../components/Layout'
import { Input, Badge, Card, EmptyState } from '../../components/ui'
import { useInventory } from '../../hooks/index'
import { useShiftStore } from '../../store/shiftStore'
import { unitLabel } from '../../utils/units'

export default function InventoryScreen() {
  const shift = useShiftStore(s => s.shift)
  const { stock, isLoading } = useInventory(shift?.branch_id)
  const [search, setSearch] = useState('')
  const [showLowOnly, setShowLowOnly] = useState(false)

  const filtered = useMemo(() => {
    let items = stock
    if (search.trim()) {
      const q = search.toLowerCase()
      items = items.filter(i =>
        i.product_name?.toLowerCase().includes(q) ||
        i.product_sku?.toLowerCase().includes(q)
      )
    }
    if (showLowOnly) {
      items = items.filter(i => parseFloat(i.quantity) <= parseFloat(i.reorder_level || 0))
    }
    return items
  }, [stock, search, showLowOnly])

  return (
    <AppShell title='Stock'>
      <div className='px-4 pt-4 pb-2 flex flex-col gap-3'>
        <Input value={search} onChange={setSearch} placeholder='Search products…' prefix='🔍' />
        <button
          onClick={() => setShowLowOnly(!showLowOnly)}
          className={`self-start px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${
            showLowOnly ? 'bg-amber-600 text-white' : 'bg-slate-800 text-slate-400 border border-slate-700'
          }`}
        >
          ⚠ Low Stock Only
        </button>
      </div>

      {filtered.length === 0 ? (
        <EmptyState icon='📦' title='No items found' />
      ) : (
        <div className='px-4 flex flex-col gap-2 pb-4'>
          {filtered.map(item => {
            const qty   = parseFloat(item.quantity)
            const level = parseFloat(item.reorder_level || 0)
            const isLow = qty <= level
            const isOut = qty <= 0

            return (
              <Card key={item.id} className='flex items-center justify-between'>
                <div className='min-w-0 flex-1'>
                  <p className='font-medium text-slate-100 truncate'>{item.product_name}</p>
                  <p className='text-xs text-slate-500'>{item.product_sku}</p>
                </div>
                <div className='text-right shrink-0 ml-3'>
                  <p className='font-bold text-slate-100'>
                    {qty} <span className='text-xs font-normal text-slate-500'>{item.stock_unit}</span>
                  </p>
                  {isOut ? (
                    <Badge variant='danger'>Out of stock</Badge>
                  ) : isLow ? (
                    <Badge variant='warning'>Low stock</Badge>
                  ) : null}
                </div>
              </Card>
            )
          })}
        </div>
      )}
    </AppShell>
  )
}
