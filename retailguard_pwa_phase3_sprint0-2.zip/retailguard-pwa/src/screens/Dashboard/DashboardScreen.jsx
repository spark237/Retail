/**
 * RetailGuard — Dashboard Screen
 * Server data via React Query (5min stale time — reports don't need to be live).
 * Never shows pending/unsynced figures merged with confirmed — matches API contract.
 */
import { useState } from 'react'
import { AppShell } from '../../components/Layout'
import { Card, Badge, Spinner, EmptyState } from '../../components/ui'
import { useDailyAnalytics } from '../../hooks/index'
import { useAuthStore } from '../../store/authStore'
import { useShiftStore } from '../../store/shiftStore'
import { formatXAFShort } from '../../utils/currency'

export default function DashboardScreen() {
  const user  = useAuthStore(s => s.user)
  const shift = useShiftStore(s => s.shift)
  const branchId = shift?.branch_id || user?.primary_branch_id
  const today = new Date().toISOString().split('T')[0]

  const { data, isLoading, error } = useDailyAnalytics(branchId, today)

  if (!branchId) {
    return (
      <AppShell title='Dashboard'>
        <EmptyState icon='📊' title='No branch selected' />
      </AppShell>
    )
  }

  if (isLoading) {
    return (
      <AppShell title='Dashboard'>
        <div className='flex justify-center py-16'><Spinner size='lg' /></div>
      </AppShell>
    )
  }

  if (error || !data) {
    return (
      <AppShell title='Dashboard'>
        <EmptyState icon='⚠️' title='Unable to load dashboard' message='Check your connection and try again.' />
      </AppShell>
    )
  }

  return (
    <AppShell title='Dashboard'>
      <div className='px-4 py-4 flex flex-col gap-4'>
        {/* Revenue card */}
        <Card>
          <p className='text-xs text-slate-500 mb-1'>TODAY'S REVENUE</p>
          <p className='text-3xl font-bold text-slate-100 mb-3'>{formatXAFShort(data.revenue?.total)}</p>
          <div className='grid grid-cols-2 gap-2 text-sm'>
            <div className='flex justify-between'>
              <span className='text-slate-400'>Cash</span>
              <span className='text-slate-200'>{formatXAFShort(data.revenue?.by_method?.CASH)}</span>
            </div>
            <div className='flex justify-between'>
              <span className='text-slate-400'>MTN MoMo</span>
              <span className='text-slate-200'>{formatXAFShort(data.revenue?.by_method?.MTN_MOMO)}</span>
            </div>
            <div className='flex justify-between'>
              <span className='text-slate-400'>Orange Money</span>
              <span className='text-slate-200'>{formatXAFShort(data.revenue?.by_method?.ORANGE_MONEY)}</span>
            </div>
            <div className='flex justify-between'>
              <span className='text-slate-400'>Transfer</span>
              <span className='text-slate-200'>{formatXAFShort(data.revenue?.by_method?.BANK_TRANSFER)}</span>
            </div>
          </div>
        </Card>

        {/* Transactions */}
        <Card>
          <p className='text-xs text-slate-500 mb-2'>TRANSACTIONS</p>
          <div className='flex justify-between mb-1'>
            <span className='text-slate-400 text-sm'>Completed</span>
            <span className='text-slate-100 font-semibold'>{data.transactions?.completed || 0}</span>
          </div>
          <div className='flex justify-between mb-1'>
            <span className='text-slate-400 text-sm'>Voided</span>
            <span className='text-slate-100 font-semibold'>{data.transactions?.voided || 0}</span>
          </div>
          <div className='flex justify-between'>
            <span className='text-slate-400 text-sm'>Price Overrides</span>
            <span className='text-slate-100 font-semibold'>{data.transactions?.price_overrides || 0}</span>
          </div>
        </Card>

        {/* Reconciliation */}
        {data.reconciliation && (
          <Card className={data.reconciliation.is_preliminary ? 'border-orange-800' : ''}>
            <div className='flex items-center justify-between mb-2'>
              <p className='text-xs text-slate-500'>CASH RECONCILIATION</p>
              {data.reconciliation.is_preliminary && <Badge variant='pending'>Preliminary</Badge>}
            </div>
            <div className='flex justify-between'>
              <span className='text-slate-400 text-sm'>Difference</span>
              <span className={`font-bold ${data.reconciliation.difference < 0 ? 'text-red-400' : 'text-emerald-400'}`}>
                {formatXAFShort(data.reconciliation.difference)}
              </span>
            </div>
          </Card>
        )}

        {/* Fraud alerts */}
        <Card>
          <div className='flex items-center justify-between mb-2'>
            <p className='text-xs text-slate-500'>FRAUD ALERTS</p>
            <Badge variant={data.fraud_alerts?.open > 0 ? 'danger' : 'default'}>
              {data.fraud_alerts?.open || 0} open
            </Badge>
          </div>
          <div className='flex gap-2 flex-wrap'>
            {data.fraud_alerts?.by_level?.critical > 0 && (
              <Badge variant='critical'>{data.fraud_alerts.by_level.critical} Critical</Badge>
            )}
            {data.fraud_alerts?.by_level?.high > 0 && (
              <Badge variant='danger'>{data.fraud_alerts.by_level.high} High</Badge>
            )}
            {data.fraud_alerts?.by_level?.medium > 0 && (
              <Badge variant='warning'>{data.fraud_alerts.by_level.medium} Medium</Badge>
            )}
          </div>
        </Card>

        {/* Low stock */}
        {data.low_stock_items?.length > 0 && (
          <Card>
            <p className='text-xs text-slate-500 mb-2'>LOW STOCK</p>
            {data.low_stock_items.slice(0, 5).map(item => (
              <div key={item.product_id} className='flex justify-between py-1 text-sm'>
                <span className='text-slate-300 truncate'>{item.product_name}</span>
                <span className='text-amber-400 font-medium'>{item.quantity} {item.unit}</span>
              </div>
            ))}
          </Card>
        )}

        {/* Top products */}
        {data.top_products?.length > 0 && (
          <Card>
            <p className='text-xs text-slate-500 mb-2'>TOP PRODUCTS</p>
            {data.top_products.map((p, idx) => (
              <div key={p.product_id} className='flex justify-between py-1 text-sm'>
                <span className='text-slate-300 truncate'>{idx + 1}. {p.product_name}</span>
                <span className='text-slate-100 font-medium'>{formatXAFShort(p.revenue)}</span>
              </div>
            ))}
          </Card>
        )}
      </div>
    </AppShell>
  )
}
