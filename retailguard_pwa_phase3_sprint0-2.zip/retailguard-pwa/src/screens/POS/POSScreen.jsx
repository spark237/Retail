/**
 * RetailGuard — POS Screen
 * The primary cashier interface. Offline-first: everything reads/writes IndexedDB.
 */
import { useState, useEffect, useMemo } from 'react'
import { useNavigate } from 'react-router-dom'
import { AppShell } from '../../components/Layout'
import { Input, Badge, Button } from '../../components/ui'
import { ProductGrid } from '../../components/POS/ProductGrid'
import { QuantityPickerModal } from '../../components/POS/QuantityPickerModal'
import { CartBar } from '../../components/POS/CartBar'
import { useProductSearch, useInventory } from '../../hooks/index'
import { useCartStore } from '../../store/cartStore'
import { useShiftStore } from '../../store/shiftStore'
import { formatXAFShort } from '../../utils/currency'
import { productsDB } from '../../db/products'

export default function POSScreen() {
  const navigate = useNavigate()
  const shift    = useShiftStore(s => s.shift)
  const { query, setQuery, results } = useProductSearch('')
  const { stock } = useInventory(shift?.branch_id)
  const cartHydrate = useCartStore(s => s.hydrate)
  const items       = useCartStore(s => s.items)
  const addItem     = useCartStore(s => s.addItem)

  const [selectedProduct, setSelectedProduct] = useState(null)
  const [allProducts, setAllProducts] = useState([])

  // Hydrate cart from IndexedDB on mount (crash recovery)
  useEffect(() => { cartHydrate() }, [cartHydrate])

  // Load full product list when no search query
  useEffect(() => {
    if (!query.trim()) {
      productsDB.getAll().then(setAllProducts)
    }
  }, [query])

  const displayProducts = query.trim() ? results : allProducts

  const stockMap = useMemo(() => {
    const map = {}
    stock.forEach(s => { map[s.product_id] = s })
    return map
  }, [stock])

  const cartTotal = items.reduce((s, i) => s + i.total_price, 0)

  function handleProductSelect(product) {
    setSelectedProduct(product)
  }

  function handleConfirmQuantity(product, qty, unit) {
    addItem(product, qty, unit)
  }

  if (!shift) {
    navigate('/shift/open')
    return null
  }

  return (
    <AppShell title='Point of Sale'>
      <div className='px-4 pt-4 pb-2'>
        <Input
          value={query}
          onChange={setQuery}
          placeholder='Search tiles, SKU, barcode…'
          prefix='🔍'
        />
      </div>

      <ProductGrid
        products={displayProducts}
        onSelect={handleProductSelect}
        stockMap={stockMap}
      />

      <QuantityPickerModal
        product={selectedProduct}
        isOpen={!!selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onConfirm={handleConfirmQuantity}
        availableStock={selectedProduct ? stockMap[selectedProduct.id]?.quantity : undefined}
      />

      <CartBar
        itemCount={items.length}
        total={cartTotal}
        onOpen={() => navigate('/pos/cart')}
      />
    </AppShell>
  )
}
