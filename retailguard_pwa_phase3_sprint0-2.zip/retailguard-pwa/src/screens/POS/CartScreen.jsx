/**
 * RetailGuard — Cart / Checkout Screen
 * Full-page cart view. Checkout triggers optimistic sale commit.
 */
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { AppShell } from '../../components/Layout'
import { Button, Alert, EmptyState } from '../../components/ui'
import { CartItemRow } from '../../components/POS/CartBar'
import { PaymentSelector } from '../../components/POS/PaymentSelector'
import { useCartStore } from '../../store/cartStore'
import { useShiftStore } from '../../store/shiftStore'
import { useAuthStore } from '../../store/authStore'
import { formatXAFShort, validatePayments } from '../../utils/currency'

export default function CartScreen() {
  const navigate = useNavigate()
  const shift    = useShiftStore(s => s.shift)
  const user     = useAuthStore(s => s.user)

  const items          = useCartStore(s => s.items)
  const payments       = useCartStore(s => s.payments)
  const setPayments     = useCartStore(s => s.setPayments)
  const removeItem     = useCartStore(s => s.removeItem)
  const commitSale     = useCartStore(s => s.commitSale)
  const isCommitting   = useCartStore(s => s.isCommitting)
  const error          = useCartStore(s => s.error)
  const clearError     = useCartStore(s => s.clearError)

  const [showPayment, setShowPayment] = useState(false)

  const subtotal = items.reduce((s, i) => s + i.total_price, 0)
  const total    = subtotal  // discount handling omitted for MVP simplicity here

  const paymentsValid = validatePayments(payments, total)

  async function handleCheckout() {
    clearError()
    const result = await commitSale({
      shiftId:  shift.id,
      branchId: shift.branch_id,
      cashier:  user,
    })

    if (result.success) {
      navigate('/pos/receipt', { state: { receipt: result.receipt } })
    }
    // On failure: error is shown via store.error, INSUFFICIENT_STOCK shows details
  }

  if (items.length === 0) {
    return (
      <AppShell title='Cart' showBack onBack={() => navigate('/pos')}>
        <EmptyState
          icon='🛒'
          title='Cart is empty'
          message='Add products from the POS screen'
          action={<Button onClick={() => navigate('/pos')}>Browse Products</Button>}
        />
      </AppShell>
    )
  }

  return (
    <AppShell title={`Cart (${items.length})`} showBack onBack={() => navigate('/pos')}>
      <div className='px-4 pt-2'>
        {error && (
          <Alert variant='danger' className='mb-4'>
            {typeof error === 'string' && error.includes('INSUFFICIENT_STOCK')
              ? 'Not enough stock for this sale.'
              : error}
          </Alert>
        )}

        <div className='bg-slate-900 rounded-2xl border border-slate-800 px-4 mb-4'>
          {items.map(item => (
            <CartItemRow key={item.id} item={item} onRemove={removeItem} />
          ))}
        </div>

        <div className='bg-slate-900 rounded-2xl border border-slate-800 p-4 mb-4 flex items-center justify-between'>
          <span className='text-slate-400'>Subtotal</span>
          <span className='text-2xl font-bold text-slate-100'>{formatXAFShort(subtotal)}</span>
        </div>

        {!showPayment ? (
          <Button size='lg' fullWidth onClick={() => setShowPayment(true)}>
            Proceed to Payment
          </Button>
        ) : (
          <div className='bg-slate-900 rounded-2xl border border-slate-800 p-4 mb-4'>
            <PaymentSelector
              total={total}
              payments={payments}
              onChange={setPayments}
            />
          </div>
        )}

        {showPayment && (
          <Button
            size='lg'
            fullWidth
            variant='success'
            disabled={!paymentsValid}
            loading={isCommitting}
            onClick={handleCheckout}
            className='mb-4'
          >
            Complete Sale — {formatXAFShort(total)}
          </Button>
        )}
      </div>
    </AppShell>
  )
}
