/**
 * RetailGuard — Receipt Screen
 * Shown immediately after commitSale() — before server confirms.
 * receipt_number is null / "PENDING" until sync completes.
 */
import { useLocation, useNavigate } from 'react-router-dom'
import { AppShell } from '../../components/Layout'
import { Button, Badge } from '../../components/ui'
import { formatXAFShort } from '../../utils/currency'
import { unitLabel } from '../../utils/units'

export default function ReceiptScreen() {
  const navigate = useNavigate()
  const location = useLocation()
  const receipt  = location.state?.receipt

  if (!receipt) {
    navigate('/pos')
    return null
  }

  return (
    <AppShell title='Receipt' hideNav>
      <div className='px-4 py-6 flex flex-col items-center'>
        <div className='text-5xl mb-3'>✅</div>
        <h2 className='text-xl font-bold text-slate-100 mb-1'>Sale Complete</h2>

        <Badge variant={receipt.sync_status === 'synced' ? 'synced' : 'pending'} className='mb-6'>
          {receipt.sync_status === 'synced'
            ? `Receipt #${receipt.receipt_number}`
            : '⏳ Pending sync — saved locally'}
        </Badge>

        <div className='w-full max-w-sm bg-white text-slate-900 rounded-xl p-5 font-mono text-sm'>
          <div className='text-center mb-3 pb-3 border-b border-dashed border-slate-300'>
            <p className='font-bold'>RETAILGUARD</p>
            <p className='text-xs text-slate-500'>{new Date(receipt.timestamp).toLocaleString()}</p>
            <p className='text-xs text-slate-500'>Cashier: {receipt.cashier_name}</p>
          </div>

          {receipt.items.map(item => (
            <div key={item.id} className='flex justify-between mb-1'>
              <span className='truncate pr-2'>
                {item.product_name} × {item.quantity_sold}{unitLabel(item.unit_sold)}
              </span>
              <span className='shrink-0'>{formatXAFShort(item.total_price)}</span>
            </div>
          ))}

          <div className='border-t border-dashed border-slate-300 mt-2 pt-2'>
            <div className='flex justify-between font-bold'>
              <span>TOTAL</span>
              <span>{formatXAFShort(receipt.total)}</span>
            </div>
          </div>

          <div className='mt-3 pt-2 border-t border-dashed border-slate-300'>
            {receipt.payments.map((p, idx) => (
              <div key={idx} className='flex justify-between text-xs'>
                <span>{p.payment_method}</span>
                <span>{formatXAFShort(p.amount)}</span>
              </div>
            ))}
          </div>

          {receipt.sync_status !== 'synced' && (
            <p className='text-center text-xs text-orange-600 mt-3 pt-2 border-t border-dashed border-slate-300'>
              ⚠ Not yet confirmed by server
            </p>
          )}
        </div>

        <Button size='lg' fullWidth className='mt-6' onClick={() => navigate('/pos')}>
          New Sale
        </Button>
      </div>
    </AppShell>
  )
}
