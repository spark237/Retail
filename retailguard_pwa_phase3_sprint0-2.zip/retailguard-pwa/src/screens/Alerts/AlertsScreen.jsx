/**
 * RetailGuard — Alerts Screen
 * Fraud alert management. Network Only — never cached, never stale.
 */
import { useState, useEffect, useCallback } from 'react'
import { AppShell } from '../../components/Layout'
import { Badge, Card, Button, Spinner, EmptyState, Modal, Input } from '../../components/ui'
import { alertsAPI } from '../../api/client'
import { useAuthStore } from '../../store/authStore'

const LEVEL_VARIANT = { critical: 'critical', high: 'danger', medium: 'warning', low: 'default' }

export default function AlertsScreen() {
  const user = useAuthStore(s => s.user)
  const [alerts, setAlerts]   = useState([])
  const [isLoading, setLoading] = useState(true)
  const [filter, setFilter]   = useState('open')
  const [resolvingAlert, setResolvingAlert] = useState(null)
  const [resolutionNotes, setResolutionNotes] = useState('')

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const { data } = await alertsAPI.list({ status: filter === 'all' ? undefined : filter })
      setAlerts(data.data || [])
    } catch (err) {
      console.error('Failed to load alerts', err)
    } finally {
      setLoading(false)
    }
  }, [filter])

  useEffect(() => { load() }, [load])

  async function handleAcknowledge(id) {
    await alertsAPI.acknowledge(id)
    load()
  }

  async function handleResolve() {
    if (!resolvingAlert || !resolutionNotes.trim()) return
    await alertsAPI.resolve(resolvingAlert.id, resolutionNotes)
    setResolvingAlert(null)
    setResolutionNotes('')
    load()
  }

  const filters = [
    { value: 'open', label: 'Open' },
    { value: 'acknowledged', label: 'Acknowledged' },
    { value: 'all', label: 'All' },
  ]

  return (
    <AppShell title='Fraud Alerts'>
      <div className='px-4 pt-4 pb-2 flex gap-2'>
        {filters.map(f => (
          <button
            key={f.value}
            onClick={() => setFilter(f.value)}
            className={`px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${
              filter === f.value ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-400 border border-slate-700'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {isLoading ? (
        <div className='flex justify-center py-16'><Spinner size='lg' /></div>
      ) : alerts.length === 0 ? (
        <EmptyState icon='✅' title='No alerts' message='Everything looks good' />
      ) : (
        <div className='px-4 flex flex-col gap-3 pb-4'>
          {alerts.map(alert => (
            <Card key={alert.id}>
              <div className='flex items-start justify-between gap-2 mb-2'>
                <Badge variant={LEVEL_VARIANT[alert.alert_level]}>{alert.alert_level.toUpperCase()}</Badge>
                <span className='text-xs text-slate-500'>
                  {new Date(alert.created_at).toLocaleString()}
                </span>
              </div>
              <p className='font-semibold text-slate-100 mb-1'>{alert.title}</p>
              <p className='text-sm text-slate-400 mb-3'>{alert.description}</p>

              {alert.branch_name && (
                <p className='text-xs text-slate-500 mb-3'>📍 {alert.branch_name}</p>
              )}

              {alert.status === 'open' && (
                <div className='flex gap-2'>
                  <Button size='sm' variant='outline' onClick={() => handleAcknowledge(alert.id)}>
                    Acknowledge
                  </Button>
                  <Button size='sm' variant='secondary' onClick={() => setResolvingAlert(alert)}>
                    Resolve
                  </Button>
                </div>
              )}

              {alert.status === 'acknowledged' && (
                <Button size='sm' variant='secondary' onClick={() => setResolvingAlert(alert)}>
                  Resolve
                </Button>
              )}

              {(alert.status === 'resolved' || alert.status === 'dismissed') && (
                <Badge variant='default'>{alert.status}</Badge>
              )}
            </Card>
          ))}
        </div>
      )}

      <Modal
        isOpen={!!resolvingAlert}
        onClose={() => setResolvingAlert(null)}
        title='Resolve Alert'
      >
        <div className='flex flex-col gap-4'>
          <p className='text-sm text-slate-400'>{resolvingAlert?.title}</p>
          <Input
            label='Resolution notes'
            value={resolutionNotes}
            onChange={setResolutionNotes}
            placeholder='Explain how this was resolved...'
          />
          <Button
            fullWidth
            disabled={!resolutionNotes.trim()}
            onClick={handleResolve}
          >
            Confirm Resolution
          </Button>
        </div>
      </Modal>
    </AppShell>
  )
}
