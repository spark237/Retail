/**
 * RetailGuard — Shift Open Screen
 * Opens a shift, seeds product catalog + inventory into IndexedDB.
 */
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useShiftStore } from '../../store/shiftStore'
import { useAuthStore } from '../../store/authStore'
import { Button, Input, Alert, Spinner } from '../../components/ui'

export default function ShiftOpenScreen() {
  const navigate      = useNavigate()
  const user           = useAuthStore(s => s.user)
  const openShift      = useShiftStore(s => s.openShift)
  const isLoading      = useShiftStore(s => s.isLoading)
  const error          = useShiftStore(s => s.error)

  const [openingCash, setOpeningCash] = useState('')
  const [seeding, setSeeding]         = useState(false)

  async function handleOpen() {
    const cash = parseInt(openingCash) || 0
    setSeeding(true)
    const result = await openShift(user.primary_branch_id, cash)
    setSeeding(false)
    if (result.success) navigate('/pos')
  }

  return (
    <div className='min-h-screen bg-slate-950 flex flex-col justify-center px-6'>
      <div className='mb-8 text-center'>
        <div className='text-4xl mb-2'>🕐</div>
        <h1 className='text-xl font-bold text-slate-100'>Open Shift</h1>
        <p className='text-slate-400 text-sm mt-1'>Enter your opening cash float</p>
      </div>

      {error && <Alert variant='danger' className='mb-4'>{error.message}</Alert>}

      <Input
        label='Opening Cash (XAF)'
        value={openingCash}
        onChange={setOpeningCash}
        inputMode='numeric'
        placeholder='0'
        autoFocus
        suffix='XAF'
      />

      <Button
        onClick={handleOpen}
        size='lg'
        loading={isLoading || seeding}
        fullWidth
        className='mt-6'
      >
        {seeding ? 'Loading catalog…' : 'Start Shift'}
      </Button>

      {seeding && (
        <p className='text-center text-xs text-slate-500 mt-3'>
          Caching products and stock for offline use…
        </p>
      )}
    </div>
  )
}
