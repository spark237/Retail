/**
 * RetailGuard — Login Screen
 * Handles TERMINAL_OCCUPIED (409) response with takeover prompt for managers/owners.
 */
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuthStore } from '../../store/authStore'
import { authAPI } from '../../api/client'
import { Button, Input, Alert } from '../../components/ui'

export default function LoginScreen() {
  const navigate = useNavigate()
  const login    = useAuthStore(s => s.login)
  const isLoading = useAuthStore(s => s.isLoading)

  const [identifier, setIdentifier] = useState('')
  const [password, setPassword]     = useState('')
  const [error, setError]           = useState(null)
  const [takeoverPrompt, setTakeoverPrompt] = useState(null)  // { branch_id, ... }

  async function handleSubmit(e) {
    e.preventDefault()
    setError(null)
    setTakeoverPrompt(null)

    const result = await login(identifier, password)

    if (result.success) {
      navigate('/pos')
      return
    }

    if (result.error?.code === 'TERMINAL_OCCUPIED') {
      if (result.error.details?.can_override) {
        setTakeoverPrompt(result.error.details)
      } else {
        setError(`Branch is occupied by ${result.error.details?.cashier_name}. Ask a manager to take over.`)
      }
      return
    }

    if (result.error?.code === 'ACCOUNT_LOCKED') {
      setError('Account locked due to failed attempts. Try again later.')
      return
    }

    setError(result.error?.message || 'Login failed. Check your credentials.')
  }

  return (
    <div className='min-h-screen bg-slate-950 flex flex-col justify-center px-6'>
      <div className='mb-10 text-center'>
        <div className='text-4xl mb-2'>🛡️</div>
        <h1 className='text-2xl font-bold text-slate-100'>RetailGuard</h1>
        <p className='text-slate-400 text-sm mt-1'>Sign in to continue</p>
      </div>

      {error && (
        <Alert variant='danger' className='mb-4'>{error}</Alert>
      )}

      {takeoverPrompt && (
        <Alert variant='warning' title='Terminal occupied' className='mb-4'>
          <p className='mb-2'>
            {takeoverPrompt.cashier_name} has an active session since{' '}
            {new Date(takeoverPrompt.active_since).toLocaleTimeString()}.
          </p>
          <p className='text-xs opacity-75'>
            As a manager, you can take over this terminal. Go to Terminal Takeover to proceed.
          </p>
        </Alert>
      )}

      <form onSubmit={handleSubmit} className='flex flex-col gap-4'>
        <Input
          label='Phone or Email'
          value={identifier}
          onChange={setIdentifier}
          placeholder='237612345678'
          autoFocus
        />
        <Input
          label='Password'
          type='password'
          value={password}
          onChange={setPassword}
        />
        <Button type='submit' size='lg' loading={isLoading} fullWidth className='mt-2'>
          Sign In
        </Button>
      </form>
    </div>
  )
}
