/**
 * RetailGuard — Unit Conversion Utils
 * LOCKED: NUMERIC(12,3) precision. All quantities rounded to 3dp.
 */

export function convertToStockUnit(qty, unitSold, product) {
  const quantity   = parseFloat(qty)
  const stockUnit  = product.stock_unit || 'BOX'

  if (unitSold === stockUnit) {
    return round3(quantity)
  }

  if (stockUnit === 'BOX') {
    switch (unitSold) {
      case 'PIECE':
        if (!product.pieces_per_box) throw new Error(`Product "${product.name}" has no pieces_per_box`)
        return round3(quantity / parseFloat(product.pieces_per_box))
      case 'SQM':
        if (!product.sqm_per_box) throw new Error(`Product "${product.name}" has no sqm_per_box`)
        return round3(quantity / parseFloat(product.sqm_per_box))
      case 'PALLET':
        if (!product.boxes_per_pallet) throw new Error(`Product "${product.name}" has no boxes_per_pallet`)
        return round3(quantity * parseFloat(product.boxes_per_pallet))
      default:
        throw new Error(`Unknown unit: ${unitSold}`)
    }
  }

  throw new Error(`Unsupported stock_unit: ${stockUnit}`)
}

export function computeTotalPrice(unitPrice, qtyInStockUnit) {
  return Math.round(parseFloat(unitPrice) * parseFloat(qtyInStockUnit))
}

/** V2 Tile Estimator formula (non-MVP — reserved for future use). */
export function estimateTiles(widthM, lengthM, sqmPerBox, wastagePct = 10) {
  const area       = widthM * lengthM
  const adjusted   = area * (1 + wastagePct / 100)
  const boxes      = Math.ceil(adjusted / sqmPerBox)
  return { area_sqm: round3(area), adjusted_sqm: round3(adjusted), boxes_required: boxes }
}

export function unitLabel(unit) {
  return { PIECE: 'Piece', BOX: 'Box', SQM: 'm²', PALLET: 'Pallet' }[unit] || unit
}

export function availableUnits(product) {
  const units  = [product.stock_unit]
  const extras = {
    PIECE:  product.pieces_per_box,
    SQM:    product.sqm_per_box,
    PALLET: product.boxes_per_pallet,
  }
  for (const [unit, factor] of Object.entries(extras)) {
    if (factor && unit !== product.stock_unit) units.push(unit)
  }
  return units
}

function round3(n) {
  return Math.round(n * 1000) / 1000
}
