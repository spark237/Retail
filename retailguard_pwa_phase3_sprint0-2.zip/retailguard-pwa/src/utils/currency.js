/**
 * RetailGuard — Currency Utils (XAF)
 * XAF is stored as integers. No floats, no decimals.
 */

export function formatXAF(amount) {
  const n = parseInt(amount || 0)
  return new Intl.NumberFormat('fr-CM', {
    style:    'currency',
    currency: 'XAF',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(n)
}

export function formatXAFShort(amount) {
  const n = parseInt(amount || 0)
  return new Intl.NumberFormat('fr-FR', {
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(n) + ' XAF'
}

export function parseXAF(str) {
  if (!str) return 0
  return parseInt(String(str).replace(/[^\d]/g, ''), 10) || 0
}

export function computeChange(amountPaid, total) {
  return parseInt(amountPaid || 0) - parseInt(total || 0)
}

export function validatePayments(payments, total) {
  const sum = payments.reduce((s, p) => s + parseInt(p.amount || 0), 0)
  return sum === parseInt(total)
}
