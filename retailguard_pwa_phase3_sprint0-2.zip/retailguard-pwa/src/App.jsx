/**
 * RetailGuard — App Root
 * Wires routing, React Query, and app-level session restoration.
 */
import { useEffect } from 'react'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'

import { useAuthStore } from './store/authStore'
import { useShiftStore } from './store/shiftStore'
import { useConnectivityStore } from './store/connectivityStore'
import { SyncManager, syncEvents } from './sync/SyncManager'
import { RequireAuth, RequireShift, RequireRole } from './components/RouteGuards'

import LoginScreen      from './screens/Login/LoginScreen'
import ShiftOpenScreen  from './screens/ShiftOpen/ShiftOpenScreen'
import ShiftCloseScreen from './screens/ShiftClose/ShiftCloseScreen'
import POSScreen        from './screens/POS/POSScreen'
import CartScreen       from './screens/POS/CartScreen'
import ReceiptScreen    from './screens/POS/ReceiptScreen'
import InventoryScreen  from './screens/Inventory/InventoryScreen'
import DashboardScreen  from './screens/Dashboard/DashboardScreen'
import AlertsScreen     from './screens/Alerts/AlertsScreen'

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
})

export default function App() {
  const restoreSession = useAuthStore(s => s.restoreSession)
  const hydrateShift    = useShiftStore(s => s.hydrate)
  const initConnectivity = useConnectivityStore(s => s.init)

  useEffect(() => {
    // Boot sequence: restore session, hydrate shift, start background sync
    SyncManager.init()
    initConnectivity(syncEvents)
    restoreSession()
    hydrateShift()

    // Handle forced logout from API 401 refresh failure
    const handleLogout = () => useAuthStore.getState().logout()
    window.addEventListener('auth:logout', handleLogout)
    return () => window.removeEventListener('auth:logout', handleLogout)
  }, [])

  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <Routes>
          <Route path='/login' element={<LoginScreen />} />

          <Route path='/shift/open' element={
            <RequireAuth><ShiftOpenScreen /></RequireAuth>
          } />

          <Route path='/pos' element={
            <RequireAuth><RequireShift><POSScreen /></RequireShift></RequireAuth>
          } />
          <Route path='/pos/cart' element={
            <RequireAuth><RequireShift><CartScreen /></RequireShift></RequireAuth>
          } />
          <Route path='/pos/receipt' element={
            <RequireAuth><RequireShift><ReceiptScreen /></RequireShift></RequireAuth>
          } />

          <Route path='/inventory' element={
            <RequireAuth><RequireShift><InventoryScreen /></RequireShift></RequireAuth>
          } />

          <Route path='/shifts' element={
            <RequireAuth><RequireShift><ShiftCloseScreen /></RequireShift></RequireAuth>
          } />

          <Route path='/dashboard' element={
            <RequireAuth>
              <RequireRole roles={['owner', 'manager']}>
                <DashboardScreen />
              </RequireRole>
            </RequireAuth>
          } />

          <Route path='/alerts' element={
            <RequireAuth>
              <RequireRole roles={['owner', 'manager']}>
                <AlertsScreen />
              </RequireRole>
            </RequireAuth>
          } />

          <Route path='/' element={<Navigate to='/pos' replace />} />
          <Route path='*' element={<Navigate to='/pos' replace />} />
        </Routes>
      </BrowserRouter>
    </QueryClientProvider>
  )
}
