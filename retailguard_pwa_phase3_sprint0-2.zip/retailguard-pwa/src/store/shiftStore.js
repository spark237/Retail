/**
 * RetailGuard — Shift Store (Zustand)
 */
import { create } from 'zustand'
import { getDB } from '../db/schema'
import { shiftsAPI, productsAPI, inventoryAPI } from '../api/client'
import { productsDB } from '../db/products'
import { inventoryDB } from '../db/inventory'

const SHIFT_KEY = 'shift'

async function saveShiftToDB(shift) {
  const db = await getDB()
  await db.put('auth', { key: SHIFT_KEY, shift })
}

async function loadShiftFromDB() {
  const db    = await getDB()
  const entry = await db.get('auth', SHIFT_KEY)
  return entry?.shift || null
}

export const useShiftStore = create((set, get) => ({
  shift:      null,
  isLoading:  false,
  error:      null,

  hydrate: async () => {
    const shift = await loadShiftFromDB()
    if (shift) set({ shift })
  },

  openShift: async (branchId, openingCash) => {
    set({ isLoading: true, error: null })
    try {
      const { data } = await shiftsAPI.open(branchId, openingCash)
      const shift    = data.data
      await saveShiftToDB(shift)

      await Promise.all([
        get()._seedProducts(),
        get()._seedInventory(branchId),
      ])

      set({ shift, isLoading: false })
      return { success: true, shift }
    } catch (err) {
      const error = err.response?.data?.error || { message: 'Failed to open shift' }
      set({ isLoading: false, error })
      return { success: false, error }
    }
  },

  closeShift: async (actualCash, notes = '') => {
    const { shift } = get()
    if (!shift) return { success: false, error: 'No active shift' }
    set({ isLoading: true, error: null })
    try {
      const { data } = await shiftsAPI.close(shift.id, actualCash, notes)
      const updated  = { ...shift, status: data.data.status, closed_at: new Date().toISOString() }
      await saveShiftToDB(updated)
      set({ shift: updated, isLoading: false })
      return { success: true, data: data.data }
    } catch (err) {
      const error = err.response?.data?.error || { message: 'Failed to close shift' }
      set({ isLoading: false, error })
      return { success: false, error }
    }
  },

  clearShift: async () => {
    const db = await getDB()
    await db.delete('auth', SHIFT_KEY)
    set({ shift: null })
  },

  _seedProducts: async () => {
    try {
      const { data } = await productsAPI.list({ per_page: 500, is_active: true })
      if (data.data?.length) await productsDB.bulkPut(data.data)
    } catch (err) {
      console.warn('[ShiftStore] Product seed failed — will use cached data', err.message)
    }
  },

  _seedInventory: async (branchId) => {
    try {
      const { data } = await inventoryAPI.list({ branch_id: branchId, per_page: 500 })
      if (data.data?.length) await inventoryDB.bulkPut(data.data)
    } catch (err) {
      console.warn('[ShiftStore] Inventory seed failed — will use cached data', err.message)
    }
  },
}))
