/**
 * RetailGuard — Connectivity Store (Zustand)
 * Subscribes to SyncManager events and exposes sync state to React UI.
 */
import { create } from 'zustand'
import { SyncEvent } from '../sync/SyncManager'
import { syncQueueDB } from '../db/syncQueue'

export const useConnectivityStore = create((set, get) => ({
  isOnline:       navigator.onLine,
  isSyncing:      false,
  pendingCount:   0,
  conflictCount:  0,
  lastSyncAt:     null,

  init: (syncEvents) => {
    syncEvents.addEventListener(SyncEvent.CONNECTIVITY, (e) => {
      set({ isOnline: e.detail.online })
    })
    syncEvents.addEventListener(SyncEvent.STARTED, () => {
      set({ isSyncing: true })
    })
    syncEvents.addEventListener(SyncEvent.COMPLETED, () => {
      set({ isSyncing: false, lastSyncAt: new Date().toISOString() })
      get().refreshCounts()
    })
    syncEvents.addEventListener(SyncEvent.QUEUE_EMPTY, () => {
      set({ isSyncing: false, pendingCount: 0 })
    })
    syncEvents.addEventListener(SyncEvent.ITEM_CONFLICT, () => {
      set(s => ({ conflictCount: s.conflictCount + 1 }))
    })
    syncEvents.addEventListener(SyncEvent.ITEM_SUCCESS, () => {
      get().refreshCounts()
    })
  },

  refreshCounts: async () => {
    try {
      const count = await syncQueueDB.pendingCount()
      set({ pendingCount: count })
    } catch { /* non-fatal */ }
  },
}))
