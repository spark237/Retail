/**
 * RetailGuard — Auth Store (Zustand)
 * JWT access token lives in tokenStore (memory) — never in this store.
 */
import { create } from 'zustand'
import { tokenStore, authAPI } from '../api/client'
import { getDB, clearBusinessData } from '../db/schema'

async function saveAuthToDB(key, value) {
  const db = await getDB()
  await db.put('auth', { key, ...value })
}

async function getAuthFromDB(key) {
  const db = await getDB()
  return db.get('auth', key)
}

export const useAuthStore = create((set, get) => ({
  user:        null,
  business:    null,
  isLoggedIn:  false,
  isLoading:   false,
  error:       null,

  login: async (identifier, password, branchId) => {
    set({ isLoading: true, error: null })
    try {
      let fingerprint = sessionStorage.getItem('device_fingerprint')
      if (!fingerprint) {
        fingerprint = crypto.randomUUID()
        sessionStorage.setItem('device_fingerprint', fingerprint)
      }

      const { data } = await authAPI.login(identifier, password, branchId, fingerprint)
      const { access_token, user } = data.data

      tokenStore.set(access_token)

      await saveAuthToDB('session', {
        user_id:           user.id,
        business_id:       user.business_id,
        role:              user.role,
        primary_branch_id: user.primary_branch_id,
        fingerprint,
      })
      await saveAuthToDB('user', user)

      set({ user, isLoggedIn: true, isLoading: false, error: null })
      return { success: true, user }
    } catch (err) {
      const error = err.response?.data?.error || { message: 'Login failed' }
      set({ isLoading: false, error, isLoggedIn: false })
      return { success: false, error }
    }
  },

  restoreSession: async () => {
    set({ isLoading: true })
    try {
      const { data } = await authAPI.refresh()
      tokenStore.set(data.data.access_token)

      const user = await getAuthFromDB('user')
      if (user) {
        set({ user, isLoggedIn: true, isLoading: false })
        try {
          const { data: meData } = await authAPI.me()
          set({ user: meData.data })
          await saveAuthToDB('user', meData.data)
        } catch { /* use cached */ }
      } else {
        set({ isLoading: false })
      }
    } catch {
      tokenStore.clear()
      set({ user: null, isLoggedIn: false, isLoading: false })
    }
  },

  logout: async () => {
    try { await authAPI.logout() } catch { /* best effort */ }
    tokenStore.clear()
    await clearBusinessData()
    const db = await getDB()
    await db.clear('auth')
    set({ user: null, isLoggedIn: false, error: null })
  },

  clearError: () => set({ error: null }),
}))
