/**
 * RetailGuard — Cart Store (Zustand)
 * Every mutation writes to IndexedDB immediately for crash recovery.
 */
import { create } from 'zustand'
import { getDB } from '../db/schema'
import { inventoryDB } from '../db/inventory'
import { salesDB } from '../db/sales'
import { syncQueueDB, EntityType } from '../db/syncQueue'
import { convertToStockUnit, computeTotalPrice } from '../utils/units'
import { SyncManager } from '../sync/SyncManager'

const CART_KEY = 'active_cart'

async function persistCart(cart) {
  const db = await getDB()
  await db.put('settings', { key: CART_KEY, cart })
}

async function loadCart() {
  try {
    const db    = await getDB()
    const entry = await db.get('settings', CART_KEY)
    return entry?.cart || null
  } catch {
    return null
  }
}

async function clearCartDB() {
  const db = await getDB()
  await db.delete('settings', CART_KEY)
}

const emptyCart = () => ({
  items:          [],
  paymentMethod:  'CASH',
  payments:       [],
  notes:          '',
  discountAmount: 0,
})

/**
 * Extract ONLY the plain-data cart fields from the store's current state.
 *
 * Never spread the raw store object (`{ ...get() }`) into persistCart().
 * Zustand's get() returns the full store — data fields AND every action
 * function (addItem, commitSale, etc.) plus the subtotal/totalAmount
 * getters. IndexedDB's structured-clone algorithm cannot serialize
 * functions and throws DataCloneError the instant it tries — which
 * silently breaks persistence on every mutation past the first one,
 * since callers don't await/catch persistCart() defensively.
 */
function persistableCartFields(state) {
  return {
    items:          state.items,
    paymentMethod:  state.paymentMethod,
    payments:       state.payments,
    notes:          state.notes,
    discountAmount: state.discountAmount,
  }
}

export const useCartStore = create((set, get) => ({
  ...emptyCart(),
  isCommitting: false,
  lastReceipt:  null,
  error:        null,

  hydrate: async () => {
    const saved = await loadCart()
    if (saved) set({ ...saved })
  },

  addItem: async (product, quantitySold, unitSold) => {
    const { items } = get()
    const qtyInStockUnit = convertToStockUnit(quantitySold, unitSold, product)
    const totalPrice = computeTotalPrice(product.selling_price, qtyInStockUnit)

    const existingIdx = items.findIndex(
      i => i.product_id === product.id && i.unit_sold === unitSold
    )

    let newItems
    if (existingIdx >= 0) {
      newItems = items.map((item, idx) =>
        idx === existingIdx
          ? {
              ...item,
              quantity_sold:          parseFloat(item.quantity_sold) + parseFloat(quantitySold),
              quantity_in_stock_unit: (parseFloat(item.quantity_in_stock_unit) + qtyInStockUnit).toFixed(3),
              total_price:            item.total_price + totalPrice,
            }
          : item
      )
    } else {
      newItems = [
        ...items,
        {
          id:                     crypto.randomUUID(),
          product_id:             product.id,
          product_name:           product.name,
          product_sku:            product.sku,
          tile_size:              product.tile_size,
          unit_sold:              unitSold,
          quantity_sold:          String(quantitySold),
          stock_unit_snapshot:    product.stock_unit,
          quantity_in_stock_unit: qtyInStockUnit.toFixed(3),
          unit_price:             product.selling_price,
          discount_amount:        0,
          total_price:            totalPrice,
          is_price_override:      false,
          override_approval_id:   null,
          _product:               product,
        },
      ]
    }

    set({ items: newItems })
    await persistCart({ ...persistableCartFields(get()), items: newItems })
  },

  removeItem: async (itemId) => {
    const newItems = get().items.filter(i => i.id !== itemId)
    set({ items: newItems })
    await persistCart({ ...persistableCartFields(get()), items: newItems })
  },

  updateItemQuantity: async (itemId, newQtySold, product) => {
    const items = get().items
    const item  = items.find(i => i.id === itemId)
    if (!item) return

    const qtyInStockUnit = convertToStockUnit(newQtySold, item.unit_sold, product)
    const totalPrice     = computeTotalPrice(item.unit_price, qtyInStockUnit)

    const newItems = items.map(i =>
      i.id === itemId
        ? { ...i, quantity_sold: String(newQtySold),
            quantity_in_stock_unit: qtyInStockUnit.toFixed(3),
            total_price: totalPrice }
        : i
    )
    set({ items: newItems })
    await persistCart({ ...persistableCartFields(get()), items: newItems })
  },

  setPaymentMethod: async (method) => {
    set({ paymentMethod: method })
    await persistCart({ ...persistableCartFields(get()), paymentMethod: method })
  },

  setPayments: async (payments) => {
    set({ payments })
    await persistCart({ ...persistableCartFields(get()), payments })
  },

  setNotes: async (notes) => {
    set({ notes })
    await persistCart({ ...persistableCartFields(get()), notes })
  },

  get subtotal() {
    return get().items.reduce((s, i) => s + i.total_price, 0)
  },

  get totalAmount() {
    return get().subtotal - get().discountAmount
  },

  commitSale: async ({ shiftId, branchId, cashier }) => {
    const { items, payments, notes, discountAmount } = get()
    if (items.length === 0) {
      set({ error: 'Cart is empty' })
      return { success: false, error: 'Cart is empty' }
    }

    set({ isCommitting: true, error: null })

    try {
      const saleId = crypto.randomUUID()
      const now    = new Date().toISOString()

      const subtotal    = items.reduce((s, i) => s + i.total_price, 0)
      const totalAmount = subtotal - discountAmount

      // Stock check + staleness detection (see db/inventory.js for rationale).
      // A stale snapshot that still passes quantity check isn't blocked —
      // offline-first means never making the cashier wait on the network —
      // but is flagged for visibility on the receipt/sync layer.
      let staleWarning = false
      for (const item of items) {
        const stock = await inventoryDB.getStock(item.product_id, branchId)
        const available = stock ? parseFloat(stock.quantity) : 0
        const needed    = parseFloat(item.quantity_in_stock_unit)
        if (available < needed) {
          throw new Error(`INSUFFICIENT_STOCK:${item.product_name}:${available}:${needed}:${item.stock_unit_snapshot}`)
        }
        if (inventoryDB.isStale(stock)) staleWarning = true
      }

      const saleRecord = {
        id:               saleId,
        shift_id:         shiftId,
        branch_id:        branchId,
        cashier_id:       cashier.id,
        subtotal,
        discount_amount:  discountAmount,
        total_amount:     totalAmount,
        status:           'completed',
        sync_status:      'pending',
        receipt_number:   null,
        created_at_device: now,
        synced_at:        null,
        notes,
      }
      await salesDB.put(saleRecord)

      const saleItems = items.map(item => ({
        id:                     item.id,
        sale_id:                saleId,
        product_id:             item.product_id,
        product_name:           item.product_name,
        product_sku:            item.product_sku,
        tile_size:              item.tile_size,
        unit_sold:              item.unit_sold,
        quantity_sold:          item.quantity_sold,
        stock_unit_snapshot:    item.stock_unit_snapshot,
        quantity_in_stock_unit: item.quantity_in_stock_unit,
        unit_price:             item.unit_price,
        discount_amount:        item.discount_amount,
        total_price:            item.total_price,
        is_price_override:      item.is_price_override,
        override_approval_id:   item.override_approval_id,
      }))
      await salesDB.putItems(saleItems)

      const paymentRecords = payments.map(p => ({
        id:             crypto.randomUUID(),
        sale_id:        saleId,
        payment_method: p.method,
        amount:         p.amount,
        reference_number: p.reference || null,
        is_confirmed:   p.method === 'CASH',
      }))
      await salesDB.putPayments(paymentRecords)

      for (const item of items) {
        await inventoryDB.deductStock(
          item.product_id,
          branchId,
          item.quantity_in_stock_unit
        )
      }

      await syncQueueDB.enqueue({
        entityType: EntityType.SALE,
        entityId:   saleId,
        operation:  'create',
        payload: {
          id:               saleId,
          shift_id:         shiftId,
          created_at_device: now,
          notes,
          items: saleItems.map(({ id, product_id, unit_sold, quantity_sold,
            unit_price, discount_amount, override_approval_id }) => ({
            id, product_id, unit_sold, quantity_sold,
            unit_price, discount_amount, override_approval_id,
          })),
          payments: paymentRecords.map(({ payment_method, amount, reference_number }) => ({
            payment_method, amount, reference_number,
          })),
        },
      })

      const receipt = {
        sale_id:       saleId,
        items:         saleItems,
        payments:      paymentRecords,
        subtotal,
        discount:      discountAmount,
        total:         totalAmount,
        cashier_name:  `${cashier.first_name} ${cashier.last_name}`,
        timestamp:     now,
        sync_status:   'pending',
        receipt_number: null,
        stale_inventory_warning: staleWarning,
      }

      set({ lastReceipt: receipt, isCommitting: false })
      await clearCartDB()
      set(emptyCart())

      if (SyncManager.isOnline) {
        SyncManager.flush()
      }

      return { success: true, receipt }
    } catch (err) {
      set({ isCommitting: false, error: err.message })
      if (err.message.startsWith('INSUFFICIENT_STOCK:')) {
        const [, name, available, needed, unit] = err.message.split(':')
        return { success: false, error: 'INSUFFICIENT_STOCK',
          details: { product_name: name, available: parseFloat(available),
            requested: parseFloat(needed), unit } }
      }
      return { success: false, error: err.message }
    }
  },

  clearCart: async () => {
    set(emptyCart())
    await clearCartDB()
  },

  clearError: () => set({ error: null }),
  clearReceipt: () => set({ lastReceipt: null }),
}))
