/**
 * RetailGuard — Custom Hooks
 * React Query = server cache only. IndexedDB = source of truth for offline data.
 */
import { useState, useEffect, useCallback, useRef } from 'react'
import { useQuery } from '@tanstack/react-query'
import { productsDB } from '../db/products'
import { inventoryDB } from '../db/inventory'
import { salesDB } from '../db/sales'
import { syncEvents, SyncEvent, SyncManager } from '../sync/SyncManager'
import { useConnectivityStore } from '../store/connectivityStore'
import { analyticsAPI } from '../api/client'

// ─── useProducts ─────────────────────────────────────────────────────────────
export function useProducts({ search = '', categoryId, tileType } = {}) {
  const [products, setProducts] = useState([])
  const [isLoading, setIsLoading] = useState(true)

  const fetch = useCallback(async () => {
    setIsLoading(true)
    try {
      const results = await productsDB.search(search, { categoryId, tileType })
      setProducts(results)
    } finally {
      setIsLoading(false)
    }
  }, [search, categoryId, tileType])

  useEffect(() => { fetch() }, [fetch])

  return { products, isLoading, refresh: fetch }
}

// ─── useProductSearch (debounced) ────────────────────────────────────────────
export function useProductSearch(initialQuery = '') {
  const [query, setQuery]   = useState(initialQuery)
  const [results, setResults] = useState([])
  const timerRef            = useRef(null)

  useEffect(() => {
    clearTimeout(timerRef.current)
    if (!query.trim()) {
      setResults([])
      return
    }
    timerRef.current = setTimeout(async () => {
      const found = await productsDB.search(query)
      setResults(found)
    }, 250)
    return () => clearTimeout(timerRef.current)
  }, [query])

  return { query, setQuery, results }
}

// ─── useInventory ─────────────────────────────────────────────────────────────
export function useInventory(branchId) {
  const [stock, setStock]     = useState([])
  const [isLoading, setLoading] = useState(true)

  const load = useCallback(async () => {
    if (!branchId) return
    setLoading(true)
    try {
      const items = await inventoryDB.getByBranch(branchId)
      setStock(items)
    } finally {
      setLoading(false)
    }
  }, [branchId])

  useEffect(() => { load() }, [load])

  useEffect(() => {
    const handler = () => load()
    syncEvents.addEventListener(SyncEvent.ITEM_SUCCESS, handler)
    syncEvents.addEventListener(SyncEvent.COMPLETED, handler)
    return () => {
      syncEvents.removeEventListener(SyncEvent.ITEM_SUCCESS, handler)
      syncEvents.removeEventListener(SyncEvent.COMPLETED, handler)
    }
  }, [load])

  const getProductStock = useCallback(
    async (productId) => inventoryDB.getStock(productId, branchId),
    [branchId]
  )

  return { stock, isLoading, refresh: load, getProductStock }
}

// ─── useShiftSales ────────────────────────────────────────────────────────────
export function useShiftSales(shiftId) {
  const [sales, setSales]       = useState([])
  const [summary, setSummary]   = useState(null)
  const [isLoading, setLoading] = useState(true)

  const load = useCallback(async () => {
    if (!shiftId) return
    setLoading(true)
    try {
      const data = await salesDB.getByShift(shiftId)
      setSales(data)
      const counts    = await salesDB.countByShift(shiftId)
      const revenue   = await salesDB.getShiftRevenue(shiftId)
      const cashTotal = await salesDB.getCashTotal(shiftId)
      setSummary({ ...counts, revenue, cashTotal })
    } finally {
      setLoading(false)
    }
  }, [shiftId])

  useEffect(() => { load() }, [load])

  useEffect(() => {
    const handler = () => load()
    syncEvents.addEventListener(SyncEvent.ITEM_SUCCESS, handler)
    return () => syncEvents.removeEventListener(SyncEvent.ITEM_SUCCESS, handler)
  }, [load])

  return { sales, summary, isLoading, refresh: load }
}

// ─── useSync ─────────────────────────────────────────────────────────────────
export function useSync() {
  const { isOnline, isSyncing, pendingCount, conflictCount, lastSyncAt } =
    useConnectivityStore()

  const manualSync = useCallback(async () => {
    if (SyncManager.isOnline) await SyncManager.flush()
  }, [])

  return { isOnline, isSyncing, pendingCount, conflictCount, lastSyncAt, manualSync }
}

// ─── useConnectivity ─────────────────────────────────────────────────────────
export function useConnectivity() {
  return useConnectivityStore(s => ({
    isOnline: s.isOnline,
    pendingCount: s.pendingCount,
  }))
}

// ─── useDailyAnalytics (server — React Query) ────────────────────────────────
export function useDailyAnalytics(branchId, date) {
  return useQuery({
    queryKey: ['analytics', 'daily', branchId, date],
    queryFn:  () => analyticsAPI.daily({ branch_id: branchId, date }).then(r => r.data.data),
    staleTime: 5 * 60 * 1000,
    enabled:  !!branchId,
  })
}
