/**
 * RetailGuard IndexedDB Schema
 *
 * 9 object stores — separated by entity to prevent full-store scans during sync.
 * This is the SINGLE SOURCE OF TRUTH for all business data offline.
 *
 * React Query caches server responses.
 * IndexedDB stores business state.
 * They are NOT the same thing.
 */
import { openDB } from 'idb'

const DB_NAME    = 'retailguard'
const DB_VERSION = 1

let _db = null

export async function getDB() {
  if (_db) return _db

  _db = await openDB(DB_NAME, DB_VERSION, {
    upgrade(db, oldVersion) {
      if (!db.objectStoreNames.contains('products')) {
        const ps = db.createObjectStore('products', { keyPath: 'id' })
        ps.createIndex('by_category',  'category_id')
        ps.createIndex('by_sku',       'sku')
        ps.createIndex('by_barcode',   'barcode')
        ps.createIndex('by_tile_type', 'tile_type')
        ps.createIndex('by_active',    'is_active')
      }

      if (!db.objectStoreNames.contains('inventory')) {
        const inv = db.createObjectStore('inventory', { keyPath: 'id' })
        inv.createIndex('by_product_branch', ['product_id', 'branch_id'], { unique: true })
        inv.createIndex('by_branch',         'branch_id')
        inv.createIndex('by_product',        'product_id')
      }

      if (!db.objectStoreNames.contains('sales')) {
        const sales = db.createObjectStore('sales', { keyPath: 'id' })
        sales.createIndex('by_shift',       'shift_id')
        sales.createIndex('by_sync_status', 'sync_status')
        sales.createIndex('by_status',      'status')
        sales.createIndex('by_created',     'created_at_device')
      }

      if (!db.objectStoreNames.contains('sale_items')) {
        const items = db.createObjectStore('sale_items', { keyPath: 'id' })
        items.createIndex('by_sale',    'sale_id')
        items.createIndex('by_product', 'product_id')
      }

      if (!db.objectStoreNames.contains('payments')) {
        const pay = db.createObjectStore('payments', { keyPath: 'id' })
        pay.createIndex('by_sale',   'sale_id')
        pay.createIndex('by_method', 'payment_method')
      }

      if (!db.objectStoreNames.contains('sync_queue')) {
        const sq = db.createObjectStore('sync_queue', { keyPath: 'id' })
        sq.createIndex('by_status',      'status')
        sq.createIndex('by_entity_type', 'entity_type')
        sq.createIndex('by_created',     'created_at')
        sq.createIndex('by_sequence',    'local_sequence')
      }

      if (!db.objectStoreNames.contains('price_overrides')) {
        const po = db.createObjectStore('price_overrides', { keyPath: 'id' })
        po.createIndex('by_status',  'status')
        po.createIndex('by_product', 'product_id')
      }

      if (!db.objectStoreNames.contains('auth')) {
        db.createObjectStore('auth', { keyPath: 'key' })
      }

      if (!db.objectStoreNames.contains('settings')) {
        db.createObjectStore('settings', { keyPath: 'key' })
      }
    },

    blocked() {
      console.warn('[IDB] Database upgrade blocked by another tab. Please close other tabs.')
    },

    blocking() {
      _db?.close()
      _db = null
      window.location.reload()
    },

    terminated() {
      _db = null
    },
  })

  return _db
}

/** Clear all business data stores (not auth/settings). Used on logout. */
export async function clearBusinessData() {
  const db = await getDB()
  const tx = db.transaction(
    ['products', 'inventory', 'sales', 'sale_items', 'payments', 'sync_queue', 'price_overrides'],
    'readwrite'
  )
  await Promise.all([
    tx.objectStore('products').clear(),
    tx.objectStore('inventory').clear(),
    tx.objectStore('sales').clear(),
    tx.objectStore('sale_items').clear(),
    tx.objectStore('payments').clear(),
    tx.objectStore('sync_queue').clear(),
    tx.objectStore('price_overrides').clear(),
  ])
  await tx.done
}

/**
 * TEST-ONLY: closes and drops the cached connection handle.
 * Not called anywhere in production code. Necessary because getDB() memoizes
 * `_db` in a module-level closure — after a test deletes the underlying
 * IndexedDB database, that cached handle is left pointing at nothing, and
 * every subsequent getDB() call in the same process would return the stale
 * connection instead of opening a fresh one against the recreated database.
 */
export function __resetConnectionForTests() {
  _db?.close()
  _db = null
}
