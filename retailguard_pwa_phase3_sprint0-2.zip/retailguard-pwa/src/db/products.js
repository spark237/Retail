/**
 * IndexedDB — Products Store
 * NetworkFirst: populated from API, available offline.
 */
import { getDB } from './schema'

export const productsDB = {
  async bulkPut(products) {
    const db = await getDB()
    const tx = db.transaction('products', 'readwrite')
    await Promise.all([
      ...products.map(p => tx.store.put(p)),
      tx.done,
    ])
  },

  async getById(id) {
    const db = await getDB()
    return db.get('products', id)
  },

  async search(query = '', { categoryId, tileType, isActive = true } = {}) {
    const db  = await getDB()
    const all = await db.getAll('products')
    return all.filter(p => {
      if (isActive && !p.is_active) return false
      if (categoryId && p.category_id !== categoryId) return false
      if (tileType   && p.tile_type  !== tileType)    return false
      if (query) {
        const q = query.toLowerCase()
        return (
          p.name?.toLowerCase().includes(q) ||
          p.sku?.toLowerCase().includes(q)  ||
          p.barcode?.includes(q)            ||
          p.tile_size?.includes(q)
        )
      }
      return true
    })
  },

  async getByBarcode(barcode) {
    const db = await getDB()
    return db.getFromIndex('products', 'by_barcode', barcode)
  },

  async getAll() {
    const db = await getDB()
    return db.getAll('products')
  },

  async count() {
    const db = await getDB()
    return db.count('products')
  },
}
