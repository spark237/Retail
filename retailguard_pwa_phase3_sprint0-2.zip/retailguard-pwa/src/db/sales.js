/**
 * IndexedDB — Sales Store
 * Sales are written here FIRST, then queued for server sync.
 */
import { getDB } from './schema'

export const salesDB = {
  async put(sale) {
    const db = await getDB()
    return db.put('sales', sale)
  },

  async getById(id) {
    const db = await getDB()
    return db.get('sales', id)
  },

  async getByShift(shiftId) {
    const db = await getDB()
    return db.getAllFromIndex('sales', 'by_shift', shiftId)
  },

  async getPending() {
    const db = await getDB()
    return db.getAllFromIndex('sales', 'by_sync_status', 'pending')
  },

  async updateSyncStatus(saleId, syncStatus, receiptNumber = null) {
    const db   = await getDB()
    const sale = await db.get('sales', saleId)
    if (!sale) return
    sale.sync_status = syncStatus
    if (receiptNumber) sale.receipt_number = receiptNumber
    return db.put('sales', sale)
  },

  async countByShift(shiftId) {
    const all = await this.getByShift(shiftId)
    return {
      total:    all.length,
      synced:   all.filter(s => s.sync_status === 'synced').length,
      pending:  all.filter(s => s.sync_status === 'pending').length,
      conflict: all.filter(s => s.sync_status === 'conflict').length,
    }
  },

  async getShiftRevenue(shiftId) {
    const sales = await this.getByShift(shiftId)
    const completed = sales.filter(s =>
      s.status !== 'voided' && s.sync_status !== 'rejected'
    )
    return completed.reduce((sum, s) => sum + parseInt(s.total_amount || 0), 0)
  },

  async putItems(items) {
    const db = await getDB()
    const tx = db.transaction('sale_items', 'readwrite')
    await Promise.all([...items.map(i => tx.store.put(i)), tx.done])
  },

  async getItemsBySale(saleId) {
    const db = await getDB()
    return db.getAllFromIndex('sale_items', 'by_sale', saleId)
  },

  async putPayments(payments) {
    const db = await getDB()
    const tx = db.transaction('payments', 'readwrite')
    await Promise.all([...payments.map(p => tx.store.put(p)), tx.done])
  },

  async getPaymentsBySale(saleId) {
    const db = await getDB()
    return db.getAllFromIndex('payments', 'by_sale', saleId)
  },

  async getCashTotal(shiftId) {
    const sales = await this.getByShift(shiftId)
    const db    = await getDB()
    let total   = 0
    for (const sale of sales) {
      if (sale.status === 'voided') continue
      const payments = await db.getAllFromIndex('payments', 'by_sale', sale.id)
      for (const p of payments) {
        if (p.payment_method === 'CASH') {
          total += parseInt(p.amount || 0)
        }
      }
    }
    return total
  },
}
