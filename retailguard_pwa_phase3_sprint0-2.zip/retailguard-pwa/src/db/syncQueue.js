/**
 * IndexedDB — Generic Sync Queue
 * Handles sales, damage reports, shift close, attendance, transfers.
 *
 * ORDERING: local_sequence is a monotonically increasing integer,
 * assigned atomically at enqueue time. created_at (ISO timestamp) is
 * kept for display/debugging only — it is NOT used for sort order.
 * Millisecond-resolution timestamps can collide when two operations
 * are queued in rapid succession (e.g. add sale → immediately queue
 * shift close); an integer counter cannot.
 */
import { getDB } from './schema'

export const SyncStatus = {
  QUEUED:     'queued',
  PROCESSING: 'processing',
  COMPLETED:  'completed',
  FAILED:     'failed',
  DEAD:       'dead',
  CONFLICT:   'conflict',
}

export const EntityType = {
  SALE:          'sale',
  DAMAGE_REPORT: 'damage_report',
  SHIFT_CLOSE:   'shift_close',
  ATTENDANCE:    'attendance',
  TRANSFER:      'transfer',
}

const MAX_RETRIES = 5
const SEQUENCE_KEY = 'sync_queue_sequence'

/**
 * Atomically read-increment-write the sequence counter.
 * Uses the 'settings' store as a single-row counter. Runs inside
 * its own transaction so concurrent enqueue() calls never collide.
 */
async function nextSequence() {
  const db = await getDB()
  const tx = db.transaction('settings', 'readwrite')
  const store = tx.objectStore('settings')
  const current = await store.get(SEQUENCE_KEY)
  const next = (current?.value || 0) + 1
  await store.put({ key: SEQUENCE_KEY, value: next })
  await tx.done
  return next
}

export const syncQueueDB = {
  async enqueue({ entityType, entityId, operation, payload }) {
    const db = await getDB()
    const sequence = await nextSequence()
    const entry = {
      id:              crypto.randomUUID(),
      local_sequence:  sequence,
      entity_type:     entityType,
      entity_id:       entityId,
      operation,
      payload,
      status:          SyncStatus.QUEUED,
      retry_count:     0,
      created_at:      new Date().toISOString(),
      last_attempt:    null,
    }
    await db.put('sync_queue', entry)
    return entry.id
  },

  async getQueued() {
    const db = await getDB()
    const all = await db.getAllFromIndex('sync_queue', 'by_status', SyncStatus.QUEUED)
    // Strict sequence order — not timestamp order. See module docstring.
    return all.sort((a, b) => a.local_sequence - b.local_sequence)
  },

  async getFailed() {
    const db = await getDB()
    return db.getAllFromIndex('sync_queue', 'by_status', SyncStatus.FAILED)
  },

  async getAll() {
    const db = await getDB()
    return db.getAll('sync_queue')
  },

  async markProcessing(id) {
    return this._updateStatus(id, SyncStatus.PROCESSING, {
      last_attempt: new Date().toISOString(),
    })
  },

  async markCompleted(id) {
    return this._updateStatus(id, SyncStatus.COMPLETED)
  },

  async markFailed(id, errorMessage) {
    const db    = await getDB()
    const entry = await db.get('sync_queue', id)
    if (!entry) return

    entry.retry_count++
    entry.last_attempt   = new Date().toISOString()
    entry.last_error     = errorMessage
    entry.status = entry.retry_count >= MAX_RETRIES
      ? SyncStatus.DEAD
      : SyncStatus.FAILED

    return db.put('sync_queue', entry)
  },

  async markConflict(id, conflictDetail) {
    return this._updateStatus(id, SyncStatus.CONFLICT, {
      conflict_detail: conflictDetail,
    })
  },

  async requeueFailed() {
    const db     = await getDB()
    const failed = await db.getAllFromIndex('sync_queue', 'by_status', SyncStatus.FAILED)
    const tx     = db.transaction('sync_queue', 'readwrite')
    await Promise.all([
      ...failed.map(entry => {
        entry.status = SyncStatus.QUEUED
        return tx.store.put(entry)
      }),
      tx.done,
    ])
    return failed.length
  },

  async pendingCount() {
    const db = await getDB()
    const queued     = await db.countFromIndex('sync_queue', 'by_status', SyncStatus.QUEUED)
    const processing = await db.countFromIndex('sync_queue', 'by_status', SyncStatus.PROCESSING)
    return queued + processing
  },

  async _updateStatus(id, status, extra = {}) {
    const db    = await getDB()
    const entry = await db.get('sync_queue', id)
    if (!entry) return
    Object.assign(entry, { status, ...extra })
    return db.put('sync_queue', entry)
  },
}
