/**
 * IndexedDB — Inventory Store
 *
 * Inventory is NEVER cached by the service worker.
 * This store holds a snapshot refreshed from the server on reconnect.
 * After every local sale, the snapshot is immediately updated here.
 *
 * VERSIONING:
 * Each stock row carries `server_version` (from the API response's
 * updated_at, used as an opaque version token) and `last_synced_at`
 * (when THIS device last refreshed the row from the server).
 * This distinguishes two different failure modes that plain quantity
 * comparison conflates:
 *   - "insufficient stock"  → the number itself is too low
 *   - "stale snapshot"      → the server has moved on (adjustment,
 *                             another device's sale) since we last
 *                             refreshed, even if our local number
 *                             still looks sufficient
 * A stale snapshot with a passing quantity check can still be wrong.
 */
import { getDB } from './schema'

const STALE_THRESHOLD_MS = 4 * 60 * 60 * 1000  // 4h — matches unsynced shift alert window

export const inventoryDB = {
  /**
   * Replace entire branch inventory snapshot (called on shift open or reconnect).
   * Stamps last_synced_at = now on every row so staleness can be measured
   * independently of any single item's last mutation time.
   */
  async bulkPut(stockItems) {
    const db  = await getDB()
    const now = new Date().toISOString()
    const tx  = db.transaction('inventory', 'readwrite')
    await Promise.all([
      ...stockItems.map(item => tx.store.put({
        ...item,
        server_version: item.updated_at || null,   // opaque token from API — not compared, only carried
        last_synced_at: now,
      })),
      tx.done,
    ])
  },

  async getStock(productId, branchId) {
    const db = await getDB()
    return db.getFromIndex('inventory', 'by_product_branch', [productId, branchId])
  },

  /** True if this row hasn't been refreshed from the server within the staleness window. */
  isStale(item) {
    if (!item?.last_synced_at) return true
    return (Date.now() - new Date(item.last_synced_at).getTime()) > STALE_THRESHOLD_MS
  },

  async deductStock(productId, branchId, quantityInStockUnit) {
    const db    = await getDB()
    const tx    = db.transaction('inventory', 'readwrite')
    const store = tx.objectStore('inventory')
    const idx   = store.index('by_product_branch')
    const item  = await idx.get([productId, branchId])

    if (!item) {
      await tx.done
      throw new Error(`No stock record for product ${productId} at branch ${branchId}`)
    }

    const currentQty  = parseFloat(item.quantity)
    const deductQty   = parseFloat(quantityInStockUnit)

    if (currentQty < deductQty) {
      await tx.done
      throw new Error('INSUFFICIENT_STOCK')
    }

    item.quantity = (currentQty - deductQty).toFixed(3)
    await store.put(item)
    await tx.done

    return item.quantity
  },

  async restoreStock(productId, branchId, quantityInStockUnit) {
    const db    = await getDB()
    const tx    = db.transaction('inventory', 'readwrite')
    const store = tx.objectStore('inventory')
    const item  = await store.index('by_product_branch').get([productId, branchId])
    if (item) {
      item.quantity = (parseFloat(item.quantity) + parseFloat(quantityInStockUnit)).toFixed(3)
      await store.put(item)
    }
    await tx.done
  },

  async getByBranch(branchId) {
    const db = await getDB()
    return db.getAllFromIndex('inventory', 'by_branch', branchId)
  },

  async getLowStock(branchId) {
    const items = await this.getByBranch(branchId)
    return items.filter(i => parseFloat(i.quantity) <= parseFloat(i.reorder_level || 0))
  },

  async clear() {
    const db = await getDB()
    return db.clear('inventory')
  },
}
