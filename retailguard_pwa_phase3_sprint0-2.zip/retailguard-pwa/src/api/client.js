/**
 * RetailGuard API Client
 * Token lives in memory only — never persisted.
 */
import axios from 'axios'

const BASE_URL = import.meta.env.VITE_API_BASE_URL || ''

let _accessToken  = null
let _isRefreshing = false
let _refreshQueue = []

export const tokenStore = {
  set(token)   { _accessToken = token },
  get()        { return _accessToken   },
  clear()      { _accessToken = null   },
  hasToken()   { return !!_accessToken },
}

export const apiClient = axios.create({
  baseURL: `${BASE_URL}/api/v1`,
  timeout: 15_000,
  headers: { 'Content-Type': 'application/json' },
})

apiClient.interceptors.request.use(config => {
  if (!navigator.onLine) {
    const err    = new Error('No network connection')
    err.code     = 'OFFLINE'
    err.isOffline = true
    return Promise.reject(err)
  }

  const token = tokenStore.get()
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }

  const fingerprint = sessionStorage.getItem('device_fingerprint')
  if (fingerprint) {
    config.headers['X-Device-Fingerprint'] = fingerprint
  }

  return config
})

apiClient.interceptors.response.use(
  response => response,
  async error => {
    const original = error.config

    if (
      error.response?.status === 401 &&
      !original._retry &&
      !original.url?.includes('/auth/refresh')
    ) {
      if (_isRefreshing) {
        return new Promise((resolve, reject) => {
          _refreshQueue.push({ resolve, reject, config: original })
        })
      }

      original._retry  = true
      _isRefreshing    = true

      try {
        const { data } = await axios.post(
          `${BASE_URL}/api/v1/auth/refresh/`,
          {},
          { withCredentials: true }
        )
        const newToken = data.data.access_token
        tokenStore.set(newToken)

        _refreshQueue.forEach(({ resolve, config }) => {
          config.headers.Authorization = `Bearer ${newToken}`
          resolve(apiClient(config))
        })
        _refreshQueue = []

        original.headers.Authorization = `Bearer ${newToken}`
        return apiClient(original)
      } catch (refreshErr) {
        tokenStore.clear()
        _refreshQueue.forEach(({ reject }) => reject(refreshErr))
        _refreshQueue = []
        window.dispatchEvent(new CustomEvent('auth:logout'))
        return Promise.reject(refreshErr)
      } finally {
        _isRefreshing = false
      }
    }

    return Promise.reject(error)
  }
)

export const authAPI = {
  login: (identifier, password, branchId, deviceFingerprint) =>
    apiClient.post('/auth/login/', {
      identifier,
      password,
      branch_id:          branchId  || undefined,
      device_fingerprint: deviceFingerprint || undefined,
    }),

  logout:   () => apiClient.post('/auth/logout/'),
  me:       () => apiClient.get('/auth/me/'),
  refresh:  () => axios.post(`${BASE_URL}/api/v1/auth/refresh/`, {}, { withCredentials: true }),

  terminalTakeover: (branchId, approvalMethod, credential, reason) =>
    apiClient.post('/auth/terminal/takeover/', {
      branch_id: branchId, approval_method: approvalMethod, credential, reason,
    }),
}

export const productsAPI = {
  list:   (params) => apiClient.get('/products/', { params }),
  getById: (id)   => apiClient.get(`/products/${id}/`),
}

export const inventoryAPI = {
  list: (params) => apiClient.get('/inventory/', { params }),
}

export const salesAPI = {
  create: (sale) => apiClient.post('/sales/', sale),
  syncBatch: (shiftId, sales) =>
    apiClient.post('/sales/sync/', { shift_id: shiftId, sales }),

  requestPriceOverride: (productId, branchId, requestedPrice, reason) =>
    apiClient.post('/sales/price-approvals/request/', {
      product_id: productId, branch_id: branchId,
      requested_price: requestedPrice, reason,
    }),

  approvePriceOverride: (approvalId, method, credential, approvedPrice) =>
    apiClient.post(`/sales/price-approvals/${approvalId}/approve/`, {
      approval_method: method, credential, approved_price: approvedPrice,
    }),

  confirmPayment: (paymentId, referenceNumber) =>
    apiClient.post(`/sales/payments/${paymentId}/confirm/`, {
      reference_number: referenceNumber,
    }),
}

export const shiftsAPI = {
  open:   (branchId, openingCash) =>
    apiClient.post('/shifts/open/', { branch_id: branchId, opening_cash: openingCash }),
  close:  (shiftId, actualCash, notes) =>
    apiClient.post(`/shifts/${shiftId}/close/`, { actual_cash: actualCash, notes }),
  active: () => apiClient.get('/shifts/active/'),
}

export const analyticsAPI = {
  daily:   (params) => apiClient.get('/analytics/daily/',   { params }),
  monthly: (params) => apiClient.get('/analytics/monthly/', { params }),
}

export const alertsAPI = {
  list:         (params) => apiClient.get('/alerts/',                 { params }),
  acknowledge:  (id)     => apiClient.post(`/alerts/${id}/acknowledge/`),
  resolve:      (id, notes) => apiClient.post(`/alerts/${id}/resolve/`, { resolution_notes: notes }),
}
