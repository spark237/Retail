/**
 * RetailGuard Layout Components
 */
import { Link, useLocation } from 'react-router-dom'
import { useAuthStore } from '../../store/authStore'
import { useShiftStore } from '../../store/shiftStore'
import { useSync } from '../../hooks/index'

export function ConnectivityBanner() {
  const { isOnline, pendingCount, isSyncing } = useSync()

  if (isOnline && pendingCount === 0) return null

  return (
    <div className={`px-4 py-2 text-center text-xs font-medium ${
      !isOnline
        ? 'bg-orange-900/80 text-orange-200'
        : 'bg-blue-900/80 text-blue-200'
    }`}>
      {!isOnline ? (
        <span>⚡ Offline mode — {pendingCount > 0 ? `${pendingCount} sale${pendingCount > 1 ? 's' : ''} queued` : 'Sales saved locally'}</span>
      ) : isSyncing ? (
        <span>↑ Syncing {pendingCount} record{pendingCount > 1 ? 's' : ''}…</span>
      ) : (
        <span>⏳ {pendingCount} pending sync</span>
      )}
    </div>
  )
}

export function TopBar({ title, rightAction, showBack = false, onBack }) {
  const user  = useAuthStore(s => s.user)
  const shift = useShiftStore(s => s.shift)

  return (
    <header className='bg-slate-900 border-b border-slate-800 px-4 py-3 flex items-center gap-3 sticky top-0 z-30'>
      {showBack && (
        <button onClick={onBack} className='text-slate-400 hover:text-white p-1 -ml-1'>
          <svg className='h-6 w-6' fill='none' viewBox='0 0 24 24' stroke='currentColor'>
            <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M15 19l-7-7 7-7' />
          </svg>
        </button>
      )}
      <div className='flex-1 min-w-0'>
        <h1 className='font-bold text-slate-100 text-lg leading-tight truncate'>{title}</h1>
        {user && shift && (
          <p className='text-xs text-slate-400 truncate'>{user.first_name} · {shift.branch_name || shift.branch_id}</p>
        )}
      </div>
      {rightAction}
    </header>
  )
}

const NAV_ITEMS = [
  { to: '/pos',       label: 'POS',       icon: '🛒', roles: ['owner', 'manager', 'cashier'] },
  { to: '/inventory', label: 'Stock',     icon: '📦', roles: ['owner', 'manager', 'cashier', 'warehouse_staff'] },
  { to: '/shifts',    label: 'Shift',     icon: '🕐', roles: ['owner', 'manager', 'cashier'] },
  { to: '/dashboard', label: 'Dashboard', icon: '📊', roles: ['owner', 'manager'] },
  { to: '/alerts',    label: 'Alerts',    icon: '🚨', roles: ['owner', 'manager'] },
]

export function BottomNav() {
  const location = useLocation()
  const user     = useAuthStore(s => s.user)
  const role     = user?.role || 'cashier'

  const items = NAV_ITEMS.filter(i => i.roles.includes(role))

  return (
    <nav className='fixed bottom-0 left-0 right-0 z-30 bg-slate-900 border-t border-slate-800 flex pb-safe'>
      {items.map(item => {
        const active = location.pathname.startsWith(item.to)
        return (
          <Link
            key={item.to}
            to={item.to}
            className={`relative flex-1 flex flex-col items-center justify-center py-2 gap-0.5 transition-colors ${
              active ? 'text-blue-400' : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            <span className='text-xl leading-none'>{item.icon}</span>
            <span className='text-[10px] font-medium leading-tight'>{item.label}</span>
            {active && <span className='absolute bottom-0 h-0.5 w-8 bg-blue-400 rounded-full' />}
          </Link>
        )
      })}
    </nav>
  )
}

export function AppShell({ children, title, rightAction, showBack = false, onBack, hideNav = false }) {
  return (
    <div className='min-h-screen bg-slate-950 text-slate-100 flex flex-col'>
      <ConnectivityBanner />
      <TopBar title={title} rightAction={rightAction} showBack={showBack} onBack={onBack} />
      <main className={`flex-1 overflow-y-auto ${hideNav ? 'pb-4' : 'pb-20'}`}>
        {children}
      </main>
      {!hideNav && <BottomNav />}
    </div>
  )
}
