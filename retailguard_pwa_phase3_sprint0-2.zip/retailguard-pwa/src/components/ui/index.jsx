/**
 * RetailGuard UI Primitives
 * Mobile-first. Minimum touch target: 48px on interactive elements.
 */

export function Button({
  children, onClick, variant = 'primary', size = 'md',
  disabled = false, loading = false, className = '', type = 'button', fullWidth = false,
}) {
  const base = 'inline-flex items-center justify-center font-semibold rounded-xl transition-all active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed select-none'

  const variants = {
    primary:   'bg-blue-600 text-white hover:bg-blue-700 active:bg-blue-800',
    secondary: 'bg-slate-700 text-white hover:bg-slate-600',
    danger:    'bg-red-600 text-white hover:bg-red-700',
    success:   'bg-emerald-600 text-white hover:bg-emerald-700',
    ghost:     'bg-transparent text-slate-300 hover:bg-slate-800',
    outline:   'border border-slate-600 text-slate-200 hover:bg-slate-800',
    warning:   'bg-amber-500 text-white hover:bg-amber-600',
  }

  const sizes = {
    sm:   'h-10 px-4 text-sm gap-1.5',
    md:   'h-12 px-5 text-base gap-2',
    lg:   'h-14 px-6 text-lg gap-2',
    xl:   'h-16 px-8 text-xl gap-3',
    icon: 'h-12 w-12 p-0',
  }

  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled || loading}
      className={`${base} ${variants[variant]} ${sizes[size]} ${fullWidth ? 'w-full' : ''} ${className}`}
    >
      {loading ? <Spinner size='sm' /> : children}
    </button>
  )
}

export function Input({
  label, value, onChange, placeholder = '', type = 'text',
  error, className = '', inputMode, autoFocus, readOnly,
  prefix, suffix, onFocus, onBlur,
}) {
  return (
    <div className={`flex flex-col gap-1.5 ${className}`}>
      {label && <label className='text-sm font-medium text-slate-300'>{label}</label>}
      <div className='relative flex items-center'>
        {prefix && (
          <span className='absolute left-3 text-slate-400 text-sm select-none'>{prefix}</span>
        )}
        <input
          type={type}
          value={value}
          onChange={e => onChange?.(e.target.value)}
          placeholder={placeholder}
          inputMode={inputMode}
          autoFocus={autoFocus}
          readOnly={readOnly}
          onFocus={onFocus}
          onBlur={onBlur}
          className={`
            w-full h-12 rounded-xl bg-slate-800 border text-slate-100 placeholder-slate-500
            ${error ? 'border-red-500' : 'border-slate-700 focus:border-blue-500'}
            focus:outline-none focus:ring-1 focus:ring-blue-500
            transition-colors
            ${prefix ? 'pl-10' : 'pl-4'}
            ${suffix ? 'pr-10' : 'pr-4'}
          `}
        />
        {suffix && (
          <span className='absolute right-3 text-slate-400 text-sm select-none'>{suffix}</span>
        )}
      </div>
      {error && <p className='text-red-400 text-xs'>{error}</p>}
    </div>
  )
}

export function Badge({ children, variant = 'default', className = '' }) {
  const variants = {
    default:  'bg-slate-700 text-slate-300',
    primary:  'bg-blue-900 text-blue-300',
    success:  'bg-emerald-900 text-emerald-300',
    warning:  'bg-amber-900 text-amber-300',
    danger:   'bg-red-900 text-red-300',
    critical: 'bg-red-700 text-white',
    pending:  'bg-orange-900 text-orange-300',
    synced:   'bg-emerald-900 text-emerald-400',
  }
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${variants[variant]} ${className}`}>
      {children}
    </span>
  )
}

export function Spinner({ size = 'md', className = '' }) {
  const sizes = { sm: 'h-4 w-4', md: 'h-6 w-6', lg: 'h-8 w-8', xl: 'h-12 w-12' }
  return (
    <div className={`${sizes[size]} ${className} animate-spin rounded-full border-2 border-slate-600 border-t-blue-500`} />
  )
}

export function Modal({ isOpen, onClose, title, children, size = 'md' }) {
  if (!isOpen) return null
  const sizes = { sm: 'max-w-sm', md: 'max-w-md', lg: 'max-w-lg', full: 'max-w-full mx-0 mb-0 rounded-b-none' }
  return (
    <div className='fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4'>
      <div className='absolute inset-0 bg-black/70 backdrop-blur-sm' onClick={onClose} />
      <div className={`relative w-full ${sizes[size]} bg-slate-900 rounded-t-2xl sm:rounded-2xl border border-slate-700 shadow-2xl`}>
        {title && (
          <div className='flex items-center justify-between px-5 pt-5 pb-3 border-b border-slate-800'>
            <h2 className='text-lg font-semibold text-slate-100'>{title}</h2>
            <button onClick={onClose} className='text-slate-400 hover:text-slate-200 p-1'>
              <svg className='h-5 w-5' fill='none' viewBox='0 0 24 24' stroke='currentColor'>
                <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M6 18L18 6M6 6l12 12' />
              </svg>
            </button>
          </div>
        )}
        <div className='px-5 py-4'>{children}</div>
      </div>
    </div>
  )
}

export function Alert({ variant = 'info', title, children, className = '' }) {
  const variants = {
    info:    'bg-blue-950 border-blue-800 text-blue-200',
    success: 'bg-emerald-950 border-emerald-800 text-emerald-200',
    warning: 'bg-amber-950 border-amber-800 text-amber-200',
    danger:  'bg-red-950 border-red-800 text-red-200',
  }
  return (
    <div className={`rounded-xl border p-4 ${variants[variant]} ${className}`}>
      {title && <p className='font-semibold mb-1'>{title}</p>}
      <div className='text-sm opacity-90'>{children}</div>
    </div>
  )
}

export function Card({ children, className = '', onClick, padding = true }) {
  return (
    <div
      onClick={onClick}
      className={`bg-slate-800 border border-slate-700 rounded-2xl ${padding ? 'p-4' : ''} ${onClick ? 'cursor-pointer active:scale-98 hover:border-slate-600 transition-all' : ''} ${className}`}
    >
      {children}
    </div>
  )
}

export function Divider({ className = '' }) {
  return <hr className={`border-slate-700 ${className}`} />
}

export function EmptyState({ icon, title, message, action }) {
  return (
    <div className='flex flex-col items-center justify-center py-16 px-6 text-center'>
      {icon && <div className='text-5xl mb-4'>{icon}</div>}
      <h3 className='text-lg font-semibold text-slate-200 mb-2'>{title}</h3>
      {message && <p className='text-slate-400 text-sm mb-6'>{message}</p>}
      {action}
    </div>
  )
}
