/**
 * RetailGuard — Cart Drawer (POS)
 * Bottom sheet showing current cart items. Tap to expand to full checkout.
 */
import { Badge } from '../ui'
import { formatXAFShort } from '../../utils/currency'
import { unitLabel } from '../../utils/units'

export function CartBar({ itemCount, total, onOpen }) {
  if (itemCount === 0) return null

  return (
    <button
      onClick={onOpen}
      className='fixed bottom-20 left-4 right-4 z-20 bg-blue-600 hover:bg-blue-700 active:scale-98 transition-all rounded-2xl px-5 py-4 flex items-center justify-between shadow-2xl shadow-blue-950/50'
    >
      <div className='flex items-center gap-3'>
        <span className='bg-white/20 rounded-full h-8 w-8 flex items-center justify-center font-bold text-white text-sm'>
          {itemCount}
        </span>
        <span className='text-white font-semibold'>View Cart</span>
      </div>
      <span className='text-white font-bold text-lg'>{formatXAFShort(total)}</span>
    </button>
  )
}

export function CartItemRow({ item, onRemove, onEdit }) {
  return (
    <div className='flex items-center justify-between py-3 border-b border-slate-800 last:border-0'>
      <div className='flex-1 min-w-0'>
        <p className='font-medium text-slate-100 text-sm truncate'>{item.product_name}</p>
        <div className='flex items-center gap-2 mt-0.5'>
          <span className='text-xs text-slate-400'>
            {item.quantity_sold} {unitLabel(item.unit_sold)}
          </span>
          {item.is_price_override && <Badge variant='warning'>Override</Badge>}
        </div>
      </div>
      <div className='flex items-center gap-3'>
        <span className='font-semibold text-slate-100'>{formatXAFShort(item.total_price)}</span>
        <button
          onClick={() => onRemove(item.id)}
          className='text-slate-500 hover:text-red-400 p-1'
        >
          <svg className='h-5 w-5' fill='none' viewBox='0 0 24 24' stroke='currentColor'>
            <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16' />
          </svg>
        </button>
      </div>
    </div>
  )
}
