/**
 * RetailGuard — Product Grid (POS)
 * Tap-to-add product cards optimised for phone thumb zones.
 */
import { Card, Badge } from '../ui'
import { formatXAFShort } from '../../utils/currency'

export function ProductGrid({ products, onSelect, stockMap }) {
  if (products.length === 0) {
    return (
      <div className='flex items-center justify-center py-12 text-slate-500 text-sm'>
        No products found
      </div>
    )
  }

  return (
    <div className='grid grid-cols-2 gap-3 p-4'>
      {products.map(product => {
        const stock = stockMap?.[product.id]
        const qty   = stock ? parseFloat(stock.quantity) : null
        const isLow = qty !== null && qty <= parseFloat(product.reorder_level || 0)
        const isOut = qty !== null && qty <= 0

        return (
          <Card
            key={product.id}
            onClick={() => !isOut && onSelect(product)}
            className={`flex flex-col gap-2 ${isOut ? 'opacity-50' : ''}`}
          >
            <div className='flex items-start justify-between gap-2'>
              <p className='font-semibold text-sm text-slate-100 leading-tight line-clamp-2'>
                {product.name}
              </p>
              {product.tile_size && (
                <Badge variant='default' className='shrink-0'>{product.tile_size}</Badge>
              )}
            </div>

            {product.color_description && (
              <p className='text-xs text-slate-400'>{product.color_description}</p>
            )}

            <div className='flex items-center justify-between mt-auto pt-2'>
              <p className='font-bold text-blue-400'>{formatXAFShort(product.selling_price)}</p>
              {qty !== null && (
                <Badge variant={isOut ? 'danger' : isLow ? 'warning' : 'default'}>
                  {isOut ? 'Out' : `${qty} ${product.stock_unit}`}
                </Badge>
              )}
            </div>
          </Card>
        )
      })}
    </div>
  )
}
