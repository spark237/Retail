/**
 * RetailGuard — Payment Selector (POS Checkout)
 * Supports split payments across CASH / MTN_MOMO / ORANGE_MONEY / BANK_TRANSFER.
 * Non-cash payments require a reference number before confirmation
 * (server enforces PAYMENT_UNCONFIRMED rejection if missing).
 */
import { useState } from 'react'
import { Button, Input, Badge } from '../ui'
import { formatXAFShort, computeChange } from '../../utils/currency'

const METHODS = [
  { value: 'CASH',          label: 'Cash',         icon: '💵' },
  { value: 'MTN_MOMO',      label: 'MTN MoMo',     icon: '📱' },
  { value: 'ORANGE_MONEY',  label: 'Orange Money', icon: '🟠' },
  { value: 'BANK_TRANSFER', label: 'Bank Transfer', icon: '🏦' },
]

export function PaymentSelector({ total, payments, onChange }) {
  const [activeMethod, setActiveMethod] = useState('CASH')
  const [amount, setAmount]             = useState('')
  const [reference, setReference]       = useState('')

  const paidSoFar   = payments.reduce((s, p) => s + parseInt(p.amount || 0), 0)
  const remaining   = total - paidSoFar

  function addPayment() {
    const amt = parseInt(amount)
    if (!amt || amt <= 0) return
    if (activeMethod !== 'CASH' && !reference.trim()) return

    onChange([
      ...payments,
      { method: activeMethod, amount: amt, reference: reference.trim() || null },
    ])
    setAmount('')
    setReference('')
  }

  function removePayment(idx) {
    onChange(payments.filter((_, i) => i !== idx))
  }

  function fillRemaining() {
    setAmount(String(Math.max(remaining, 0)))
  }

  return (
    <div className='flex flex-col gap-4'>
      {/* Method tabs */}
      <div className='grid grid-cols-4 gap-2'>
        {METHODS.map(m => (
          <button
            key={m.value}
            onClick={() => setActiveMethod(m.value)}
            className={`flex flex-col items-center gap-1 py-2 rounded-xl text-xs font-medium transition-colors ${
              activeMethod === m.value
                ? 'bg-blue-600 text-white'
                : 'bg-slate-800 text-slate-400 border border-slate-700'
            }`}
          >
            <span className='text-lg'>{m.icon}</span>
            {m.label}
          </button>
        ))}
      </div>

      {/* Amount + reference input */}
      <div className='flex flex-col gap-3'>
        <div className='flex gap-2'>
          <Input
            value={amount}
            onChange={setAmount}
            placeholder='Amount'
            inputMode='numeric'
            suffix='XAF'
            className='flex-1'
          />
          <Button variant='outline' size='md' onClick={fillRemaining}>Full</Button>
        </div>

        {activeMethod !== 'CASH' && (
          <Input
            value={reference}
            onChange={setReference}
            placeholder='Transaction reference number'
            label='Reference (required)'
          />
        )}

        <Button
          variant='secondary'
          onClick={addPayment}
          disabled={!amount || (activeMethod !== 'CASH' && !reference.trim())}
        >
          + Add Payment
        </Button>
      </div>

      {/* Payment list */}
      {payments.length > 0 && (
        <div className='flex flex-col gap-2 border-t border-slate-800 pt-3'>
          {payments.map((p, idx) => (
            <div key={idx} className='flex items-center justify-between bg-slate-800/60 rounded-lg px-3 py-2'>
              <div>
                <span className='text-sm font-medium text-slate-200'>
                  {METHODS.find(m => m.value === p.method)?.label}
                </span>
                {p.reference && (
                  <span className='text-xs text-slate-500 ml-2'>#{p.reference}</span>
                )}
                {p.method !== 'CASH' && (
                  <Badge variant='pending' className='ml-2'>Unconfirmed</Badge>
                )}
              </div>
              <div className='flex items-center gap-2'>
                <span className='font-semibold text-slate-100'>{formatXAFShort(p.amount)}</span>
                <button onClick={() => removePayment(idx)} className='text-slate-500 hover:text-red-400'>×</button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Summary */}
      <div className='flex items-center justify-between pt-3 border-t border-slate-800'>
        <span className='text-slate-400 text-sm'>Remaining</span>
        <span className={`font-bold text-lg ${remaining === 0 ? 'text-emerald-400' : remaining < 0 ? 'text-red-400' : 'text-amber-400'}`}>
          {formatXAFShort(remaining)}
        </span>
      </div>
    </div>
  )
}
