/**
 * RetailGuard — Quantity Picker Modal
 * Cashier selects unit (PIECE/BOX/SQM/PALLET) and quantity before adding to cart.
 * Shows live stock-unit conversion so cashier sees exactly what will be deducted.
 */
import { useState, useMemo } from 'react'
import { Modal, Button, Input, Badge } from '../ui'
import { formatXAFShort } from '../../utils/currency'
import { convertToStockUnit, computeTotalPrice, availableUnits, unitLabel } from '../../utils/units'

export function QuantityPickerModal({ product, isOpen, onClose, onConfirm, availableStock }) {
  const units = useMemo(() => (product ? availableUnits(product) : []), [product])
  const [unit, setUnit]         = useState(units[0] || 'BOX')
  const [quantity, setQuantity] = useState('1')
  const [error, setError]       = useState('')

  if (!product) return null

  // Recompute derived values whenever unit/quantity changes
  let qtyInStockUnit = 0
  let totalPrice     = 0
  let conversionError = null

  try {
    qtyInStockUnit = convertToStockUnit(quantity || '0', unit, product)
    totalPrice     = computeTotalPrice(product.selling_price, qtyInStockUnit)
  } catch (err) {
    conversionError = err.message
  }

  const stockAvailable  = availableStock !== undefined ? parseFloat(availableStock) : null
  const exceedsStock    = stockAvailable !== null && qtyInStockUnit > stockAvailable

  function handleConfirm() {
    const qty = parseFloat(quantity)
    if (!qty || qty <= 0) {
      setError('Enter a valid quantity')
      return
    }
    if (exceedsStock) {
      setError(`Only ${stockAvailable} ${product.stock_unit} available`)
      return
    }
    onConfirm(product, qty, unit)
    setQuantity('1')
    setError('')
    onClose()
  }

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={product.name} size='md'>
      <div className='flex flex-col gap-4'>
        {product.tile_size && (
          <p className='text-sm text-slate-400'>
            {product.tile_size} · {product.tile_finish} · {product.color_description}
          </p>
        )}

        {/* Unit selector */}
        {units.length > 1 && (
          <div className='flex gap-2'>
            {units.map(u => (
              <button
                key={u}
                onClick={() => setUnit(u)}
                className={`flex-1 h-11 rounded-xl text-sm font-medium transition-colors ${
                  unit === u
                    ? 'bg-blue-600 text-white'
                    : 'bg-slate-800 text-slate-300 border border-slate-700'
                }`}
              >
                {unitLabel(u)}
              </button>
            ))}
          </div>
        )}

        {/* Quantity input */}
        <Input
          label={`Quantity (${unitLabel(unit)})`}
          value={quantity}
          onChange={setQuantity}
          inputMode='decimal'
          type='text'
          autoFocus
          error={error}
        />

        {/* Conversion preview */}
        {!conversionError && unit !== product.stock_unit && (
          <div className='bg-slate-800/60 rounded-lg px-3 py-2 text-xs text-slate-400'>
            = {qtyInStockUnit} {product.stock_unit} (deducted from stock)
          </div>
        )}

        {conversionError && (
          <p className='text-red-400 text-xs'>{conversionError}</p>
        )}

        {exceedsStock && (
          <p className='text-amber-400 text-xs'>
            ⚠ Only {stockAvailable} {product.stock_unit} available
          </p>
        )}

        {/* Price preview */}
        <div className='flex items-center justify-between pt-2 border-t border-slate-800'>
          <span className='text-slate-400 text-sm'>Total</span>
          <span className='text-xl font-bold text-blue-400'>{formatXAFShort(totalPrice)}</span>
        </div>

        <div className='flex gap-3 pt-2'>
          <Button variant='outline' onClick={onClose} fullWidth>Cancel</Button>
          <Button
            variant='primary'
            onClick={handleConfirm}
            fullWidth
            disabled={!!conversionError || exceedsStock}
          >
            Add to Cart
          </Button>
        </div>
      </div>
    </Modal>
  )
}
