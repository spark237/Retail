/**
 * RetailGuard — Route Guards
 */
import { Navigate } from 'react-router-dom'
import { useAuthStore } from '../store/authStore'
import { useShiftStore } from '../store/shiftStore'
import { Spinner } from './ui'

export function RequireAuth({ children }) {
  const isLoggedIn = useAuthStore(s => s.isLoggedIn)
  const isLoading  = useAuthStore(s => s.isLoading)

  if (isLoading) {
    return (
      <div className='min-h-screen bg-slate-950 flex items-center justify-center'>
        <Spinner size='xl' />
      </div>
    )
  }

  if (!isLoggedIn) return <Navigate to='/login' replace />
  return children
}

export function RequireShift({ children }) {
  const shift = useShiftStore(s => s.shift)
  if (!shift || shift.status !== 'open') {
    return <Navigate to='/shift/open' replace />
  }
  return children
}

export function RequireRole({ roles, children }) {
  const user = useAuthStore(s => s.user)
  if (!user || !roles.includes(user.role)) {
    return <Navigate to='/pos' replace />
  }
  return children
}
