/**
 * RetailGuard — Vitest Configuration
 *
 * Deliberately separate from vite.config.js: the VitePWA plugin
 * generates a service worker at build time and has no business
 * running inside a test environment. Merging configs would mean
 * every test run either triggers SW generation or requires excluding
 * the plugin conditionally — a separate config is simpler and safer.
 */
import { defineConfig } from 'vitest/config'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  test: {
    environment: 'jsdom',
    setupFiles: ['./tests/setup/global.js'],
    globals: true,
    css: false,
    // Failure-mode tests intentionally use real timers in places (backoff
    // delays, staleness windows) — see individual test files for where
    // vi.useFakeTimers() is scoped locally instead of globally.
    testTimeout: 10_000,
    include: ['tests/**/*.test.js'],
    coverage: {
      provider: 'v8',
      reporter: ['text', 'html', 'lcov'],
      reportsDirectory: './coverage',
      include: ['src/**/*.{js,jsx}'],
      exclude: [
        'src/main.jsx',
        '**/*.config.js',
      ],
    },
  },
})
