/**
 * RetailGuard — Global Test Setup
 *
 * fake-indexeddb provides REAL IndexedDB transaction/index/constraint
 * semantics in Node — not a mock that just returns fixture data. This
 * matters specifically for failure-mode testing: a mock IDB would let
 * broken transaction logic pass silently. fake-indexeddb enforces the
 * same atomicity and index-uniqueness rules a real browser would.
 */
import 'fake-indexeddb/auto'
import { beforeEach, afterEach, vi } from 'vitest'
import '@testing-library/jest-dom/vitest'

// ─── navigator.onLine control ────────────────────────────────────────────
// jsdom's navigator.onLine is read-only by default. Tests that simulate
// connectivity flapping need to flip it and fire the matching window event,
// exactly as SyncManager listens for in production.
Object.defineProperty(window.navigator, 'onLine', {
  writable: true,
  configurable: true,
  value: true,
})

export function setOnline(isOnline) {
  Object.defineProperty(window.navigator, 'onLine', {
    writable: true,
    configurable: true,
    value: isOnline,
  })
  window.dispatchEvent(new Event(isOnline ? 'online' : 'offline'))
}

// ─── Fresh IndexedDB per test ────────────────────────────────────────────
// Without this, test N's data leaks into test N+1 because fake-indexeddb
// persists for the life of the Node process, not per-test like a real
// browser tab would reset on reload. This is the single most important
// line in this file — omitting it produces tests that pass in isolation
// and fail in a full run, for reasons that look like flakiness but aren't.
beforeEach(async () => {
  const databases = await indexedDB.databases()
  await Promise.all(
    databases.map(
      db =>
        new Promise((resolve, reject) => {
          const req = indexedDB.deleteDatabase(db.name)
          req.onsuccess = resolve
          req.onerror = reject
          req.onblocked = resolve  // don't hang the suite on a stray open handle
        })
    )
  )
  // Force schema.js to re-open a fresh connection next call
  vi.resetModules()
})

afterEach(() => {
  vi.restoreAllMocks()
  setOnline(true)
})
