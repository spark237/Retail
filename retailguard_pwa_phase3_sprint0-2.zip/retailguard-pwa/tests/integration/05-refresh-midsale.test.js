/**
 * FAILURE MODE 5 — Browser refresh mid-sale
 *
 * Real-world trigger: cashier has items in the cart, hasn't checked out
 * yet, and the browser reloads — accidental refresh, PWA update prompt,
 * OS killing a backgrounded tab to reclaim memory. All in-memory Zustand
 * state is gone the instant that happens; nothing survives except what
 * was actually written to IndexedDB.
 *
 * What must hold:
 *  1. Every cart mutation (addItem, removeItem, updateItemQuantity,
 *     setPaymentMethod, setPayments, setNotes) persists to IndexedDB
 *     synchronously with the in-memory state change — not batched,
 *     not debounced, not "eventually".
 *  2. A fresh store instance (simulating the post-reload app) can
 *     fully reconstruct the cart via hydrate() alone.
 *  3. Partially-entered payment info survives the same way as items —
 *     a cashier who'd already selected MTN_MOMO and typed a reference
 *     number shouldn't have to redo that after a refresh.
 *  4. After a successful commit, the persisted cart is actually cleared
 *     — a REAL reload after checkout must not resurrect the old cart.
 */
import { describe, it, expect, vi, beforeEach } from 'vitest'
import { useCartStore } from '../../src/store/cartStore'
import { getDB } from '../../src/db/schema'
import { makeProduct, makeCashier } from '../helpers/fixtures'
import { inventoryDB } from '../../src/db/inventory'

vi.mock('../../src/api/client', () => ({
  apiClient: { post: vi.fn(), get: vi.fn() },
}))

import { SyncManager } from '../../src/sync/SyncManager'

const product = makeProduct({ id: 'prod-tile' })
const cashier = makeCashier()

/** Simulates "the page reloaded": wipes in-memory state but leaves IndexedDB untouched. */
function simulateReload() {
  useCartStore.setState({
    items: [], paymentMethod: 'CASH', payments: [], notes: '', discountAmount: 0,
    isCommitting: false, lastReceipt: null, error: null,
  })
}

describe('Failure mode: browser refresh mid-sale', () => {
  beforeEach(async () => {
    vi.clearAllMocks()
    Object.defineProperty(window.navigator, 'onLine', { writable: true, value: true })
    simulateReload()
  })

  it('persists an added item to IndexedDB immediately, before any explicit save', async () => {
    await useCartStore.getState().addItem(product, 2, 'BOX')

    const db = await getDB()
    const persisted = await db.get('settings', 'active_cart')

    expect(persisted).toBeDefined()
    expect(persisted.cart.items).toHaveLength(1)
    expect(persisted.cart.items[0].product_id).toBe('prod-tile')
    expect(persisted.cart.items[0].quantity_sold).toBe('2')
  })

  it('fully reconstructs the cart after a simulated reload via hydrate()', async () => {
    await useCartStore.getState().addItem(product, 3, 'SQM')
    await useCartStore.getState().setNotes('Customer wants matching grout')

    simulateReload()
    expect(useCartStore.getState().items).toHaveLength(0)  // confirm in-memory state really was wiped

    await useCartStore.getState().hydrate()

    const state = useCartStore.getState()
    expect(state.items).toHaveLength(1)
    expect(state.items[0].unit_sold).toBe('SQM')
    expect(state.notes).toBe('Customer wants matching grout')
  })

  it('survives a refresh after removing an item (not just after adding one)', async () => {
    const productB = makeProduct({ id: 'prod-tile-b', name: 'Second Tile' })
    await useCartStore.getState().addItem(product, 2, 'BOX')
    await useCartStore.getState().addItem(productB, 1, 'BOX')

    const items = useCartStore.getState().items
    await useCartStore.getState().removeItem(items[0].id)

    simulateReload()
    await useCartStore.getState().hydrate()

    const state = useCartStore.getState()
    expect(state.items).toHaveLength(1)
    expect(state.items[0].product_id).toBe('prod-tile-b')
  })

  it('preserves partially-entered payment info (method + reference) across reload', async () => {
    await useCartStore.getState().addItem(product, 1, 'BOX')
    await useCartStore.getState().setPaymentMethod('MTN_MOMO')
    await useCartStore.getState().setPayments([
      { method: 'MTN_MOMO', amount: 12000, reference: 'MM20260713998877' },
    ])

    simulateReload()
    await useCartStore.getState().hydrate()

    const state = useCartStore.getState()
    expect(state.paymentMethod).toBe('MTN_MOMO')
    expect(state.payments).toHaveLength(1)
    expect(state.payments[0].reference).toBe('MM20260713998877')
  })

  it('clears the persisted cart after a successful commit — a real reload must not resurrect it', async () => {
    await inventoryDB.bulkPut([{ id: 'stock-x', product_id: 'prod-tile', branch_id: 'branch-1', quantity: '10.000' }])
    await useCartStore.getState().addItem(product, 1, 'BOX')

    const flushStub = vi.spyOn(SyncManager, 'flush').mockResolvedValue(undefined)
    const result = await useCartStore.getState().commitSale({ shiftId: 'shift-1', branchId: 'branch-1', cashier })
    flushStub.mockRestore()
    expect(result.success).toBe(true)

    simulateReload()
    await useCartStore.getState().hydrate()

    expect(useCartStore.getState().items).toHaveLength(0)

    const db = await getDB()
    const persisted = await db.get('settings', 'active_cart')
    expect(persisted).toBeUndefined()
  })

  it('does NOT resurrect a stale cart if hydrate() is never called (no silent auto-restore)', async () => {
    await useCartStore.getState().addItem(product, 1, 'BOX')
    simulateReload()
    // Deliberately not calling hydrate() — a fresh screen mount that
    // doesn't invoke it should show an empty cart, not a hidden restore.
    expect(useCartStore.getState().items).toHaveLength(0)
  })
})
