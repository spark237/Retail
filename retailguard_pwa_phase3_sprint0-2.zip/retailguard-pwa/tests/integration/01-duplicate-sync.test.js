/**
 * FAILURE MODE 1 — Duplicate sync
 *
 * Real-world trigger: cashier's device sends a sale, the server accepts
 * it and writes it to the database, but the response never makes it back
 * (connection drops mid-response, timeout, tab backgrounded by the OS).
 * The client still has the entry in sync_queue as unconfirmed and will
 * retry it — potentially selling the same tiles twice if the server
 * blindly re-processed the request.
 *
 * What must hold: the server's UUID-based idempotency (documented in
 * SaleService.create_sale on the backend) returns 409 with the original
 * receipt on a duplicate, and the CLIENT must treat that as success —
 * not as a failure to retry again, and not as data loss.
 */
import { describe, it, expect, vi, beforeEach } from 'vitest'
import { syncQueueDB, SyncStatus, EntityType } from '../../src/db/syncQueue'
import { salesDB } from '../../src/db/sales'
import { conflictResponse, networkError } from '../helpers/fixtures'

vi.mock('../../src/api/client', () => ({
  apiClient: { post: vi.fn(), get: vi.fn() },
}))

import { apiClient } from '../../src/api/client'
import { SyncManager } from '../../src/sync/SyncManager'

describe('Failure mode: duplicate sync (lost response, retried request)', () => {
  const saleId = 'sale-dup-1'

  beforeEach(async () => {
    vi.clearAllMocks()
    Object.defineProperty(window.navigator, 'onLine', { writable: true, value: true })

    // Sale already exists locally as 'pending' — as it would after the
    // original commitSale() wrote it, before the (lost) server response.
    await salesDB.put({
      id: saleId,
      shift_id: 'shift-1',
      branch_id: 'branch-1',
      cashier_id: 'user-1',
      subtotal: 60000,
      discount_amount: 0,
      total_amount: 60000,
      status: 'completed',
      sync_status: 'pending',
      receipt_number: null,
      created_at_device: new Date().toISOString(),
    })

    await syncQueueDB.enqueue({
      entityType: EntityType.SALE,
      entityId: saleId,
      operation: 'create',
      payload: { id: saleId, shift_id: 'shift-1', created_at_device: new Date().toISOString(), items: [], payments: [] },
    })
  })

  it('treats a 409 duplicate response as success, not a failure to retry', async () => {
    // Server says: "I already have this sale" — this IS the correct,
    // expected response for a retried request, not an error condition.
    apiClient.post.mockRejectedValueOnce(conflictResponse(saleId, 'RCP-BR001-20260627-0099'))

    await SyncManager.flush()

    const sale = await salesDB.getById(saleId)
    expect(sale.sync_status).toBe('synced')
    expect(sale.receipt_number).toBe('RCP-BR001-20260627-0099')

    const queue = await syncQueueDB.getAll()
    expect(queue[0].status).toBe(SyncStatus.COMPLETED)
    // Critically: NOT 'failed' — a duplicate is not a retriable error,
    // and marking it failed would cause an infinite retry loop against
    // a sale the server has already permanently recorded.
    expect(queue[0].status).not.toBe(SyncStatus.FAILED)
  })

  it('does not re-post the sale a second time after the 409 resolves it', async () => {
    apiClient.post.mockRejectedValueOnce(conflictResponse(saleId, 'RCP-BR001-20260627-0099'))
    await SyncManager.flush()
    expect(apiClient.post).toHaveBeenCalledTimes(1)

    // Simulate a second flush cycle (e.g. the 30s poll interval firing again).
    // A completed queue entry must never be picked up by getQueued() again.
    await SyncManager.flush()
    expect(apiClient.post).toHaveBeenCalledTimes(1)  // still 1 — not re-sent
  })

  it('distinguishes a genuine 409 duplicate from an unrelated network drop', async () => {
    // A bare network error (no response at all) must NOT be treated as
    // "already synced" — that would silently discard a sale that was
    // never actually received by the server.
    apiClient.post.mockRejectedValueOnce(networkError())

    await SyncManager.flush()

    const sale = await salesDB.getById(saleId)
    expect(sale.sync_status).toBe('pending')  // unchanged — correctly NOT marked synced

    const queue = await syncQueueDB.getAll()
    expect(queue[0].status).toBe(SyncStatus.FAILED)
    expect(queue[0].retry_count).toBe(1)
  })
})
