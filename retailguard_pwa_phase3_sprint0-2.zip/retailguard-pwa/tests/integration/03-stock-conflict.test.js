/**
 * FAILURE MODE 3 — Stock conflict from concurrent offline devices
 *
 * Real-world trigger: Branch has 5 boxes of a tile in stock. Two cashiers
 * on two separate phones both go offline. Device A sells 3 boxes; Device B
 * (unaware of A's sale) also sells 3 boxes against its own last-known
 * snapshot of 5. Both devices think their sale is valid. When they both
 * reconnect, the server — which processes sales strictly in arrival order
 * and holds the real SELECT FOR UPDATE lock — can only honor one of them.
 *
 * What must hold on THIS device (we can only test one client's behavior;
 * the other device is simulated by mocking what the server tells us):
 *  1. Client-side stock check correctly prevents overselling against its
 *     OWN local snapshot (the easy, expected case).
 *  2. When the SERVER rejects a queued sale as 422 INSUFFICIENT_STOCK
 *     (because the other device's sale landed first), the local sale
 *     record is marked 'conflict' — NOT silently retried forever, and
 *     NOT silently marked 'synced'. A shortage must surface, not vanish.
 *  3. After the conflict, refreshing the inventory snapshot from the
 *     server must overwrite the stale local number with server truth.
 */
import { describe, it, expect, vi, beforeEach } from 'vitest'
import { syncQueueDB, SyncStatus, EntityType } from '../../src/db/syncQueue'
import { salesDB } from '../../src/db/sales'
import { inventoryDB } from '../../src/db/inventory'
import { useCartStore } from '../../src/store/cartStore'
import { makeProduct, makeStock, makeCashier, insufficientStockError } from '../helpers/fixtures'

vi.mock('../../src/api/client', () => ({
  apiClient: { post: vi.fn(), get: vi.fn() },
}))

import { apiClient } from '../../src/api/client'
import { SyncManager } from '../../src/sync/SyncManager'

const product = makeProduct({ id: 'prod-tile', stock_unit: 'BOX' })
const cashier = makeCashier()

describe('Failure mode: concurrent stock conflict', () => {
  beforeEach(async () => {
    vi.clearAllMocks()
    Object.defineProperty(window.navigator, 'onLine', { writable: true, value: true })
    await inventoryDB.bulkPut([makeStock({ product_id: 'prod-tile', branch_id: 'branch-1', quantity: '5.000' })])
    useCartStore.setState({ items: [], payments: [], paymentMethod: 'CASH', notes: '', discountAmount: 0, error: null, lastReceipt: null })
  })

  it('prevents overselling against this device\'s own local snapshot', async () => {
    const store = useCartStore.getState()
    await store.addItem(product, 3, 'BOX')      // Device A sells 3 of its known 5 — fine
    await useCartStore.getState().addItem(product, 3, 'BOX')  // tries 3 more — 6 total, only 5 exist

    // addItem merges same-product lines, so cart now shows 6 BOX requested
    // against 5 in the local snapshot. commitSale must reject BEFORE
    // touching sales/sale_items/inventory tables — no partial writes.
    const result = await useCartStore.getState().commitSale({
      shiftId: 'shift-1', branchId: 'branch-1', cashier,
    })

    expect(result.success).toBe(false)
    expect(result.error).toBe('INSUFFICIENT_STOCK')
    expect(result.details.available).toBe(5)
    expect(result.details.requested).toBe(6)

    // Confirm no partial commit — inventory must be untouched.
    const stock = await inventoryDB.getStock('prod-tile', 'branch-1')
    expect(stock.quantity).toBe('5.000')
  })

  it('marks the sale as conflict — not synced, not silently dropped — when the server rejects it', async () => {
    // commitSale() fires an un-awaited background SyncManager.flush() the
    // instant it commits (the "sync immediately if online" optimistic-UI
    // behavior) — that's correct production behavior, but it means a real
    // network call could race ahead of this test setting up its mock.
    // Stub flush() as a no-op for the commit step only, then restore the
    // real implementation and drive it explicitly under full test control.
    const flushDuringCommit = vi.spyOn(SyncManager, 'flush').mockResolvedValue(undefined)

    // This device's local snapshot still says 5 (it hasn't heard about
    // the OTHER device's sale yet). Its own sale of 3 looks valid locally.
    await useCartStore.getState().addItem(product, 3, 'BOX')
    const commitResult = await useCartStore.getState().commitSale({
      shiftId: 'shift-1', branchId: 'branch-1', cashier,
    })
    expect(commitResult.success).toBe(true)  // passes the LOCAL check — as it must, it looks fine here

    flushDuringCommit.mockRestore()

    const saleId = commitResult.receipt.sale_id

    // Now the server processes the queued sale and discovers, via its
    // own authoritative lock, that the other device already consumed
    // enough stock that only 2 remain — not enough for this 3-box sale.
    apiClient.post.mockRejectedValueOnce(
      insufficientStockError({ product_id: 'prod-tile', available: '2.000', requested: '3.000', unit: 'BOX' })
    )

    await SyncManager.flush()

    const sale = await salesDB.getById(saleId)
    expect(sale.sync_status).toBe('conflict')
    expect(sale.sync_status).not.toBe('synced')     // must not silently succeed
    expect(sale.sync_status).not.toBe('rejected')   // conflict is distinct from a hard rejection —
                                                       // it needs human/manager review, not a retry loop

    const queueEntries = await syncQueueDB.getAll()
    const entry = queueEntries.find(e => e.entity_id === saleId)
    expect(entry.status).toBe(SyncStatus.CONFLICT)
    expect(entry.conflict_detail.code).toBe('INSUFFICIENT_STOCK')
  })

  it('overwrites the stale local snapshot with server truth on reconnect refresh', async () => {
    // Simulate: this device's snapshot is stale at 5, but the server's
    // real number (after the other device's sale) is 2.
    await import('../../src/db/schema').then(({ getDB }) => getDB()).then(async db => {
      await db.put('auth', {
        key: 'session', user_id: 'user-1', business_id: 'biz-1',
        role: 'cashier', primary_branch_id: 'branch-1',
      })
    })

    apiClient.get.mockResolvedValueOnce({
      data: { data: [makeStock({ product_id: 'prod-tile', branch_id: 'branch-1', quantity: '2.000', updated_at: new Date().toISOString() })] },
    })

    await SyncManager._refreshInventory()

    const stock = await inventoryDB.getStock('prod-tile', 'branch-1')
    expect(stock.quantity).toBe('2.000')  // server truth wins — stale 5 is gone
    expect(inventoryDB.isStale(stock)).toBe(false)  // freshly refreshed
  })
})
