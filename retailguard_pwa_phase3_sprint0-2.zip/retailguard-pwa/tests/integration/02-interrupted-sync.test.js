/**
 * FAILURE MODE 2 — Interrupted sync
 *
 * Real-world trigger: cashier walks near a dead zone mid-flush. The
 * queue has several pending sales; the connection drops after some
 * succeed but before all of them are processed.
 *
 * What must hold:
 *  1. One item's failure must NOT abort the rest of the batch —
 *     items are independent, sequential, and each gets its own outcome.
 *  2. A 'failed' item must NOT be silently retried on the next flush()
 *     call — only requeueFailed() (called by SyncManager on reconnect)
 *     moves it back to 'queued'. Otherwise a transient bug could cause
 *     a failed sale to retry in a tight loop on every 30s poll tick.
 *  3. When the connection genuinely returns, _onOnline() must pick up
 *     exactly the failed item and complete it — nothing lost, nothing
 *     duplicated.
 */
import { describe, it, expect, vi, beforeEach } from 'vitest'
import { syncQueueDB, SyncStatus, EntityType } from '../../src/db/syncQueue'
import { salesDB } from '../../src/db/sales'
import { networkError } from '../helpers/fixtures'

vi.mock('../../src/api/client', () => ({
  apiClient: { post: vi.fn(), get: vi.fn() },
}))

import { apiClient } from '../../src/api/client'
import { SyncManager } from '../../src/sync/SyncManager'

async function seedSale(id) {
  await salesDB.put({
    id, shift_id: 'shift-1', branch_id: 'branch-1', cashier_id: 'user-1',
    subtotal: 10000, discount_amount: 0, total_amount: 10000,
    status: 'completed', sync_status: 'pending', receipt_number: null,
    created_at_device: new Date().toISOString(),
  })
  await syncQueueDB.enqueue({
    entityType: EntityType.SALE, entityId: id, operation: 'create',
    payload: { id, shift_id: 'shift-1', created_at_device: new Date().toISOString(), items: [], payments: [] },
  })
}

describe('Failure mode: interrupted sync (batch partially processed)', () => {
  beforeEach(async () => {
    vi.clearAllMocks()
    Object.defineProperty(window.navigator, 'onLine', { writable: true, value: true })
    await seedSale('sale-A')
    await seedSale('sale-B')  // this one will fail — connection drops here
    await seedSale('sale-C')
  })

  it('processes item C even though item B failed mid-batch', async () => {
    apiClient.post
      .mockResolvedValueOnce({ data: { data: { id: 'sale-A', receipt_number: 'RCP-A' } } })
      .mockRejectedValueOnce(networkError())  // connection drops on B
      .mockResolvedValueOnce({ data: { data: { id: 'sale-C', receipt_number: 'RCP-C' } } })

    await SyncManager.flush()

    const [a, b, c] = await Promise.all([
      salesDB.getById('sale-A'),
      salesDB.getById('sale-B'),
      salesDB.getById('sale-C'),
    ])

    expect(a.sync_status).toBe('synced')
    expect(b.sync_status).toBe('pending')  // untouched — B never got a success response
    expect(c.sync_status).toBe('synced')   // C was NOT skipped because B failed

    expect(apiClient.post).toHaveBeenCalledTimes(3)
  })

  it('does not auto-retry the failed item on a bare flush() call', async () => {
    apiClient.post
      .mockResolvedValueOnce({ data: { data: { id: 'sale-A', receipt_number: 'RCP-A' } } })
      .mockRejectedValueOnce(networkError())
      .mockResolvedValueOnce({ data: { data: { id: 'sale-C', receipt_number: 'RCP-C' } } })

    await SyncManager.flush()  // A completes, B fails, C completes
    apiClient.post.mockClear()

    // Second flush cycle — as if the 30s poll interval fired again
    // WITHOUT a genuine reconnect event (no requeueFailed() call).
    await SyncManager.flush()

    expect(apiClient.post).not.toHaveBeenCalled()  // B must stay untouched
    const b = await salesDB.getById('sale-B')
    expect(b.sync_status).toBe('pending')
  })

  it('recovers the failed item cleanly when the connection genuinely returns', async () => {
    apiClient.post
      .mockResolvedValueOnce({ data: { data: { id: 'sale-A', receipt_number: 'RCP-A' } } })
      .mockRejectedValueOnce(networkError())
      .mockResolvedValueOnce({ data: { data: { id: 'sale-C', receipt_number: 'RCP-C' } } })

    await SyncManager.flush()
    apiClient.post.mockClear()

    // Reconnect: server now accepts the previously-failed sale.
    apiClient.post.mockResolvedValueOnce({ data: { data: { id: 'sale-B', receipt_number: 'RCP-B' } } })
    apiClient.get.mockResolvedValueOnce({ data: { data: [] } })  // inventory refresh — empty is fine here

    await syncQueueDB.requeueFailed()
    await SyncManager.flush()

    const b = await salesDB.getById('sale-B')
    expect(b.sync_status).toBe('synced')
    expect(b.receipt_number).toBe('RCP-B')

    // Only B should have been re-sent — A and C were already completed
    // and getQueued() must not return completed entries.
    expect(apiClient.post).toHaveBeenCalledTimes(1)
  })
})
