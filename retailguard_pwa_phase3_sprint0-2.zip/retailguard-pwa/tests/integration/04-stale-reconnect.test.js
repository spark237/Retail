/**
 * FAILURE MODE 4 — Long offline reconnect (stale snapshot)
 *
 * Real-world trigger: a device goes offline for several hours (branch
 * has no signal overnight, device left in a drawer, etc.) and is used
 * again before reconnecting. Its inventory snapshot is old enough that
 * the server may have moved on — other devices' sales, manager stock
 * adjustments, transfers — none of which this device has seen.
 *
 * What must hold:
 *  1. isStale() correctly flags a snapshot older than the threshold,
 *     and does NOT flag one that's still fresh.
 *  2. A missing last_synced_at (row never refreshed, e.g. malformed
 *     seed data) is treated as stale by default — fail safe, not
 *     fail open.
 *  3. commitSale() does NOT block a sale just because the snapshot is
 *     stale (offline-first: never make the cashier wait on the network
 *     or refuse a sale outright) — but it DOES surface the staleness
 *     on the receipt, so it's visible rather than silently absorbed.
 *  4. Reconnecting and refreshing clears the staleness — the row is
 *     fresh again immediately after bulkPut from the server.
 */
import { describe, it, expect, vi, beforeEach } from 'vitest'
import { inventoryDB } from '../../src/db/inventory'
import { useCartStore } from '../../src/store/cartStore'
import { getDB } from '../../src/db/schema'
import { makeProduct, makeStock, makeCashier, isoHoursAgo, isoMinutesAgo } from '../helpers/fixtures'

vi.mock('../../src/api/client', () => ({
  apiClient: { post: vi.fn(), get: vi.fn() },
}))

import { apiClient } from '../../src/api/client'
import { SyncManager } from '../../src/sync/SyncManager'

const product = makeProduct({ id: 'prod-tile' })
const cashier = makeCashier()

/**
 * commitSale() fires an un-awaited background SyncManager.flush() the
 * instant it commits. Every test below that calls commitSale() but
 * doesn't care about sync outcome stubs flush() during the commit to
 * avoid that fire-and-forget call racing ahead on an unmocked
 * apiClient.post() — see tests/integration/03-stock-conflict.test.js
 * for the first occurrence of this pattern and why it's needed.
 */
async function commitWithoutAutoSync(args) {
  const stub = vi.spyOn(SyncManager, 'flush').mockResolvedValue(undefined)
  try {
    return await useCartStore.getState().commitSale(args)
  } finally {
    stub.mockRestore()
  }
}

describe('Failure mode: long offline reconnect (stale snapshot)', () => {
  beforeEach(async () => {
    vi.clearAllMocks()
    Object.defineProperty(window.navigator, 'onLine', { writable: true, value: true })
    useCartStore.setState({ items: [], payments: [], paymentMethod: 'CASH', notes: '', discountAmount: 0, error: null, lastReceipt: null })
  })

  it('flags a snapshot older than the 4h threshold as stale', () => {
    const stock = makeStock({ last_synced_at: isoHoursAgo(5) })
    expect(inventoryDB.isStale(stock)).toBe(true)
  })

  it('does not flag a recently-refreshed snapshot as stale', () => {
    const stock = makeStock({ last_synced_at: isoMinutesAgo(30) })
    expect(inventoryDB.isStale(stock)).toBe(false)
  })

  it('treats a missing last_synced_at as stale by default (fail safe)', () => {
    const stock = makeStock()
    delete stock.last_synced_at
    expect(inventoryDB.isStale(stock)).toBe(true)
  })

  it('treats a null/undefined stock row as stale (product never seeded locally)', () => {
    expect(inventoryDB.isStale(null)).toBe(true)
    expect(inventoryDB.isStale(undefined)).toBe(true)
  })

  it('completes the sale despite a stale snapshot, and surfaces the warning on the receipt', async () => {
    await inventoryDB.bulkPut([makeStock({ product_id: 'prod-tile', branch_id: 'branch-1', quantity: '10.000' })])
    const seeded = await inventoryDB.getStock('prod-tile', 'branch-1')
    seeded.last_synced_at = isoHoursAgo(6)
    const db = await getDB()
    await db.put('inventory', seeded)

    await useCartStore.getState().addItem(product, 2, 'BOX')
    const result = await commitWithoutAutoSync({
      shiftId: 'shift-1', branchId: 'branch-1', cashier,
    })

    expect(result.success).toBe(true)
    expect(result.receipt.stale_inventory_warning).toBe(true)
  })

  it('does not raise the staleness warning when the snapshot is fresh', async () => {
    await inventoryDB.bulkPut([makeStock({ product_id: 'prod-tile', branch_id: 'branch-1', quantity: '10.000' })])

    await useCartStore.getState().addItem(product, 2, 'BOX')
    const result = await commitWithoutAutoSync({
      shiftId: 'shift-1', branchId: 'branch-1', cashier,
    })

    expect(result.success).toBe(true)
    expect(result.receipt.stale_inventory_warning).toBe(false)
  })

  it('clears staleness immediately after a reconnect refresh', async () => {
    await inventoryDB.bulkPut([makeStock({ product_id: 'prod-tile', branch_id: 'branch-1', quantity: '10.000' })])

    const db = await getDB()
    const stale = await inventoryDB.getStock('prod-tile', 'branch-1')
    stale.last_synced_at = isoHoursAgo(8)
    await db.put('inventory', stale)

    expect(inventoryDB.isStale(await inventoryDB.getStock('prod-tile', 'branch-1'))).toBe(true)

    await db.put('auth', {
      key: 'session', user_id: 'user-1', business_id: 'biz-1',
      role: 'cashier', primary_branch_id: 'branch-1',
    })

    apiClient.get.mockResolvedValueOnce({
      data: { data: [makeStock({ product_id: 'prod-tile', branch_id: 'branch-1', quantity: '7.000', updated_at: new Date().toISOString() })] },
    })

    await SyncManager._refreshInventory()

    const refreshed = await inventoryDB.getStock('prod-tile', 'branch-1')
    expect(refreshed.quantity).toBe('7.000')
    expect(inventoryDB.isStale(refreshed)).toBe(false)
  })
})
