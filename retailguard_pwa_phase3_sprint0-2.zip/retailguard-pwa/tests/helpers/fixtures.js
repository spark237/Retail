/**
 * RetailGuard — Test Helpers
 * Shared fixtures and API mock builders used across failure-mode scenarios.
 */
import { vi } from 'vitest'

/**
 * Build an axios-shaped error, matching what apiClient's interceptors
 * actually produce for HTTP error responses. SyncManager's error handling
 * reads err.response.status / err.response.data — this must match exactly
 * or a test would validate against a shape the real client never produces.
 */
export function httpError(status, data) {
  const err = new Error(`Request failed with status ${status}`)
  err.response = { status, data }
  return err
}

export function conflictResponse(saleId, receiptNumber) {
  return httpError(409, { success: true, data: { id: saleId, receipt_number: receiptNumber } })
}

export function insufficientStockError(details) {
  return httpError(422, {
    success: false,
    error: { code: 'INSUFFICIENT_STOCK', message: 'Insufficient stock', details },
  })
}

export function networkError() {
  const err = new Error('Network Error')
  // Real network failures (connection drop mid-request) have no err.response —
  // axios only attaches .response when a server actually replied.
  err.response = undefined
  return err
}

// ── Fixtures ────────────────────────────────────────────────────────────

export function makeProduct(overrides = {}) {
  return {
    id: 'prod-1',
    name: 'RAK Infinity Floor Tile',
    sku: 'RAK-INF-6060',
    stock_unit: 'BOX',
    selling_price: 12000,
    min_selling_price: 9500,
    sqm_per_box: 1.44,
    pieces_per_box: 10,
    is_active: true,
    reorder_level: '10.000',
    ...overrides,
  }
}

export function makeStock(overrides = {}) {
  return {
    id: 'stock-1',
    product_id: 'prod-1',
    branch_id: 'branch-1',
    quantity: '20.000',
    reorder_level: '10.000',
    ...overrides,
  }
}

export function makeCashier(overrides = {}) {
  return {
    id: 'user-1',
    first_name: 'Jean',
    last_name: 'Mbarga',
    role: 'cashier',
    ...overrides,
  }
}

export function isoMinutesAgo(minutes) {
  return new Date(Date.now() - minutes * 60_000).toISOString()
}

export function isoHoursAgo(hours) {
  return isoMinutesAgo(hours * 60)
}
