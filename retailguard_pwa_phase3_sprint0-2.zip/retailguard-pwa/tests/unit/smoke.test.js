/**
 * Smoke test — validates the test harness itself.
 *
 * If this fails, nothing else in this suite can be trusted:
 * it confirms fake-indexeddb + schema.js + per-test isolation
 * actually work together before any real scenario test builds on them.
 */
import { describe, it, expect } from 'vitest'
import { getDB, clearBusinessData } from '../../src/db/schema'
import { productsDB } from '../../src/db/products'

describe('test harness smoke test', () => {
  it('opens a real IndexedDB connection via fake-indexeddb', async () => {
    const db = await getDB()
    expect(db.objectStoreNames.contains('products')).toBe(true)
    expect(db.objectStoreNames.contains('inventory')).toBe(true)
    expect(db.objectStoreNames.contains('sync_queue')).toBe(true)
    expect(db.objectStoreNames.length).toBe(9)
  })

  it('persists data within a test', async () => {
    await productsDB.bulkPut([
      { id: 'p1', name: 'Test Tile', sku: 'TT-001', is_active: true, stock_unit: 'BOX' },
    ])
    const found = await productsDB.getById('p1')
    expect(found?.name).toBe('Test Tile')
  })

  it('does NOT leak data from the previous test (isolation check)', async () => {
    // If beforeEach in tests/setup/global.js didn't wipe the DB and
    // reset the module cache, 'p1' from the prior test would still be here.
    const found = await productsDB.getById('p1')
    expect(found).toBeUndefined()
    const all = await productsDB.getAll()
    expect(all).toHaveLength(0)
  })
})
