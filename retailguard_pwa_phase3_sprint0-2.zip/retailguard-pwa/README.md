# RetailGuard PWA

Offline-first retail POS & fraud detection frontend. React 19 + Vite + Zustand
+ IndexedDB (`idb`) + TanStack Query (server cache only, never business data).

## Setup (target: under 30 minutes)

**Requirements:** Node 22, npm 10+.

```bash
git clone <repo-url>
cd retailguard-pwa
cp .env.example .env        # defaults point at localhost:8000
npm ci
npm run dev
```

The dev server proxies `/api` to `http://localhost:8000` (see `vite.config.js`),
so a local backend needs to be running for anything beyond the offline-only
screens to work end-to-end.

## Scripts

| Command | What it does |
|---|---|
| `npm run dev` | Start the Vite dev server |
| `npm run build` | Production build, includes service worker generation via `vite-plugin-pwa` |
| `npm run preview` | Serve the production build locally |
| `npm run test` | Run the Vitest suite once |
| `npm run test:watch` | Vitest in watch mode |
| `npm run test:coverage` | Run tests with v8 coverage, report in `coverage/` |
| `npm run lint` | oxlint — fails CI only on errors, not warnings |

## Architecture notes that aren't obvious from the file layout

- **IndexedDB is the source of truth for business data.** TanStack Query is
  server-cache only — never put inventory, cart, or sale data in it.
- **Service worker caches the app shell + product catalog only.** It never
  caches inventory, auth, or analytics endpoints — this is enforced by
  Workbox's default `NetworkOnly` behavior for anything not explicitly listed
  in `runtimeCaching` in `vite.config.js`, not by an explicit denylist.
- **Sales commit optimistically**: UUID generated client-side → IndexedDB
  write → local stock deduction → receipt shown → queued for sync. Network
  never blocks a sale.
- **`vitest.config.js` is deliberately separate from `vite.config.js`** — the
  PWA plugin generates a service worker at build time, which has no business
  running in a test environment.
- **JWT lives in module memory only; refresh token is an HttpOnly cookie.**
  Neither ever touches IndexedDB.

## Testing

7 test files, 29 tests: 1 smoke test + 6 failure-mode integration suites
(duplicate sync, interrupted sync, concurrent stock conflict, stale
reconnect, refresh mid-sale, crash recovery) using `fake-indexeddb` for real
IndexedDB semantics, not a mock.

**Known gap, intentionally undocumented-as-fixed until Sprint 3:** a crash
between `markProcessing()` and `markCompleted()`/`markFailed()` in the sync
queue leaves that entry permanently stuck in `'processing'`.
`requeueFailed()` does not currently reclaim it. See
`tests/integration/06-crash-recovery.test.js` Scenario 6, Test 4, which
asserts this as current behavior, not a fix.

## CI

See `.github/workflows/frontend-ci.yml`. Required check for merging to
`main`: `Frontend CI / build-and-test` — see `docs/BRANCH_PROTECTION.md`.
