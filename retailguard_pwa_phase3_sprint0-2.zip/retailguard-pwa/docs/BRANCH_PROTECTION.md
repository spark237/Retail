# Branch Protection — `main`

GitHub branch protection is configured in repo Settings → Branches, not in a
committed file. This doc is the source of truth for what that setting should
be, so it survives even if someone reconfigures the repo.

## Required settings for `main`

- **Require a pull request before merging** — no direct pushes to `main`.
- **Require status checks to pass before merging**, specifically:
  - `Frontend CI / build-and-test`
  - `Backend CI / build-and-test` (once the backend zip is available and its
    workflow exists — not yet wired up as of this Sprint 0 pass)
- **Require branches to be up to date before merging.**
- **Require at least 1 approval** (adjust once team size is known).
- **Do not allow bypassing the above settings**, including for admins.

## Why this matters here specifically

Per the Phase 4 Baseline Plan's CI Quality Gates: green CI is a merge
prerequisite, not a status indicator. Branch protection is the mechanism that
actually enforces that — without it, the CI workflow can be green or red and
someone can merge anyway.
